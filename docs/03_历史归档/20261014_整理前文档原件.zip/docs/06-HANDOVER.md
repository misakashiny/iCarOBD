# iCar OBD —— 详细手册

> 面向「下一个接手这个项目的 AI 智能体」。
> 目标：让你在 15 分钟内理解全部设计意图、能独立构建、能安全地继续扩展，而不需要重新踩一遍坑。
>
> **⚠️ 请先从 [`01-接手大纲.md`](01-接手大纲.md) 开始** —— 那是唯一入口，
> 里面有项目全貌、上手路线和红线清单。本文是它的展开手册。
> **不知道某件事该查哪份文档 → 看 [`00-README.md`](00-README.md)（文档索引 + 权威表）。**
>
> ## ⚠️⚠️ 本文的时效性（2026-10-11 全量文档迭代时核实 —— 请务必先读这段）
>
> **本文很长（800+ 行），其中"当前状态"性质的段落严重过期**：
>
> | 本文写的是 | 实际（2026-10-11） | 权威在哪 |
> |---|---|---|
> | 最新状态 **v1.9.0**（2026-10-03） | **v1.20.20**（versionCode 89） | [`03-迭代清单.md`](03-迭代清单.md) |
> | **415 个单元测试 / 19 个文件** | **1050 用例 / `SKIPPED=0` / 58 个测试文件** | 跑 `tools\run-tests.ps1` 看输出 |
> | 产物 `dist/iCarOBD-debug-v1.10.4-android.apk` | `dist/iCarOBD-debug-v1.20.20-android.apk` | `app/build.gradle.kts` |
> | 页脚"版本 `1.4.0`（versionCode 6）" | **v1.20.20** | 同上 |
> | §1「尚未完成」里 **"尚未接入真实车辆"** | ❌ **早已实车打通**（2026-10-06，阿特兹怠速，见 CHANGELOG v1.18.3） | [`01-接手大纲.md`](01-接手大纲.md) §1 |
> | §1「**无单元测试**」 | ❌ 1050 条 | 同上 |
> | §1「仅支持 BLE，不支持 SPP」 | ❌ v1.4.0 起支持 SPP | [`05-FILE_MAP.md`](05-FILE_MAP.md) §2.2 |
> | §1「仪表渲染层：三种自绘 View」 | ❌ 现在是 **8 种样式**（`GaugeViewFactory`） | [`08-UI控件清单.md`](08-UI控件清单.md) §一 |
> | §1「3 种仪表盘」 | ❌ 现在是 **多套画布**（最多 8 套，v1.20.0） | [`12-主题设计大纲.md`](12-主题设计大纲.md) |
>
> **本文仍然可靠的部分**：架构意图、扩展流程（怎么加 PID / 规则 / 仪表）、
> 安全模型（扫描器的七道闸门）、装机与排障步骤、**踩坑记录**。
> 这些都是长期有效的，也是本文真正的价值所在。
>
> ⚠️ **改本文时不要为了"对上数字"去重写历史段落** —— 只更新"当前状态"性质的表述。
> **本文以下内容保留原样**（那是 v1.9.0 时点的记录）。

---

## ⭐ 最新状态（v1.9.0 · 2026-10-03）—— ⚠️ **已过期，见文件头那张表**

> 🔴 **这一节是 2026-10-03（v1.9.0）的时点记录，里面的数字与"未完成"清单早已不成立。**
> **当前状态请看文件头那张对照表**，或直接看 [`03-迭代清单.md`](03-迭代清单.md)（版本清单的权威）。
> **本节保留原样**是为了留下当时的判断依据（例如"霓虹性能基准没量准"那条风险后来怎么收的）。

> 上面那些章节是长期有效的架构与手册；这一节只讲"现在到哪了"。
> 会话轮次很多，历史细节见 [`07-CHANGELOG.md`](07-CHANGELOG.md)（已 9000+ 行，按版本倒序）。

### 产物

```
dist/iCarOBD-debug-v1.10.4-android.apk    6.69 MB
```
**415 个单元测试全通过（19 个文件）。** 构建/测试命令见 §2.1。

### 这个阶段做完的

| 项 | 说明 |
|---|---|
| **LVGL 方案放弃** | 软件渲染 327 万像素撑不住 60fps（≈23ms/帧），且引入线程模型负担。<br>完整记录见 **[LVGL-放弃记录.md](19-LVGL-放弃记录.md)**。代码还在树里但**入口已关闭** |
| **坐标系改每轴 0..360** | 含旧配置自动迁移（`unit` 版本标记）。`Drag` 网格 `STEP=15` |
| **Sky Gauge 主题解析/转换** | `data/SkyTheme.kt` + `data/DashElement.kt` + `SkyImport`。**纯 Kotlin，不依赖 LVGL**，29 个单测 |
| **仪表盘霓虹重构** | 新增 `NeonPainter`（共用辉光层）+ `CircularGaugeView` 重写（危险区标识 + 爆闪）|
| **阈值爆闪** | 新增 `AlertPulse`（**带迟滞** + 两档节奏），27 个单测 |
| **模拟信号页重构** | 每通道从 7 行控件压到 1 行摘要 + 可展开详情；波形缩略图复用生成器函数 |
| **PC 端设计框架** | `data/DesignFile.kt` + [UI设计指南.md](13-UI设计指南.md)（`icar.ui/1` 格式） |
| **UI 文档化** | [UI控件清单.md](08-UI控件清单.md)（所有控件名/ID/颜色）· [动画实现.md](10-动画实现.md)（动画机制） |

### ⚠️ 未完成 / 未验证（**接手时请优先处理**）

> 🔴 **这五条是 v1.9.0 时点的清单，现在逐条已变 —— 不要照它开工：**
>
> | # | v1.9.0 时 | 现在（2026-10-11） |
> |---|---|---|
> | 1 | 霓虹性能基准没量准 | ✅ **已量**（v1.10.1：12 表 + 11 层辉光跑满 120fps，**零掉帧**）→ 见 [`04-ARCHITECTURE.md`](04-ARCHITECTURE.md) 红线 4.5.22 |
> | 2 | 四种仪表没接霓虹 | ✅ **已接**（`NeonCoverageTest` 守着覆盖） |
> | 3 | 模拟器分组太粗 | ✅ **已重做**（`SignalSimulator` 分组 + 可折叠，见 [`05-FILE_MAP.md`](05-FILE_MAP.md)） |
> | 4 | LVGL 代码未删除 | ❌ **仍未删**（`app/src/main/cpp/lvgl` 14.4 MB **还在**，确认无构建引用之外的改动）—— **这条仍然有效** |
> | 5 | 实车 BLE 写入链路从未复验 | ✅ **已复验**（2026-10-06 实车：`CCCD 写入完成` 出现、`写入被拒` 0 条） |
>
> **现在真正"未完成"的清单在 [`03-迭代清单.md`](03-迭代清单.md) 的待办节**，不在本文。

1. **🔴 霓虹的性能基准没量准**。`dumpsys gfxinfo` 只采到 5 帧（样本太小）。
   **9 层辉光上限能否在 8 个仪表下守住 60fps，尚未验证。**
   这是**唯一一个"可能推倒重来"的风险点** —— 本项目已经因为"选型不量性能"放弃过一次 LVGL，
   不要再犯。建议先做一个能强制连续动画的基准（不依赖模拟信号）。
2. 数字 / 折线 / 多值 / G力值**四种仪表还没接霓虹**
3. 模拟器分组太粗（标准 OBD 19 个通道挤在一组）
4. LVGL 代码未删除（`cpp/lvgl/` 14.4 MB + `lvgl_bridge.cpp` + `neon_gauge.cpp`）。
   删掉能缩短编译时间。**属独立且不可逆的一次动作**
5. **实车 BLE 写入链路从 v1.3.0 起从未复验**（`tools/oncar-check.ps1`）

### 这个阶段踩过的坑（**都是"看起来合理的推断"没去量**）

| 推断 | 实际 |
|---|---|
| `g_buf` 是帧缓冲 | 它是 LVGL 的**绘制暂存区**，只有脏区域有效 → 整个仪表炸了 |
| `lv_disp_flush_is_last` 能省提交 | 它把**大部分提交挡掉了** → 帧率 100→10 |
| `flush_cb` 里可以直接提交窗口 | `ANativeWindow_lock` 会阻塞，而那时**正握着锁** → **ANR** |
| 探针能读出正确像素 ⇒ 是帧缓冲 | 探针**只在自己触发过全屏重绘后才成立** |

**两条方法论**（写进 `19-LVGL-放弃记录.md` §七）：
- **改完立刻量。** 上面每一个都能在改完当场量出来。
- **用户的现象描述比日志值钱。**「弹无响应」四个字直接指向主线程阻塞，比我靠日志猜有效得多。

### 工具经验（本机实测）

- **改 C 文件不要用 PowerShell 多行字符串替换** —— 这个阶段**静默失败 5 次**（引号/换行差异），
  其中一次导致"字体加载成功但从未使用"，还基于它报告过成功。**直接按行号 splice，一次没失手。**
- **8×6 像素探针会骗人**（每 ~200×340 像素才采一个点，整片漏掉文字）。
  判断"画面是不是空的"要用**亮像素统计**，最可靠的是**截图 + 解码成色彩网格**。
- **adb 传二进制**：`cmd /c ... < file` 会**截断**（204288 → 16484）。
  用 `adb push` + `chmod 644` + `run-as cp`。
- **跑自动化验证前先锁方向**（`accelerometer_rotation 0` + `user_rotation 0`），
  否则转屏导致 Fragment 重建、验证链断掉。

---
> 项目路径：`D:/icarobd`（ASCII 联结 → `D:\AI Dsh\车机项目\iCarOBD2`）
> 包名：`com.icar.obd`　版本：**`1.20.20`**（versionCode 89 —— ⚠️ 本行曾长期写着 `1.4.0`，已过期）
>
> **六份主干文档的分工**（别重复读；**完整索引见 [`00-README.md`](00-README.md)**）：
> | 文档 | 回答什么 |
> |---|---|
> | [`00-README.md`](00-README.md) | **我该看哪份** —— 文档索引 + 权威表 |
> | [`01-接手大纲.md`](01-接手大纲.md) | **入口** —— 项目全貌、上手路线、红线清单 |
> | [`03-迭代清单.md`](03-迭代清单.md) | 做完了什么 / 接下来做什么（带验收标准） |
> | [`04-ARCHITECTURE.md`](04-ARCHITECTURE.md) | **为什么** —— 架构意图、数据流、边界速查 |
> | [`05-FILE_MAP.md`](05-FILE_MAP.md) | **改哪里** —— 文件清单、关键符号、改动风险、任务索引 |
> | `06-HANDOVER.md`（本文） | **详细手册** —— 扩展流程、安全模型、装机清单、踩坑记录 |
> | [`07-CHANGELOG.md`](07-CHANGELOG.md) | **改过什么** —— 按版本的变更与验证记录 |

---

## 0. 一句话定位

一个 Android 应用：通过 **Vgate iCar Pro 2S**（ELM327 兼容）把车辆 OBD 数据读到手机，
以**可自定义的仪表盘**实时显示，并用**规则引擎**把数据变成事件（转向灯音效、水温/电压告警等）。

**这个项目最重要的一条设计原则：**

> 新增一种车辆数据，永远不需要改代码、不需要重新编译 APK —— 只需要在 App 里「添加 PID → 测试 → 保存 → 选进仪表盘」。

所有架构决策都是为了守住这条原则。**你在改动任何东西之前，先确认没有破坏它。**

---

## 1. 当前状态

### 已完成并编译通过

| 模块 | 状态 | 说明 |
|---|---|---|
| BLE 传输层 | ✅ | GATT 连接、已知 UUID 优先 + 通用特征探测兜底、MTU 协商、按 `>` 切帧 |
| ELM327 会话层 | ✅ | AT 初始化序列、串行化请求、超时、原始命令通道 |
| OBD 协议层 | ✅ | 响应 → 数据字节提取（兼容 ATH0/ATH1）、公式求值 |
| 公式引擎 | ✅ | 自研表达式解析器，支持 `A..Z`、四则运算、`bit()/signed()/min()/max()` 等 |
| 轮询引擎 | ✅ | 单请求串行、按 PID 独立周期、失败退避冷却、采样率统计 |
| 派生通道 | ✅ | 瞬时油耗、燃油流量、增压压力、本次里程（由其它通道实时算） |
| 规则引擎 | ✅ | AND/OR 多条件、持续时间防抖、冷却、6 种动作 |
| 仪表渲染层 | ✅ | 圆表/数字/条形 三种自绘 View，与数据层完全解耦 |
| 3 种仪表盘 | ✅ | 普通驾驶 / 性能模式 / 自定义 |
| **横竖屏自适应** | ✅ | 横屏左侧导航栏；仪表盘竖屏 2 列 / 横屏 3~4 列；表单限宽居中。详见 `05-FILE_MAP.md` §6 |
| 自定义仪表编辑器 | ✅ | 通道、样式、占位宽度、量程、报警值、顺序，全部持久化 |
| PID 编辑器 | ✅ | 全字段 + **在线测试**（TX/RX/数据字节/解析结果） |
| PID 扫描器 | ✅ | 限流/超时/重试/黑名单/危险模式拦截/支持位图收敛 |
| CSV 记录 | ✅ | 1Hz 采样，列对齐，可导出 |
| 结构化日志 | ✅ | 内存环形缓冲 + 按天落盘（保留 7 天）+ 模块/级别过滤 + 导出 |
| 前台服务 | ✅ | 保活 BLE，通知栏显示状态与采样率 |
| 自动重连 | ✅ | 掉线后 3s 重试，上限 3 次；用户主动断开不重连 |
| 音效 | ✅ | SoundPool 低延迟，**9 个内置预设**（`tick_left` / `tick_right` / `beep` / `ding` / `dingdong` / `success` / `fail` / `warn` / `alert`），全部由 `tools/gen_sounds.py` **代码合成**；清单权威是 `data/SoundPresets.kt` |

### 尚未完成 / 未验证（**接手时请优先处理**）

> 🔴 **这张表是 v1.4.0~v1.9.0 时点的，多数已不成立**（"尚未接入真实车辆""无单元测试"
> "仅支持 BLE"三条都已被推翻，见文件头对照表）。**保留原样是为了留当时的判断依据。**

| 项 | 严重度 | 说明 |
|---|---|---|
| **仅支持 BLE，不支持经典蓝牙 SPP / WiFi** | 🔴 高 | 见 §10.1。若你的 iCar Pro 2S 在系统蓝牙里显示为经典设备而非 BLE，当前代码扫不到它 |
| **尚未接入真实车辆** | 🔴 高 | 已在平板（小米平板5 / Android 13）上完成 UI 全链路验证（见 §11.1），但**从未连接过 iCar Pro 2S，也没有在车上跑过**。首次接车请按 §11 排查 |
| 阿特兹厂家 PID 号全部为占位值 | 🟡 中 | 见 §10.2。必须用扫描器实测，不能直接信任 |
| 无单元测试 | 🟡 中 | 公式引擎、协议解析、规则引擎都很适合补测试 |
| ISO-TP 多帧重组 | 🟡 中 | 依赖 ELM327 自身重组，长响应可能不完整 |
| 故障码（DTC）读取 | ⚪ 低 | **有意不做**，见 §9 |

---

## 2. 五分钟上手

### 2.1 构建与测试

```bash
cd /d/icarobd
export JAVA_HOME='C:\Program Files\Eclipse Adoptium\jdk-21.0.12.101-hotspot'
export ANDROID_HOME='C:\Android\Sdk'
export ANDROID_SDK_ROOT='C:\Android\Sdk'
./gradlew assembleDebug
```

> ⚠️ 关于 `JAVA_HOME`：旧文档说「必须显式导出，否则报没装」——那是当时 WorkBuddy 会话的
> 现象（进程启动早于用户级变量写入）。**当前 DSH 会话里两个变量都已就绪**，
> 真报 `JAVA_HOME is not set` 时再显式导出即可。

> ⚠️ **路径曾经含空格与中文**（旧位置 `D:\AI Dsh\车机项目`；现位于 `D:\AI Dsh\车机项目\iCarOBD2`（含空格与中文））：AGP 默认拒绝构建，
> 已用 `android.overridePathCheck=true` 放行。**但测试任务在原路径必然失败** ——
> 见 [`05-FILE_MAP.md`](05-FILE_MAP.md) §6。

产物：`app/build/outputs/apk/debug/app-debug.apk`
归档副本：`dist/iCarOBD-debug-v1.20.20-android.apk`（⚠️ `dist/` 里**历史 APK 全都还在**，不是只留最新一个）

**跑单元测试**（**1050 用例 / `SKIPPED=0`**）—— **不要**直接 `./gradlew testDebugUnitTest`：

```powershell
powershell -ExecutionPolicy Bypass -File tools\run-tests.ps1
```

非 ASCII 路径会让 JVM 启动器解码坏 `-cp`，全部测试类都报
`ClassNotFoundException: <测试类自身>`。脚本先建 ASCII 目录联接 `D:\icarobd`
指向工程真实位置，从联接路径跑 Gradle；**工程本身不动**，构建产物也仍在原处。

### 2.2 装机

```bash
# 中文路径会让 Git Bash 向 adb 传参编码错乱，所以先复制成英文名
cp dist/iCarOBD-debug-v1.20.20-android.apk /tmp/stage.apk
C:/Android/Sdk/platform-tools/adb.exe install -r -d /tmp/stage.apk

# 装机后立刻查崩溃（编译通过 ≠ 能运行）
C:/Android/Sdk/platform-tools/adb.exe logcat -d -b crash
```

### 2.3 运行期调试

```bash
# 实时看应用日志（应用内「日志」页也能看，且更友好）
C:/Android/Sdk/platform-tools/adb.exe logcat -s iCarOBD/V iCarOBD/D iCarOBD/I iCarOBD/W iCarOBD/E

# 把 App 内日志文件拉到电脑分析（这是最有用的调试手段）
C:/Android/Sdk/platform-tools/adb.exe shell run-as com.icar.obd ls files/log
C:/Android/Sdk/platform-tools/adb.exe exec-out run-as com.icar.obd cat files/log/obd-$(date +%Y%m%d).log > obd.log
```

---

## 3–4. 架构与文件职责（指向权威文档）

> **这两节的内容已经收敛到别处，本文刻意不再重复。**
>
> 原因：历史上同一份内容在多个文档各写一份，结果真的分叉过 ——
> 最典型的是「红线清单」曾一处 7 条、另一处 12 条，v1.1.0 的横屏约束只写进其中一份，
> 照着另一份改代码就漏了约束。**同一个事实只允许有一个权威位置。**

| 我想知道… | 权威文档 |
|---|---|
| 分层、依赖方向、数据链路与排障 | [`04-ARCHITECTURE.md`](04-ARCHITECTURE.md) §1 / §2 |
| 仪表盘渲染与布局（自由画布 / 参考线 / 多数据 / 历史） | [`04-ARCHITECTURE.md`](04-ARCHITECTURE.md) §6 |
| 横竖屏自适应 | [`04-ARCHITECTURE.md`](04-ARCHITECTURE.md) §3 |
| **不可跨越的边界（红线）** | [`04-ARCHITECTURE.md`](04-ARCHITECTURE.md) §4（**唯一权威清单**） |
| 某个文件是干什么的、改哪里 | [`05-FILE_MAP.md`](05-FILE_MAP.md) §2 / §3 / §5 |
| 现在该干什么 | [`03-迭代清单.md`](03-迭代清单.md) |

本文（HANDOVER）只保留**接手流程、扩展步骤、安全模型、装机清单、踩坑记录**这类
「只有做过一遍的人才知道」的内容 —— 也就是无法从代码里直接读出来的部分。

---

## 5. 核心工作流 A：新增阿特兹 PID（**最重要的一节**）

这是整个项目存在的意义。请严格按顺序操作，能省掉大量试错。

### 步骤 1：先扫，不要猜

厂家 PID 号是猜不得的。打开 **PID 页 → PID 扫描器**：

- **Mode 01**：勾选「先用支持位图收敛范围」。程序会先请求 `0100/0120/0140/0160` 拿支持位图，
  只扫车厂声明支持的 PID，请求量从 ~96 次降到 ~30 次。
- **Mode 22（阿特兹厂家数据主要在这里）**：没有标准位图，必须给地址范围。
  默认 `1100~11FF` 只是**示例**，实际地址段请按你查到的资料调整。
- 安全参数保持默认（间隔 150ms / 超时 1500ms / 重试 1 / 上限 400）。
  **不要为了快把间隔调到 30ms 以下**，那会打满总线。

扫到命中后，每条结果右侧有「存为PID」，会自动带入编辑器并预填 Mode/PID/建议公式。

### 步骤 2：在编辑器里验证

在 **PID 编辑器** 里点「发送测试请求」，界面会显示四个关键信息：

```
TX: 22 12 34                          ← 实际发出的帧
RX: 62 12 34 3A F2                    ← 原始响应
数据字节： A=3A  B=F2                   ← 提取出的数据字节与变量名对应
解析结果： 63.86 ℃                      ← 按当前公式算出的值
```

**反推公式的方法**：拿 `A=3A B=F2`（十进制 58 与 242），
配合你资料上该量的物理值，就能确定是 `(A*256+B)*k+c` 还是 `A*k+c` 还是别的编码。

### 步骤 3：改公式 → 再测 → 直到对上

公式支持（见 `Formula.kt`）：

```
变量：A B C ... Z          （响应第 1..26 个数据字节，0..255）
运算：+ - * / % ^          括号 ( )
函数：min max abs round floor ceil sqrt
      bit(A, n)           取 A 的第 n 位（0 起），返回 0 或 1
      signed(A)           把 A 当 8 位有符号数（-128..127）
进制：0xFF
```

常用模板（编辑器里有快捷按钮）：

| 场景 | 公式 |
|---|---|
| 单字节直读 | `A` |
| 双字节大端 | `(A*256)+B` |
| 双字节大端 ×0.1 偏置 | `((A*256)+B)*0.1-40` |
| 温度（单字节，-40 偏置） | `A-40` |
| 百分比 | `A*100/255` |
| 燃油修正 | `(A-128)*100/128` |
| 开关量/位标志 | `bit(A,0)` |
| 有符号双字节 | `signed(A)*256+B` |

### 步骤 4：保存 → 启用 → 加进仪表盘

保存后回到 PID 页把开关打开（**未启用的 PID 不参与轮询**），
然后到 **仪表盘 → 自定义 → 编辑 → 添加仪表**，选上它，设好量程与报警值。

### 步骤 5（可选）：让规则引擎用上它

如果这个量需要告警（比如变速箱油温 > 120℃），到 **规则页 → 新增规则**，
数据源选它，设阈值与持续时间，动作选「弹出提示 + 仪表变色」。

> **转向灯音效同理**：转向灯信号扫出来后，把「左转向灯音效」规则的数据源
> 从默认的占位 PID 改成真实 PID 即可，不需要写任何代码。

---

## 6. 核心工作流 B：规则引擎与转向灯音效

### 6.1 触发语义（**容易误解，务必看清**）

```
条件成立 → 开始计时 → 持续 durationMs → 触发 → 进入 cooldownMs 冷却
                                                  ↓
                            冷却结束后，若条件仍成立 → 再次触发
```

这是**重复触发**语义，不是边沿触发。原因：转向灯信号在总线上是持续为 1 的状态
（开关量），只有「持续成立就按冷却周期反复响」才能产生「一秒一闪」的效果。

默认规则「左转向灯音效」的参数就是按这个设计的：
- 数据源 = 左转向信号，操作符 = `==`，阈值 = `1`
- 持续 = 0ms，冷却 = **450ms** ← 这个值决定了闪烁节奏

如果你需要「值一变就响一声」的边沿语义，把操作符改成 `~`（CHANGED）。

### 6.2 六种动作

| type | p1 | p2 | 说明 |
|---|---|---|---|
| `sound` | 音效名 | — | 9 个预设之一（`tick_left`/`tick_right`/`beep`/`ding`/`dingdong`/`success`/`fail`/`warn`/`alert`），也可以是 `content://` 音频文件 URI；未登记的名字回退 `beep` 并记日志 |
| `toast` | 文本 | — | **只弹灵动岛**（v1.20.21 起；v1.20.12 去掉了页面内告警条，v1.20.21 去掉了系统 Toast —— 以前一次弹两个）。出口表在 `data/RuleAlert.kt` |
| `log` | 文本 | — | 只写日志 |
| `gauge` | PID id（空=条件源） | 颜色名 | 给仪表染色。颜色：`red/green/yellow/orange/blue/cyan/purple/white/reset`，也支持 `#RRGGBB` |
| `vibrate` | 时长 ms | — | 振动 |
| `notify` | 文本 | — | 系统通知（需 POST_NOTIFICATIONS 权限） |

### 6.3 默认 5 条规则

`Defaults.defaultRules()`：左转向音效、右转向音效、高水温告警（>105℃ 持续 3s）、
电压异常（<11.8V 持续 3s）、超速提醒（>120 持续 5s）。

前两条依赖的 `tpl_left_turn` / `tpl_right_turn` **默认是关闭的** —— 这是刻意的：
标准 OBD 里没有转向灯，必须先扫出真实 PID。规则列表里会显示
「⚠ 数据源未启用」提示，避免你以为规则坏了。

---

## 7. 公式引擎细节

`Formula.eval(expr, data)`：`data[i]` 对应变量 `'A'+i`。

- 取超出数据长度的变量会抛 `FormulaException`（不是返回 0）——这是刻意的，
  避免「公式写错但静默算出一个看似合理的值」。
- `Formula.check(expr)` 用 26 字节零数据做静态语法校验，编辑器保存前会调它。
- 解析器是递归下降：`parseExpr`(+/-) → `parseTerm`(*/%/) → `parseUnary`(-/+) → `parsePower`(^) → `parsePrimary`。

---

## 8. 仪表渲染层（速查）

> **架构与取舍见 [`04-ARCHITECTURE.md`](04-ARCHITECTURE.md) §6** ——
> 本节只给速查表，**刻意不重复「为什么」**。

### 8.1 样式 → View

映射的**唯一**位置是 `ui/view/GaugeViewFactory.kt`（渲染器与拖拽编辑器共用它，
分两处写必然分叉）。

| style | 常量 | 类 | 适用 |
|---|---|---|---|
| 0 | `STYLE_CIRCLE` | `CircularGaugeView` | 主指标（车速 / 转速），可挂指针环 |
| 1 | `STYLE_DIGITAL` | `DigitalGaugeView` | 需要精确读数的主指标 |
| 2 | `STYLE_BAR` | `BarGaugeView` | 次要指标，一屏放多个 |
| 3 | `STYLE_LINE` | `LineChartView` | 趋势曲线（**纵轴固定用量程，不自动缩放**） |
| 4 | `STYLE_DUAL_STACK` | `DualStackGaugeView` | 主 + 1 副，上下等分 |
| 5 | `STYLE_QUAD` | `QuadGaugeView` | 主 + 3 副，2×2 |
| 6 | `STYLE_SUB_DUAL` | `SubDualGaugeView` | 主大 + 2 副小 |
| 7 | `STYLE_GFORCE` | `GForceGaugeView` | G 值 2D 点 |

> 未知 `style` 一律回落到数字表，**绝不崩**（旧配置降级时很重要）。

### 8.2 刷新与布局

- `DashRenderer` 内部 **5Hz**（200ms）拉取数据 —— 高于 OBD 轮询率，不丢帧又省电。
- 位置尺寸用**归一化坐标**，像素换算只在 `render()` 里做；画布尺寸变化时 `relayout()` 重排。
- ⚠️ **不要改回「网格 + span + weight」**：那套（自然高度 186/92/54、`MAX_SCALE`、
  `NestedScrollView`）在 v1.5.0 已废弃，见 [`04-ARCHITECTURE.md`](04-ARCHITECTURE.md) §6.3。

### 8.3 横竖屏自适应

**权威描述在 [`04-ARCHITECTURE.md`](04-ARCHITECTURE.md) §3**，本节不再重复。
唯一要记的是：`MainActivity.switchTo()` 必须用 `commitNow()`，不能用 `commit()`
（后者异步，旋转恢复时会产生重复 Fragment）。

---

## 9. PID 扫描器的安全模型（**不要放松**）

`PidScanner` 有 7 道闸门，全部是硬约束：

| 闸门 | 默认 | 作用 |
|---|---|---|
| 请求间隔 `intervalMs` | 150ms | 两条请求之间强制 `delay()`，这是「不伤总线」的核心 |
| 单条超时 `timeoutMs` | 1500ms | 未定义 PID 往往超时，必须限时 |
| 重试 `retry` | 1 | 避免偶发丢包被误判为「不支持」 |
| 黑名单 `blacklist` | Mode 01 预置 4 条 | 跳过 DTC 相关等非实时数据 |
| 危险模式拦截 | 硬编码 | `ObdProtocol.isDangerous()` 命中即抛异常 |
| 总量上限 `maxRequests` | 400 | 防止参数填错跑出天文数字 |
| 支持位图收敛 | 开启 | Mode 01/09 只扫车厂声明支持的 PID |

**危险模式**（`DANGEROUS_MODES`）：`02 冻结帧 / 03 读故障码 / 04 清故障码 / 05 氧传感器 /
06 车载监测 / 07 / 08 / 10~14`。其中 **04 会清除故障码**，误触可能让你丢失重要的历史故障信息。

扫描器 UI 里这些模式**故意仍然可见**（标注「危险·拒绝」），点开始会被拦下并写日志 ——
这是为了让下一个接手的人知道「这里曾经挡过一次」。

`learnSamples`（学习采样）默认 **0（关闭）**：开启后会对每条命中额外请求 N 次以记录 min/max，
**这会显著增加总线负载**，只在需要标定量程时临时开。

---

## 10. 已知限制与风险

### 10.1 🟡 传输方式：BLE 已支持，经典蓝牙 SPP 已实现（未实机验证），WiFi 未做

Vgate iCar Pro 系列有几个变体，对应不同链路：

| 变体 | 链路 | 状态 |
|---|---|---|
| **iCar Pro 2S** | BLE 4.0（GATT 透传） | ✅ `BleTransport` |
| **iCar Pro BT3.0** | **经典蓝牙 SPP**（RFCOMM + `00001101-...`） | ✅ `SppTransport`（v1.4.0，**未实机验证**） |
| iCar Pro WiFi | TCP `192.168.0.10:35000` | ⬜ 未做 |

**接手第一件事**：确认你手上的设备在系统蓝牙设置里是「BLE 设备」还是「经典设备」。
BLE 设备会出现在 BLE 扫描里；**经典设备在 BLE 扫描里根本不出现** ——
这时把连接页的「传输方式」改成 **经典蓝牙 SPP** 再扫。

**分层已经干净**（v1.4.0 完成）：`ObdTransport` 是接口，`ElmSession` / `ObdEngine`
只依赖它。要再加 WiFi/TCP，只需：

1. 实现 `ObdTransport`（照 `SppTransport` 抄即可）；
2. 在 `ObdController.buildTransport()` 注册；
3. `Store.Settings.transportKind` 加一个取值，连接页 `transportKeys` 加一项。

**不要**在 `ElmSession` 或更上层加传输分支判断，那会污染分层。

> ⚠️ SPP 的**接口抽象已验证**（BLE 路径无回归、应用可正常启动），
> 但**没有用真实 BT3.0 适配器跑过**。真机上连不上时优先怀疑三处：
> ① `connect()` 前是否漏了 `cancelDiscovery`（已做）；
> ② 是否需要 `createRfcommSocketToServiceRecord` 的反射兜底；
> ③ 连接超时是否太短。

### 10.2 🟡 阿特兹 PID 号全是占位值

`BuiltInPids.MANUFACTURER_TEMPLATES` 里 4 条厂家模板的 PID 号（`1234` / `2201` / `2202` / `2300`）
**都是占位示例**，只有公式骨架是对的。它们默认关闭。

我没有编造真实的马自达 PID 号，因为**错误的 PID 号比没有更危险** ——
你可能会拿到别的信号的值，然后据此做判断。

正确做法见 §5。

### 10.3 🟡 ISO-TP 多帧

长响应（>7 字节）依赖 ELM327 自身重组。部分廉价固件重组不完整。
如果发现某条 PID 响应被截断，日志里能看到原始帧，可以自己用 `customRequest` + 公式处理。

### 10.4 真机（平板）验证状态

**已完成**：小米平板 5（`M2105K81AC` / 代号 `elish`，Android 13 / SDK 33，1600×2560 @360dpi）
上安装运行，UI 全链路无崩溃、无 ANR。详见 §11.1。

**已完成（v1.1.0）**：横竖屏自适应在平板上逐页验证通过。详见 §11.2。

**已完成（v1.3.0）**：日志页崩溃与日志洪泛修复，
用压力注入的方式验证了适配器 3000 条溢出路径。

**已连接过真车（v1.3.0 前）但未取到数据**：
2026-10-02 首次上车，成功连上适配器 `IOS-Vlink`（BLE GATT），
但**所有 AT 命令超时、一个字节都没收到**，扫描 0 命中。
根因是写类型写死 + 特征选择不校验属性，已在 v1.3.0 修复，
但**修复本身尚未经实车复验**。详见 §11.3。

**仍未完成**：从未取到任何真实总线数据。
因此「数据链路」——ELM327 初始化、PID 解析、公式求值、规则触发
——**全部尚未经真实总线验证**。这是当前最大的风险。

---

## 11. 装机后必查清单（编译通过 ≠ 能运行）

> **实车场景直接跑 `tools\oncar-check.ps1`**：它把下面这些检查连同 GATT 表、
> AT 命令 TX/RX 与超时、初始化结果、扫描器日志一次收齐，并按 GATT 表给出判定。

```bash
# 1. 装机
cp dist/iCarOBD-debug-v1.20.20-android.apk /tmp/stage.apk
C:/Android/Sdk/platform-tools/adb.exe install -r -d /tmp/stage.apk

# 2. 启动
C:/Android/Sdk/platform-tools/adb.exe shell am start -n com.icar.obd/.ui.MainActivity

# 3. 立刻查崩溃（最重要）
C:/Android/Sdk/platform-tools/adb.exe logcat -d -b crash

# 4. 看应用日志确认初始化顺序
C:/Android/Sdk/platform-tools/adb.exe logcat -d -s iCarOBD/I iCarOBD/E
```

**预期看到**：日志里有 `===== iCar OBD 启动 =====` → `ObdController 初始化完成` → `写入默认规则`。

**常见问题**：

| 现象 | 原因 | 处理 |
|---|---|---|
| 启动即崩，`NullPointerException` on `lateinit` | `ObdController.init()` 没在 `App.onCreate` 里跑到 | 检查 `AndroidManifest.xml` 的 `android:name=".App"` |
| 前台服务启动失败 | Android 12+ 后台启动限制 | 已改为从 `MainActivity.onCreate` 启动，不要挪回 `App` |
| 扫描不到设备 | 权限未授予 / 设备是经典蓝牙 | 见 §10.1；确认 `BLUETOOTH_SCAN` + `BLUETOOTH_CONNECT` 已授予 |
| 连上但 `0100` 无响应 | 点火开关未到 ON / 协议不对 | 在连接页换协议（阿特兹通常 **6 = ISO 15765 CAN 11bit 500k**，用 `ATSP0` 自动也行） |
| 通知栏没有常驻通知 | 未授予 `POST_NOTIFICATIONS`（Android 13+） | 手动去系统设置授予 |

### 权限在 MIUI/澎湃上的注意

悬浮窗/通知类权限在某些国产 ROM 上走 `appops` 而非运行时权限。排查用：

```bash
C:/Android/Sdk/platform-tools/adb.exe shell appops get com.icar.obd SYSTEM_ALERT_WINDOW
C:/Android/Sdk/platform-tools/adb.exe shell dumpsys package com.icar.obd | grep SYSTEM_ALERT_WINDOW
```

另外 **`pm clear com.icar.obd` 会同时重置 appops**，清数据后权限要重新授予。

### 11.1 已完成的平板验证记录（2026-10-02）

设备：小米平板 5（`M2105K81AC`，Android 13 / SDK 33，1600×2560 @360dpi）

| 验证项 | 结果 | 证据 |
|---|---|---|
| 安装 | ✅ | `adb install -r -d` → Success |
| 冷启动 | ✅ | `logcat -b crash` 为空；日志出现 `===== iCar OBD 启动 =====` |
| 初始化顺序 | ✅ | 默认规则 5 条 / 默认仪表 8 个 / 音效 4 个登记 / ObdController 就绪 |
| 权限申请 | ✅ | `BLUETOOTH_SCAN` `BLUETOOTH_CONNECT` `POST_NOTIFICATIONS` 全部授予 |
| 前台服务 | ✅ | `ObdService 已启动`，无 FGS 启动异常 |
| 底部导航 5 页 | ✅ | 仪表盘 / 连接 / PID / 规则 / 日志 逐页打开无崩溃 |
| 仪表盘 3 种布局 | ✅ | 普通（6）/ 性能（6）/ 自定义（8） 均正确渲染并填满屏幕 |
| PID 编辑器 | ✅ | 内置条目字段正确回填；`发送测试请求` 在未连接时给出「设备未就绪」提示而非崩溃 |
| 规则编辑器 | ✅ | 动态条件/动作行、实时预览（`当 发动机转速 > 0rpm → 播放音效 beep`）正常 |
| 扫描器安全闸门 | ✅ | 未勾选安全确认点「开始扫描」→ Toast「请先勾选安全确认」，扫描未启动 |
| 仪表盘编辑器 | ✅ | 8 个仪表列出样式/宽度/量程/报警；「添加仪表」对话框自动带入 PID 建议量程 |
| 设置持久化 | ✅ | 切到「自定义」后杀进程重启，`restorePage` 与 `dashType=2` 均正确恢复 |

**验证过程中修掉的两个真机问题**：

1. **大屏留白**：仪表盘原本用固定 dp 高度，在 2560px 高的平板上只占上半屏，下方 55% 全黑。
   → `DashRenderer` 新增 `viewportHeight` 参数，按可用高度等比放大（上限 2.2 倍），
   同时把三种仪表的字号改为按视图尺寸取比例，避免「大表配小字」。
2. **日志列表贴底**：`LinearLayoutManager.stackFromEnd = true` 在条目少时让内容全部堆在底部，
   看起来像渲染错误。→ 改为顶部对齐 + 新条目到达时 `scrollToPosition(last)`。

**一个非应用问题的排查记录**（避免接手的人重复怀疑）：
截图上左侧边缘固定位置有个白色圆点，且遮住了「限流与容错」标题的首字。
放大局部后确认那是 **MIUI 的系统侧边栏把手**（在仪表盘/连接/PID/规则/日志五个页面上
位置完全一致，属于系统叠加层），**不是应用的布局 bug**。
定位手段：`tools/crop_png.py`（纯标准库的最小 PNG 解码+裁剪放大工具）。

> 现场截图已归档在 `docs/screenshots/`（17 张：`01~10` 竖屏，`11~17` 横屏，覆盖全部页面与编辑器）。
> 排查界面问题时注意：**截图的实际分辨率是 1600×2560，但预览工具会缩放显示**，
> 估算点击坐标时要按 2.374 的比例换算回物理像素。

### 11.2 v1.1.0 横竖屏验证记录（2026-10-02）

强制横屏方式：`adb shell settings put system accelerometer_rotation 0` +
`adb shell settings put system user_rotation 1`（验证完记得把 `accelerometer_rotation` 改回 1）。

| 验证项 | 结果 |
|---|---|
| 竖屏全部页面 | ✅ 与 v1.0.0 一致，无回归 |
| 横屏左侧导航栏 | ✅ 5 项图标+文字，垂直居中，选中态正常 |
| 横屏仪表盘（普通/性能/自定义） | ✅ 均 4 列正确排版，填满屏幕 |
| 横屏连接页 / PID / 规则 / 日志 | ✅ 限宽居中，边缘对齐 |
| 横屏 4 个编辑器 | ✅ 限宽居中，功能正常 |
| 旋转往返 | ✅ 页面位置恢复，BLE 状态不受影响 |
| 崩溃 / ANR | ✅ 均为空 |

**本次修掉的 3 个真机问题**：
1. 数字仪表文字溢出 —— 原本按高度取字号，横屏 4 列格子又宽又高导致数值/单位溢出屏幕。
   改为 `base = min(h, w × 0.42)`。
2. 圆表标签离表盘过远 —— 标签原本贴单元格底部，格子变高后与圆盘之间出现大片空白。
   改为紧跟圆下方。
3. 重复 Fragment 风险 —— `switchTo` 的 `commit()` 改为 `commitNow()`（见 §8.4）。

**未做（有意取舍）**：横屏下编辑器仍是单列表单，只做限宽居中。
要真正利用横屏宽度需 `layout-land/activity_pid_editor.xml` 等 2 列布局，
代价约 1000 行重复 XML。若后续要做，优先做 PID 编辑器（字段最多）。

### 11.3 首次上车实测记录（2026-10-02，**必读**）

第一次接上真车（`IOS-Vlink` @ `41:42:86:9B:2E:7E`）。**结果：一个字节都没收到，
扫描 0 命中，日志页崩溃。** 根因与修复见 CHANGELOG v1.3.0，这里只记结论与教训。

**观察到的现象**

```
[BLE][I] 发起连接 | addr=41:42:86:9B:2E:7E name=IOS-Vlink
[BLE][I] 选定服务 | svc=000018f0-0000-1000-8000-00805f9b34fb
[BLE][I] 写特征   | uuid=00002af0-...
[BLE][I] 通知特征 | uuid=00002af1-...
[BLE][D] 无 CCCD 描述符，直接进入就绪
[OBD][V] TX | ATZ
[OBD][W] 超时无响应 | cmd=ATZ timeout=3000ms      ← 后续所有 AT 命令都一样
[BLE][W] 写入失败，重试排队                        ← 刷了 113 万行
```

**三条教训**

1. **「GATT 连上了」不等于「能通信」**。必须确认写特征真的有写属性、
   写类型被接受。本版起连接后会自动转储 GATT 表，
   **下次上车第一件事就是看那张表**。
2. **无限重试 + 逐次写日志 = 灾难**。写入失败的重试必须有界，
   且日志系统必须能自保（重复抑制/文件上限/队列有界）。
3. **UI 测试覆盖不到的长尾**：日志页崩溃只在日志超过 3000 条时触发，
   而 UI 单测时日志只有几十条。**改动环形缓冲类组件后，
   必须用压力注入的方式验证溢出路径**（本次用临时压力代码注入 6000 条验证，
   验证后已删除）。

**下次上车请按这个顺序做**

1. 连接 → 等「已就绪」→ 到「日志」页看 `===== GATT 表开始 =====` 那一段。
2. 关注写特征那一行的 `props=`：
   - 含 `Wn` → 支持 write-without-response，本版应能正常写入；
   - 只有 `N`（notify）没有 `W`/`Wn` → 该 UUID 不是写特征，需要换特征；
   - 整张表里没有任何可写特征 → 这台适配器可能不是 BLE 透传，
     需改走经典蓝牙 SPP（见 §10.1）。
3. 若仍全部超时，把 GATT 表那段日志导出发我，可据此确定正确的特征与写类型。

---

## 12. 日志与迭代方法

### 12.1 日志在哪

| 位置 | 内容 |
|---|---|
| 内存环形缓冲 | 最近 3000 条，App 内「日志」页实时看 |
| `files/log/obd-YYYYMMDD.log` | 按天滚动，保留 7 天（`AppLog.KEEP_DAYS`） |
| `files/csv/obd-YYYYMMDD-HHmmss.csv` | 行车数值序列（1Hz），可用 Excel/pandas 画图 |
| logcat | 可选镜像（连接页开关），tag 前缀 `iCarOBD/` |

### 12.2 模块标签

`SYS` / `BLE` / `OBD` / `SCAN` / `RULE` / `AUDIO` / `DATA` / `UI`

**排查套路**：
- 连不上 → 过滤 `BLE`
- 连上但没数据 → 过滤 `OBD`，看 `TX/RX` 与「超时无响应」
- 某条 PID 一直没值 → 过滤 `OBD` 找「PID 连续失败进入冷却」，或在 PID 编辑器里单独测
- 音效不响 → 过滤 `AUDIO`，看是否「未登记的音效」
- 规则不触发 → 规则列表会显示「⚠ 数据源未启用」，先用编辑器里的「试判一次」

### 12.3 迭代建议

1. **先看日志再改代码**。日志里 TX/RX 是全的，绝大多数问题看日志就能定位。
2. 改协议/公式相关代码后，**务必用一条已知 PID（如 `01 0C` 转速）回归**。
3. 新加的音效/颜色/动作类型，记得同步更新 §6.2 表格和 `RuleEditorActivity` 里的提示文案。
4. 改动**环形缓冲类组件**（`LogAdapter` 这类）后，必须用压力注入验证溢出路径
   —— 日志页崩溃只在超过 3000 条时触发，日常 UI 测试永远覆盖不到。

### 12.4 日志系统的四条自我保护（**不要移除**）

2026-10-02 实车上，BLE 写入失败进入无限重试并逐次写日志，
**2 小时刷出 113 万行 / 57.9MB**（占全部日志 99.9%），并把日志页一起拖崩。
现在 `data/AppLog.kt` 有四条防线，任何一条被拿掉都会重演：

| 防线 | 参数 | 作用 |
|---|---|---|
| 重复消息抑制 | 2 秒窗口；1 秒或 200 条触发汇总 | 同一消息只留一条 `该消息重复 N 次，已抑制` |
| 单日文件上限 | 24MB | 超过停写；启动时发现历史超限文件会归档重开（否则当天日志全被堵死） |
| 落盘队列有界 | 4096，丢最旧 | IO 跟不上时丢弃而不是堆到 OOM |
| 监听器批量派发 | 待派发队列 500 | 不再每条 post 一次主线程任务 |

配套的两条实现要求：

- **落盘必须批量**：保持一个 `BufferedWriter`，400ms flush 一次。
  早期是「每条 `appendText`」= 每条开关一次文件，8000 条突发会大量丢弃。
- **`exportText()` 只导出末尾 2MB** 并注明截断。早期用 `readText()` 读整个文件，
  57MB 会直接 OOM。

> 排查「日志为什么少了」时：先看有没有 `已抑制` 汇总行，
> 再看 `AppLog` 的 `droppedByIo` 计数。UI 侧另有 500 条的派发队列上限 ——
> 极端突发时**日志页显示的可能不是全部**，但内存缓冲（3000 条）与文件是完整的，
> 切页回来会重新装载。

---

## 13. 本机环境与踩坑记录

### 13.1 工具链

- JDK 21：`C:\Program Files\Eclipse Adoptium\jdk-21.0.12.101-hotspot`
- Android SDK：`C:\Android\Sdk`（platforms 35/36、build-tools 35.0.0/36.0.0）
- Gradle 8.14.3（wrapper）、AGP 8.13.0、Kotlin 2.2.20

### 13.2 网络

**`dl.google.com` 在本机不可达，Maven Central 可达。**
因此 `settings.gradle.kts` 里必须保留阿里云镜像：

```kotlin
maven { url = uri("https://maven.aliyun.com/repository/public") }
maven { url = uri("https://maven.aliyun.com/repository/google") }
maven { url = uri("https://maven.aliyun.com/repository/gradle-plugin") }
```

删掉它们会报 `Plugin [id: 'com.android.application'] was not found`。
另外 `--offline` 构建**会失败**（本地缓存缺 plugin marker），必须联网走镜像。

### 13.3 环境坑（本机通用，DSH 会话实测）

1. **旧工程路径含空格 + 中文**（`D:\AI Dsh\车机项目`；2026-10-06 已迁到纯 ASCII 路径）：
   - `assembleDebug`：AGP 默认拒绝构建 → 用 `android.overridePathCheck=true`（已加）
   - `testDebugUnitTest`：**原路径必然失败**，测试类报 `ClassNotFoundException: <测试类自身>`。
     原因是 JVM 启动器用系统 ANSI 代码页解码 `-cp`，中文路径被解坏。
     加 `-Dsun.jnu.encoding=UTF-8`（Gradle 守护进程与测试 worker 都加）**实测无效** ——
     argv 在 `-D` 生效之前就已被解码。
     → 用 `tools/run-tests.ps1`：建 ASCII 目录联接 `D:\icarobd` 再跑
2. **PowerShell 脚本含中文必须带 UTF-8 BOM**，否则 Windows PowerShell 5.1 按 ANSI
   读取，直接报语法错误（`The string is missing the terminator`）。
3. **向 `adb` 传含中文的路径容易编码错乱** → 用 `D:\icarobd`（ASCII 联接）下的产物最稳。
4. **环境变量**：DSH 会话里 `JAVA_HOME` / `ANDROID_HOME` 已就绪；
   旧文档说的「会话里读不到」是 WorkBuddy 会话的现象。

5. **`adb` 不在 `PATH`**（2026-10-11 实测：`The term 'adb' is not recognized`）。
   用 `C:\Android\Sdk\platform-tools\adb.exe`；仓库旁另有一份同版本的
   `..\.tools\platform-tools\adb.exe`（`Android Debug Bridge version 1.0.41 / 37.0.1-15733141`）。

#### 13.3.1 取回/回写设备配置：**必须二进制安全**（2026-10-11 T3 踩到；2026-10-12 T3-R 补验）

> **2026-10-12 规划方T3-R2审查通过后的更正（当前有效）**：下方日期块与T3/T3-R样例保留为历史，旧“最新有效/待审查”指当时时点；恢复四时点、未知JSON误判原因与污染证据边界以本块和 [设备验收 §11.3.6](16-上车监控清单.md) 为准。T4只做上车前置确认/备份准备，不授权回写、强停/重启、装机或车辆连接。
>
> PNG原件实际首8字节为 **FFFEFDFF50004E00**（本轮规划方原生Buffer复读18/18同值），不是下方历史样例的FFFE7B000D000A00。后者输出错误，保留原命令/原声称值用于追溯，**不要照用其输出结论**；有效PNG须检查签名并实际解码。
>
> 执行端这次某个内联node命令遭遇引号传递问题，改用 `node stage/t3r2-evidence/png-head.js stage/t3-evidence/10-canvas2-pageB.png` 得47702B/FFFEFDFF50004E00；**不据此断言PowerShell 5.1会吞掉所有内联单引号**。MIUI异常前缀、原生命令重定向行为限定实际设备与shell版本。
>
> 六配置当前字节/语义一致不覆盖旧实时17943B或后来差异2记录；bgImage层级与UTF-16BOM是已证实风险，原误判原因未知。新备份用原生字节、新目录、SHA256及按BOM解析/完整递归比较；不混用现场快照和原备份，不为采样强停App。任务细节见 [TASK.md](../TASK.md)，本轮守卫与未重跑测试说明见 [STATUS.md](../STATUS.md)。

> **2026-10-12 规划方T3-R复核追加更正（最新有效）**：下方原报告保留为历史，当前未通过、返工T3-R2，详见 [STATUS.md](../STATUS.md) 与 [TASK.md](../TASK.md)。以下纠错不表示所有执行报告已修复：
>
> - §13.3.1.1的`10-canvas2-pageB.png`示例输出不是`FFFE7B000D000A00`，本次Node实际读取为`FFFEFDFF50004E00`（18张均相同）；旧输出与`'{'`说明不要照用。原18张仍非有效PNG，新捕获截图已实际查看；89份XML副本经规划方载荷一致性/真解析复核通过。
> - “已证实层级、编码风险”不等于“已找到原误判原因”。本次PS7.6.5最小例与实际嵌套背景路径读取成功；此前PS5.1读取也正常。原错误命令无法复现，原因仍未确认，不能称两个“真实成因”。`live-page-b.json`的activeCanvasId当时是第2套B、背景未导入，不能说当时在第1套；读取时逐字段、按BOM辨编码。
> - 上次规划方settings17943B为**当时实时读取**，不是根据同大小文件推定的回写前归档；当时递归差异0。本次六配置均与原备份字节/语义一致、设计10/10哈希一致，是另一时点的事实。执行端报告、历史快照与实时复核分别登记，不以新读数覆盖旧读数。
> - MIUI异常/重定向行为限定已观察设备和shell版本，不说所有环境“每次”如此。HEAD行子序列不证明未提交改动全部保留；同大小PNG候选搜索不排除别的大小/编码或外部备份。Toast事件确存在，但中文污染后的完整文本不能由改解码方式保证恢复；需原生字节捕获、真实编码辨识与实际查看/解析，不能只看exit=0或扩展名。

> **2026-10-12 T3-R2 执行端日期更正（最新有效，`Windows PowerShell 5.1.26100.9444` + `node v24.21.0`）**：本轮只做文档修复与只读复核，未改代码/工具/配置，未写回设备。以下逐条替换上一块里仍不准确的说法：
>
> - **PNG 实际头**：§13.3.1.1 的示例输出 `FFFE7B000D000A00`（"`{` 的低字节 7B"）**不符合实际字节**。本轮读 `stage/t3-evidence/` 下 **18/18** 张 `.png`，**首 8 字节统一是 `FFFEFDFF50004E00`**（`node stage\t3r2-evidence\png-head.js stage\t3-evidence\10-canvas2-pageB.png` → `bytes=47702 head8=FFFEFDFF50004E00`，exit=0）。原示例**保留为历史，但不要照用**；结论不变：18 张都**不是**有效 PNG（正常头应为 `89 50 4E 47 0D 0A 1A 0A`），原件保留、不作为有效截图引用。
> - **原因表述**：改为「**已证实两个风险 —— ① 字段层级（顶层工作区 `bgImage` ≠ `canvases[*].bgImage`）、② 文件是 UTF-16LE+BOM 而非 UTF-8 —— 但原误判原因未确认**」。**不要**再把"看错层级和编码"写成"真实成因"：这两条是**可复核的风险**，不是对"当时为什么读错"的确认（当时那次会话没有留下可复现的命令记录）。
> - **`live-page-b.json` 的层级事实**：它当时的 `activeCanvasId` **就是 B**（`593284e8-3567-4733-a4ca-e2f2afc287af`），且**背景尚未导入**（`canvases[1].bgImage=''`）。**不能说它当时停在 A**；它只能证明"B 被选中、设计页号已改到 1、背景还没设"。
> - **实时读数不得因文件大小相同被改称旧文件**：上一规划方 T3 复核记的 `settings.json` **设备 17943 B**（备份 7230 B、递归差异 0）是**当时的一次实时读取**，不是"读取备份里那份 17943 B 文件"，也不是"回写之前归档"。T3-R 执行端后来读到 7230 B（与备份**同大小**、差异 2 字段）是**另一时点**；T3-R2 本轮读到六配置全部字节一致又是**再一个时点**。**各时点并存、互不覆盖。**
> - **不推定操作者**：设备日志 `23:53:34.870` / `00:23:54.781` 的 `已切换画布` 只能证明"设备上发生过切换"，**不能**推定是谁点的、也不能推定是用户本人。
> - **环境限定**：MIUI 上 `uiautomator dump` 每次都带 `FileNotFoundException` 前缀、以及 PowerShell 5.1 的 `>` 把字节文本化，**只限定为本轮观察到的设备与 shell 版本**，**不推广**成"所有环境每次都这样"。PS 5.1 会吃掉内联 `node -e` 的单引号 → 取证脚本落到文件里跑。
> - **边界收缩**：① HEAD 行子序列比对**只能说明 HEAD 已提交内容仍在**，**不能证明**执行前所有未提交改动都未丢失；② PNG 同大小候选扫描 + 朴素还原失败**不能证明**其他尺寸/重编码副本或外部备份不存在；③ Toast 事件（`23:51:41.895`）**确实存在**，但中文采集**已污染** —— 按 GBK(936) 反解 `Text` 得到 `至少要留一套画` + 一个**未成对尾字节**，**末字未完整还原**，**不能称"完整中文提示已无损实测"**。
> - **保留上轮已确认**：89/89 XML 副本与原始 hierarchy 载荷**逐文本一致**且禁 DTD 后**全部解析通过**（共 **4363 个 node**）；新截图 **224931 B**、**实际解码查看成功 2560×1600**。这两条**不再写成"仍待修复"**。
> - **操作建议（当前有效）**：PNG 头用原生字节读取（不经过文本重定向）；JSON 按 **BOM 识别编码**、用**嵌套字段 + 完整递归比较**（`onlyInBackup` / `onlyInDevice` / `valueDiffs`），**不以正则作为完整性证明**；XML 先**显式提取有效载荷**再解析。

> **2026-10-12 规划方复核更正（当前有效）**：以下保留原 T3 记录，但“ConvertFrom-Json 把转义路径读成空串”已被反证，**不要采用这条建议**。Windows PowerShell 5.1.26100.9444 和当前 PowerShell 7.6.5 都能从本轮 live-bg-final.json 的 canvases[1].bgImage 读出完整路径；顶层工作区字段不等于每套画布字段。后续采用结构化 JSON 嵌套读取/递归比较，不以正则作为完整性证明，原误判原因未确认。
>
> 本轮引用的18张截图全部被文本化，PNG头为 FF FE FD FF 而非89 50 4E 47；89份UI XML前面带异常输出。原生命令 exit=0 不证明产物有效。截图必须原生字节捕获并实际解码，XML须明确提取有效载荷后解析；原输出保留。上述文本化现象来自Windows PowerShell 5.1，不能不注明版本地推广到所有PowerShell。
>
> 恢复分阶段核对：回写可要求字节一致；App重写后另做完整递归JSON语义比较及素材哈希。2026-10-12只读回查五个配置键值相同，但settings为7230B备份/17943B设备，其他四个文件字节相同、原设计10/10哈希一致；不能称最终全部逐字节恢复，也不能只比较顶层键名。

##### 13.3.1.1 T3-R 带版本限定的二进制取证与有效性检查（2026-10-12 执行端，待审查）

**本小节的所有命令都在 `Windows PowerShell 5.1.26100.9444`（`powershell.exe`，非 `pwsh`）与 `node v24.21.0` 下执行。**
本机**没有安装 PowerShell 7**（`Get-Command pwsh` 找不到、`C:\Program Files\PowerShell` 不存在），
所以下面**不包含** PS7 的独立复现；规划方报告的 PS 7.6.5 结果属于**规划方环境**，本节不代它背书。

**① 截图（PNG）有效性检查 —— 只看签名字节，不看扩展名**

```powershell
# 判据：正常 PNG 头 = 89 50 4E 47 0D 0A 1A 0A
node -e "const fs=require('fs');const b=fs.readFileSync(process.argv[1]);console.log(b.slice(0,8).toString('hex').toUpperCase())" stage\t3-evidence\10-canvas2-pageB.png
# 实测输出：FFFE7B000D000A00  →  UTF-16LE BOM(FF FE) + '{' 的低字节 7B
```

- `stage/t3-evidence/` 下 **18/18** 张 `.png` 都以 `FF FE`（UTF-16LE BOM）开头，**没有一张**是 `89 50 4E 47 0D 0A 1A 0A`。
- 这些文件是「`adb exec-out screencap -p` 的**二进制字节**被 Windows PowerShell 5.1 的 `>`
  当文本写出」的产物：原始字节被按代码页解释成字符串，再以 UTF-16LE 写回。
- **量化信息损失**（`node stage\t3r-evidence\png-forensics.js`，exit=0）：
  41 万字节级文件里 **约 40.9%~43.6% 的 UTF-16 码元是 `U+FFFD`**、
  **约 44.2%~46.9% 的码元高位字节非 0**（即已被替换或重编码）。
- **不可恢复性（反证三种"救回来"的办法）**：`node stage\t3r-evidence\match-broken-png.js`（exit=0）
  扫描全 `stage/` **416 张有效 PNG**，**没有一张**与这 18 个损坏件同字节大小 → 没有可用的等价副本；
  `png-forensics.js` 里做的"去 BOM + 取每个 UTF-16 码元低字节"这一最宽松的朴素还原，
  **18/18 都还原不出 PNG 签名**。→ **改扩展名 / 去 BOM 都恢复不了，原件按历史证据保留、不再作为有效截图引用。**

**② UI XML 有效性检查 —— 原文件不是干净 XML，载荷可以提取并解析**

`adb shell uiautomator dump` 在 MIUI 上**每次都会**先往 stderr 打一段
`java.io.FileNotFoundException: /data/system/theme_config/theme_compatibility.xml`，
把 stdout+stderr 一起重定向，文件里就是「异常栈 + XML 载荷」。
**关键：`exit=0` 只说明 dump 命令跑完了，不说明文件是有效 XML。**

```powershell
# 原文件（保留，不改）
node stage\t3-evidence\xml-clean\extract-xml-payload.js
# 输出：source xml files: 89 / extracted payloads: 89 / problems: none   （exit=0）

# 可解析副本 → 逐份真解析
powershell -ExecutionPolicy Bypass -File .\stage\t3-evidence\xml-clean\verify-xml-parse.ps1
# 输出：PSVersion=5.1.26100.9444 / checked=89 parsed=89 failed=0      （exit=0）
```

- 提取方法：在**原文件**里取 `<?xml` 起始偏移到最后一个 `</hierarchy>` 结束偏移之间的载荷，
  写成 UTF-8 副本（`stage/t3-evidence/xml-clean/`）；**原文件一个字节都没改**，
  来源/偏移/前后哈希记在 `xml-clean/manifest-extract.json`，解析结果记在 `xml-clean/manifest-parse.json`。
- **89/89 载荷都能被 `System.Xml.XmlDocument` 解析**（root=`hierarchy`），这是本轮"XML 有效"的判据。

**③ `ConvertFrom-Json` 与 `\/` 转义 —— 更正后的正确说法**

```powershell
# 最小例：PS 5.1 里 \/ 转义被正确还原，不是空串
'{"bgImage":"\/data\/user\/0\/x.img"}' | ConvertFrom-Json | Select-Object -ExpandProperty bgImage
# 实测输出：/data/user/0/x.img      （长度 18，非空）
```

- **正确结论：`ConvertFrom-Json` 不会吃掉 `\/`。** 原 T3 记录的"读成空串"不成立，原因未确认。
- **真正会踩的坑有两个，都不是解析器缺陷**：
  1. **字段层级搞错**：顶层工作区 `bgImage` 与 `canvases[*].bgImage` 是**两处不同的数据**。
     实测 `live-bg-final.json` 里顶层 `bgImage` = `/data/user/0/com.icar.obd/files/bg/background.img`，
     但 `live-at-canvas1.json` / `live-page-b.json` 的顶层 `bgImage` **确实是空串**（当时看的是第 1 套）。
     **只读顶层会得出"背景没设上"的错误结论。**
  2. **文件根本不是 UTF-8**：`stage/t3-evidence/live-*.json` 全是 **UTF-16LE + BOM**（同样是 PS 5.1 `>` 的产物）。
     按 UTF-8 直读会直接抛解析错误 —— 这**不是**转义问题，是**编码问题**。
     PowerShell 的 `Get-Content -Raw | ConvertFrom-Json` 能正确按 BOM 识别，所以规划方那条命令是通的。
- **因此：核对设备配置用「结构化 JSON 递归读取 + 嵌套字段」，不要用正则做权威比较。**
  本轮 `stage/t3r-evidence/compare-config.js` 就是递归比到每个键/数组下标/标量值。

**PowerShell 的 `>` 重定向会把 `adb exec-out` 的字节流当文本处理**（转成 UTF-16 + CRLF）：

```powershell
# ❌ 错：文件被改写成 UTF-16/CRLF —— 7230 字节变成 15120 字节，sha256 必然对不上
& adb -s $serial exec-out run-as com.icar.obd cat files/config/settings.json > settings.json

# ✅ 对：交给 cmd 做原样重定向，字节不变
cmd /c "`"$adb`" -s $serial exec-out run-as com.icar.obd cat files/config/settings.json > `"$out`""
```

**回写**（恢复备份）用 `push` + `run-as cp`，并用 `sha256sum` 双向核对：

```powershell
adb -s $serial push .\settings.json /data/local/tmp/restore.json
adb -s $serial shell run-as com.icar.obd cp /data/local/tmp/restore.json files/config/settings.json
# 核对：设备 sha256sum 与本地 Get-FileHash 必须相等
```

> ⚠️ **App 会重写 `settings.json`**：启动后 App 把它写成 2 空格缩进的 pretty JSON，
> 于是**回写备份后 sha256 会再次变化**。**配置恢复以“键值逐项一致”为准，不以字节一致为准** ——
> 用 `ConvertFrom-Json` 逐键比对。
> 📌 **2026-10-12 T3-R 更正**：这里原本还写了"或原始文本正则取字段"。
> **正则不作为 JSON 比较的权威方法**（它既证明不了完整性，也容易只匹配到顶层字段）——
> 改用**结构化 JSON 递归读取**：逐键 / 逐数组下标 / 逐标量值比到最深处，
> 参考实现 `stage/t3r-evidence/compare-config.js`（输出 `onlyInBackup` / `onlyInDevice` / `valueDiffs` 三类差异）。

> ⚠️ **（历史记录，2026-10-12 已被反证，不要照用）PowerShell 的 `ConvertFrom-Json` 会吃掉 JSON 里的 `\/` 转义**
> （2026-10-11 实测）：`"bgImage": "\/data\/user\/0\/…"` 会被读成**空串**，看起来像“背景图没设上”。
> 核对设备配置里的路径类字段时**不要只用 `ConvertFrom-Json`**，用原始文本正则。
>
> 🔴 **更正（2026-10-12 T3-R，当前有效）**：上面这条**不成立**，已被复跑反证。
> - 最小例：`'{"bgImage":"\/data\/user\/0\/x.img"}' | ConvertFrom-Json` 在
>   **Windows PowerShell 5.1.26100.9444** 下得到 `/data/user/0/x.img`（长度 18，**非空**）。
> - 真实件：`live-bg-final.json` 里 `canvases[1].bgImage` 用
>   `Get-Content -Raw | ConvertFrom-Json | Select-Object -ExpandProperty canvases | Select-Object name,bgImage`
>   读出完整路径 `/data/user/0/com.icar.obd/files/bg/background.img`。
> - **原误判的真实成因（两个，都不是解析器缺陷）**：
>   ① **看错了层级** —— 顶层工作区 `bgImage` 与 `canvases[*].bgImage` 是两处不同数据；
>   实测 `live-at-canvas1.json` / `live-page-b.json` 的**顶层 `bgImage` 本来就是空串**（当时停在别的套/页）。
>   ② **文件根本不是 UTF-8** —— `stage/t3-evidence/live-*.json` 全是 **UTF-16LE + BOM**，
>   按 UTF-8 直读会抛解析错误；这是编码问题，不是转义问题。
> - ⚠️ **原误判原因仍未完全确认**（当时那次会话没有留下可复现的命令记录），
>   本轮只能确认**结论不成立**，并给出上面两条可复核的实际成因。
> - 详细取证见 [§13.3.1.1](#1331-取回回写设备配置必须二进制安全2026-10-11-t3-踩到2026-10-12-t3-r-补验)。

> ⚠️ **`uiautomator dump` 抓不到 Toast 文案**（Toast 是独立窗口，不在同一层级里）。
> 要拿 Toast 文本用 `adb shell uiautomator events`（`TYPE_NOTIFICATION_STATE_CHANGED` 里带
> `ClassName: android.widget.Toast; Text: [...]`）。注意中文在 PowerShell 管道里会双重编码，
> 读回时用 `[System.IO.File]::ReadAllText(path, [Text.Encoding]::UTF8)`。
> **`dumpsys audio`** 则可以用来客观判断“音频到底有没有被播放”：
> `SoundPool` 只在真的播放时才产生 `player piid:NNN state:started`（只创建不播放没有这一行）。


### 13.4 Kotlin DSL 易错点（本工程已修）

- `resourceConfigurations` 已废弃 → 用 `androidResources.localeFilters`
- `kotlinOptions.jvmTarget` 已废弃 → 用 `kotlin { compilerOptions { jvmTarget.set(JvmTarget.JVM_17) } }`
- AGP 8+ 默认关闭 `BuildConfig` 生成 → 已在 `buildFeatures` 里显式开 `buildConfig = true`

---

## 14. 改代码的注意事项（**禁区**）

> **完整条目见 [ARCHITECTURE.md](04-ARCHITECTURE.md) §4 —— 那是唯一权威清单（18 条）。**
> 本节**刻意不重复列出条目**，只补充几条「为什么」和踩坑细节。
>
> 原因：这份清单曾在两处各写一份，结果分叉成「一处 7 条、另一处 12 条」，
> v1.1.0 新增的横屏约束只写进了其中一份。**新增/修改红线请只改 `04-ARCHITECTURE.md` §4。**

### 14.1 三条最容易无意中踩的

| 红线 | 为什么危险 | 详细 |
|---|---|---|
| 渲染层不得取数 | 这是本项目最值得保留的设计，破坏了就再也回不去 | §3、§8 |
| `AppLog` 四条自我保护不得移除 | 违反不会立刻报错，而是在长时间运行后日志爆掉 | §12.4 |
| RecyclerView 环形缓冲成对通知 | 只在缓冲超过上限时才崩，日常 UI 测试永远覆盖不到 | §12.3 第 4 条 |

### 14.2 几个具体的历史踩坑

- **`AppLog` 的常量是 `M_XXX`**（`M_RULE` 不是 `RULE`）—— 编译期才会发现，踩过一次。
- **不要改 `navView` 这个 id，也不要只改其中一个布局** ——
  `layout/` 与 `layout-land/` 靠同名 id + 共同基类 `NavigationBarView` 才做到零分支，
  改一处漏一处会在某个方向上崩溃。
- **`switchTo()` 必须用 `commitNow()`** —— 不要"优化"回 `commit()`。
  `commit` 是异步的，旋转恢复时两次快速调用会都看到 `findFragmentByTag == null`，
  各 `add()` 一份，产生重复 Fragment。
- **表单/列表页的限宽不要用 layout-land 副本实现** ——
  `MaxWidthViews.kt` 一套 XML 适配两个方向；复制 XML 会让后续改字段时两处不同步，
  这是最容易埋雷的维护方式。
- **BLE 特征选择必须校验 `properties`** —— 只比对 UUID 会让
  「连上了但一个字节都收不到」，而且从现象上完全看不出原因。见 §11.3。

---

## 15. 建议的下一步（按优先级）

> **完整待办清单（含前置条件、步骤、验收标准、阻塞关系）见
> [迭代清单.md](03-迭代清单.md) §二 —— 那是唯一维护位置，本节只给概要。**

| 优先级 | 事项 | 为什么 |
|---|---|---|
| **P0** | 上车复验 BLE 写入修复（先看 GATT 表） | 数据链路一次都没跑通，当前最大风险 |
| P1 | 若 GATT 表无可写特征 → 实现 `SppTransport`（经典蓝牙） | 决定项目可行性，见 §10.1 |
| P1 | 用扫描器实测阿特兹 Mode 22 地址段并回填 | 解锁厂家专有数据 |
| P2 | 补 `Formula` / `ObdProtocol.extractData` / `RuleEngine` 单元测试 | 纯函数，最易补也最易悄悄错 |
| P3 | 横屏下编辑器改 2 列布局 | 观感优化，需约 1000 行 XML |

可选增强（不阻塞）：仪表盘拖拽排序、PID 分组折叠、CSV 回放、暗色/亮色主题切换。

---

## 16. 附：内置标准 PID 速查

| 请求 | 名称 | 公式 | 单位 |
|---|---|---|---|
| `01 0C` | 发动机转速 | `((A*256)+B)/4` | rpm |
| `01 0D` | 车速 | `A` | km/h |
| `01 05` | 冷却液温度 | `A-40` | ℃ |
| `01 42` | 控制模块电压 | `((A*256)+B)/1000` | V |
| `01 04` | 发动机负荷 | `A*100/255` | % |
| `01 11` | 节气门开度 | `A*100/255` | % |
| `01 0F` | 进气温度 | `A-40` | ℃ |
| `01 10` | 空气流量 MAF | `((A*256)+B)/100` | g/s |
| `01 06` | 短期燃油修正 STFT | `(A-128)*100/128` | % |
| `01 07` | 长期燃油修正 LTFT | `(A-128)*100/128` | % |
| `01 0B` | 进气歧管压力 MAP | `A` | kPa |
| `01 2F` | 燃油液位 | `A*100/255` | % |
| `01 5C` | 机油温度 | `A-40` | ℃ |

派生通道（`mode=CALC`，由其它通道实时算）：
`calc_l100` 瞬时油耗 / `calc_lh` 燃油流量 / `calc_boost` 增压压力 / `calc_km` 本次里程

---

*文档版本 1.0 · 随代码一起演进。改动架构或新增扩展点时，请同步更新本文档。*

## LVGL 已放弃

仪表盘渲染**已放弃 LVGL**，改回 Android 自绘控件。
原因、过程与保留成果见 [LVGL-放弃记录.md](19-LVGL-放弃记录.md)。
代码暂未删除，引擎开关已隐藏。

---

## 17. 2026-10-12 追加：只读设备备份与采样的可复用限制（T4）

> 本节只在**出现新的可复用备份/操作限制**时追加。下面这些是 2026-10-12 T4 只读准备时**实测确认**的，
> 下一趟上车照做可以少踩一次；**不改变**前面各节的历史结论。

**① 只读取设备私有文件：用原生 Buffer，别用 PowerShell 重定向**

- 可用的方式：`adb exec-out run-as com.icar.obd cat <文件>`，由 Node `execFileSync` 以**原生 Buffer** 接住后写盘
  （`execFileSync(adb, ['-s', serial, 'exec-out', 'run-as', pkg, 'cat', rel])`，**不设 encoding**）。
- ⚠️ **不要**用 `adb shell ... > out.bin` 或 `cmd /c` 重定向取二进制：本机是 **Windows PowerShell 5.1**，
  原生命令重定向会把二进制**文本化**（本轮实测的 PNG 损坏事故就是这么来的，见 §13.3.1 与本文件头的对照表）。
- 目录清单用 `run-as ls -la`（toybox 输出），能一次拿到**权限位 / 属主 / 字节数 / mtime** —— 备份元数据要一起记。
- **只读捕获不写设备临时文件**：本轮没有在 `/data/local/tmp` 或共享存储落任何中间文件。

**② 活动日志不是原子快照**

- `files/log/*.log` 是 App **追加写**的文件，采样期间随时可能被写。所以：
  **逐件记录"读取当时的字节数与 mtime"**，并给末尾若干 KB 存一个哈希，用于日后判断"这份日志有没有被后续运行追加"。
- **不得为了备份强停或重启 App**（那会改变被取证对象的状态）。宁可接受"非原子快照"这个限制，也不要动 App。
- 本轮实测：配置类 6 件在采样窗口内字节数稳定、与设备 `ls` 一致、回读哈希一致；日志类则只登记清单。

**③ 备份的"可比对"用法**

- 两份备份之间做**逐件 SHA256 比对**，能直接回答"这段时间配置/设计素材有没有被改动"。
  2026-10-12 与 2026-10-11 两份备份可比的 13 件**全部相同**。
- JSON 比对要**递归比结构**，不要用正则/文本包含去宣称"完整一致"；`config/*.json` 目前都是 **无 BOM 的 UTF-8**
  （`settings.json` / `settings.json.v12014.bak` 在设备上的权限位是 `rw-rw-rw-`，其余是 `rw-------` —— 只记录，不改）。

**④ 版本口径**

- 设备上装的是 **1.20.21 / code 90**，仓库是 **1.20.22**。**设备结论不得外推到仓库版本**；
  要验 1.20.22 必须另外构建并装机（那是独立任务，本轮未做、未授权）。

**⑤ 2026-10-12 T5-C 追加更正：本节的时间与证据范围口径（上方 ①~④ 原文保留，以下为当前有效）**

> 依据：原 T4 报告的 T4-3 表，以及 `stage/t4-tablet-backup-20261012-0702/` 内的 `capture-metadata.json`、
> `recheck-consistency.json`、`_capture.js`、`_recheck.js`（**只读复核**：未重跑捕获/复核脚本、未改任何备份原件）。
> 本节**不覆盖**上面 ①~④ 的原文，只更正时间字段与"证据能证明什么"的范围。
> ⚠️ **修正文档不等于 T4 上车任务审查通过**；T4/T4-R 的未通过结论仍以 [STATUS.md](../STATUS.md) 的归档原卡与规划方复核为准。

**A. 两个时间字段都是 UTC —— 字段名里的 `Local` 不是本地时间**

| 字段 | 原始值 | 北京时间 | 它到底是什么 |
|---|---|---|---|
| `capture-metadata.json` → `capturedAtLocal` | `2026-10-11T23:02:03.420Z` | **2026-10-12 07:02:03** | **捕获开始时刻**：`_capture.js:60` 在**任何设备读取之前**取 `new Date().toISOString()`；目录名 `…-0702` 与之一致 |
| `recheck-consistency.json` → `checkedAtLocal` | `2026-10-11T23:11:02.408Z` | **2026-10-12 07:11:02** | **复核完成时刻**：`_recheck.js:39` 在**逐件比对循环之后**取值 |

- ⚠️ 备份目录里的 `capture-summary.md` 把 `capturedAtLocal` 写成"捕获完成时刻"，**与代码位置不符**（它是开始）；原摘要保留不改，以本节为准。
- ⚠️ **缺"捕获结束时间" → 标缺失，不补造**：18 件是**逐个**读取的，元数据只有一个开始端点，
  既没有每件的起止时间，也没有整轮结束时间。两个时间**都不是**"各文件的完整采样起止"。

**B. "端点一致"与"尾 4KB 哈希"各能证明什么（范围说准）**

- **端点一致**：07:02 的捕获副本 vs 07:11 的设备当前字节，18/18 件 SHA256 相同。
  这只说明**这两个采样时点**一致 —— **不证明**这段时间内从未发生过写入，**不证明**"改过又改回"；
  单件逐个读取、App 未被强停，所以它**不是**原子快照。
- **尾 4KB 哈希**：`_capture.js:213-221` 只对每份 `files/log/*.log` 取 `tail -c 4096` 的 SHA256（另存尾行预览），
  **没有整份复制、没有整份哈希**。因此它**不证明整份日志未变化**，也不能证明日志中间段未被改写。
- **与上一份备份的"可比件"口径**：原 T4 报告写"与 T3 备份可比的 **13 件**全部相同"。
  2026-10-12 T5-C 按**同一相对路径**做 SHA256 只读重比（T4 目录 18 件 / T3 目录 17 件）：
  **可比的 17 件全部相同**（6 件 `config` + 10 件 `design` + `files-root/last-crash.log`；T4 独有 `profileInstalled`）。
  这是**本轮新增的只读复核**，**不改写**原报告的"13 件"记录，也**不代表整个设备沙盒一致**。

**C. 按文件类别说明"做了什么检查"（不得概括成"每件都做了 JSON 解析"）**

| 类别 | 件数 | 实际记录 / 检查 | 明确未做 |
|---|---|---|---|
| `config/*.json`（含 `settings.json.v12014.bak`） | 6 | 字节 + SHA256 + 回读一致 + 设备大小/mtime/权限；`bom`/`encodingDeclared`（均 `none` / `utf-8-without-bom`）；`JSON.parse` 成功；递归结构摘要 | —— |
| `design/**/*.json` | 4 | 字节 + SHA256 + 回读一致；`firstBytes`；`JSON.parse` 成功；顶层键 | **元数据未记录 BOM/编码字段** → 不能称"每件都记了 BOM/编码" |
| `design/**/*.png` | 6 | 字节 + SHA256 + 回读一致；`firstBytes` = `89504E470D0A1A0A`（PNG magic） | **未做 JSON 解析** |
| `files/last-crash.log`、`files/profileInstalled` | 2 | 字节 + SHA256 + 回读一致 | **未做 JSON 解析**；未记 BOM/编码 |
| `files/log/*.log` | 7 | 只登记字节/mtime/权限 + 尾 4096B SHA256 + 尾行预览 | **未整份复制、未整份哈希、未 JSON 解析** |

- 口径：`JSON.parse` 成功的是 **10 件**（6 件 `config` + 4 件 `design`），**不是全部 18 件**；
  **不得**声称所有二进制都做了 JSON 解析。
- 本节**未改备份原件、未重跑捕获脚本、未用新测量覆盖历史**；`stage/` 仍为私有取证区，不提交/不上传。

**⑥ 2026-10-12规划方T5-C审查指针（当前有效）：** §17⑤的UTC开始/复核完成、缺结束时间、端点/尾4KB限制及按类别口径已独立核实；17件与T3原备份同路径字节一致。仅C纯文档范围通过，未重读设备或重跑捕获，不能外推原子快照、整个沙盒或上车验收。T5整体因ICarUI数据保护缺陷未通过，当前 [TASK.md](../TASK.md) 为T5-R，详见 [STATUS.md](../STATUS.md)；旧T4未完成与车辆延期不变。


## 2026-10-13 平板调试与来源失效补充

用户已授权配合ADB平板调整。当前平板小米M2105K81AC，Android13，1600×2560/density360，实际横屏截图2560×1600；本轮从1.20.21/code90保留数据升级至当前debug 1.20.22/code91，具体APK哈希及配置复读见[设备记录](16-上车监控清单.md)本轮条目与[STATUS](../STATUS.md)。这不是新发版；不能只看versionName认定每个debug产物相同。

本轮ADB使用C:/Android/Sdk/platform-tools/adb.exe，每个调用指定-s 7e7d7bb4；以后必须重新devices -l核实身份，不能凭旧串号推断连接。原APK与17件配置/设计/素材/last-crash在运行中只读备份，exec-out二进制经Node Buffer落盘，禁止PowerShell重定向PNG。配置自动重连原true，App没有该开关入口；调试先在已断开页按断开，再仅临时更改settings.autoReconnect=false供新进程加载，防开机自动连车；收尾恢复原字节并核对所有文件。

无数据截图确认旧版指针仍显示，新版数字--时已隐藏；实际Simulator运行36通道/10Hz并离页持续，两个时点数字/针变化且有模拟提示。显式停止后提示消失但最后值冻结，这是模拟来源未接内部令牌的剩余缺陷，不是轮询修复失败或真车读数。排障时先分清来源/版本/运行状态，不以Bus写入示意值冒充实际源start/stop。完整轮询本地测试通过不替代真实Controller断连/Session取消、监听/传感器和真车。


## 2026-10-13 CAN页操作与排障更正

本条更新旧CAN界面及过滤说明，旧段落保留为历史。当前页面主操作固定在上方，宽屏设置/结果并排，窄屏上下独立滚动；文件导入导出与常驻监听在可展开区域，说明独立展开，ID可查找并按出现/变化/ID排序。未连接、初始化、准备/收尾时不能另开采集或监听，不能清活动结果；只有有数据/同范围基准才启用相应导出/对比。具体文案权威在CanSnifferText/CanFilterPresets，不在手册复制。

过滤历史更正：页面原09A转向灯预设误填228，原全11位与第0段同用ATCM700+ATCF000，已按实际接收ID/掩码修正；历史车辆信号不推广到其他车型。手填只支持合法接收过滤格式，不接受任意AT。中断监听必须确认提示符，再设置过滤并重开ATMA；参考官方ELM327文档，实际克隆适配器仍须专门验收。

结果含原始数据/未绑定或候选时不能当已验证物理值。准备取消/失败不破坏最后有效基准；同范围再采可对比，轮换提前结束标部分结果。坏字节拒绝整帧、DLC长度不一致拒绝，不能跳过字节给公式凑数据。无值/健康失败查阶段和原因，不把空结果、OK字符串或进度当成功采集。

本轮平板先重新备份原APK与17件配置/设计/素材，临时关自动重连后保留数据装debug；查看/输入/展开/旋转不发真实CAN请求。源正式测试是假传输环境、实际设备显示与车辆验证分层，最终结果以STATUS及docs16本轮记录为准，模拟停源S仍未完成。


## 2026-10-14 CAN平板调试收口

本轮最终debug仍1.20.22/code91，用设备pull与电脑SHA256识别：ffcfa07cd41bd7bbeb3dabdd343ef86666fe4dc59786c661e0010283288f7e55，7478330字节。保留数据安装；原APK/17文件本卡重新备份，收尾17/17字节一致。临时autoReconnect=false只在启动测试进程使用，持久settings已恢复原字节/true；当前进程仍按false启动，下次启动恢复原设置。旋屏accelerometer_rotation/user_rotation已还原1/0，不改分辨率或密度。

点击过滤输入触发第三方输入法首次协议页时不要代用户接受；本轮返回协议页后保留CAN输入焦点，ADB文字验证ATZ拒绝、09A与29位ID合法，并清回空白。UI取证先确认新dump成功，再截图，过渡页/旧XML不计通过。完整报告见[本轮CAN报告](../stage/can-review-codex-20261013/REPORT.md)。真实车辆命令/常驻监听/分段/恢复均未执行。


## 2026-10-14 CAN顶部与详情操作更新

顶部右侧开始/停止、详情/收起、返回固定；默认只显示简短阶段与连接/统计，点击详情看完整说明和轮换进度，故障转FAILED时自动展开。折叠选择随旋转保存，不改采集与模式互斥。横屏结果区实际多37.47%高度，竖屏多28.41%。本轮只验证空闲/未连接详情和旋转，没有启动真实采集；运行统计/真实失败自动展开尚无硬件实屏证据。

平板最终debug1.20.22/code91，7478654字节，SHA256=5e67156c211d46967d4ddc8dcf71dabc34ed0fb58462a83705cdaf7a94fff3cf，设备pull一致。重新备份原APK/17件配置设计素材，收尾17/17字节一致，临时autoReconnect与旋屏1/0恢复；当前进程按false启动，下次按原true。日志标记只限定采样窗口，原证据与[本轮报告](../stage/can-header-codex-20261014/REPORT.md)本地忽略保留，不发版。


## 2026-10-14 PID探测操作与排障（未发版）

从PID页进入「PID探测」。选择01/09（单字节）、21厂家本地ID（单字节）或22厂家数据ID（双字节）；23是按地址读取内存，本工具不允许，不能当厂家PID或偷偷映射22。参考[Scapy KWP实现](https://github.com/secdev/scapy/blob/master/scapy/contrib/automotive/kwp.py)和[ELM327官方手册](https://www.elmelectronics.com/wp-content/uploads/2020/05/ELM327DSL.pdf)，不是宣称完整ISO标准认证。

默认CAN请求ECU为7DF；厂家PID须核实对应ECU，支持合法3/8位CAN请求头。开始前确认安全停放，先查支持位图默认开，高级参数折叠；读取上限包含位图/重试/额外采样，另有请求头设置/恢复各一条AT，不能用上限阻断恢复。未响应/缺位图标未探明，不等于本车不支持；全零有效位图不会触发盲扫。

顶部始终有开始/停止、设置收起与返回，结果独立滚动。停止取消实际当前任务，收尾期间停止不可重复；已停止/达到上限/失败与完成分开，PID进度不会一律补成100%。无命中也能导出本轮状态、参数/真实读取数/日志。参考公式与采样范围没有核实物理含义，编辑默认禁用并保留实际ECU头，确认公式/单位/量程后才启用。

旋转保留本进程输入/结果/扫描，最终离开取消，收尾恢复仅按原轮询状态；恢复头未确认时保持轮询关闭并提示原因，先检查连接和初始化。进程终止后的历史查看用ProbeLog，不声称旋转持有是持久任务。平板本轮只做UI、配置保护与debug升级，不运行真实探测。


## 2026-10-14 模拟停止与未知读数

从连接页进入模拟信号，开始后离开仍运行，顶部模拟提示保留。要结束回模拟页显式停止，本轮当前读数立即失效，下游显示未知并收起数值指针/进度弧；量程和阈值刻度仍为静态背景。不要用清总线/重启App/恢复旧缓存冒充停源修复。

其他来源后来覆盖的同PID仍按该来源正常显示；历史/累计不被清掉。运行样本默认有限期限，已配置正TTL在启动快照优先；若持续模拟没有更新，按读取入口的新鲜度判未知。再次开启可恢复输出。离页/旋转不丢失原轮询恢复意图，但当前连接/模式条件仍须满足，实际车辆恢复另验。

本轮平板保留数据升级后，在同一进程内实际开→离页动态→回页停→未知→再开→再停验证，原17文件字节恢复且没有重建进程来清掉冻值。当前安装以docs16/STATUS最新哈希识别，版本号未变，原PID硬件缺口不由模拟验收关闭。
