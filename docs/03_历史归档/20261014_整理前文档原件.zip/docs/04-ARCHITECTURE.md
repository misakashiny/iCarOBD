# 架构与维护规则

> 本文回答「为什么这样设计、哪些边界不能跨越」。查找要修改的文件请看
> [FILE_MAP.md](05-FILE_MAP.md)，接手项目与真实设备验证请看
> [HANDOVER.md](06-HANDOVER.md)。

## 1. 分层与依赖方向

依赖只能从上往下，不能反向。

```text
ui/
  MainActivity、Fragment、Editor Activity、adapter/、dash/、view/
       │ 读 VehicleBus；写 ObdController（车辆操作的唯一入口）
       ▼
obd/
  VehicleBus、ObdController、ObdEngine、RuleEngine、ObdProtocol、
  PidScanner、ElmSession
       ▼
ble/
  BleTransport（只管收发字节）
       ▼
data/
  模型、公式、内置 PID、持久化、日志、CSV、音效、默认配置
```

`service/ObdService` 只依赖 `obd/` 与 `data/`，不依赖 `ui/`。
`ui/view/` 和 `ui/dash/` 只依赖 `data/PidModels`、`obd/VehicleBus`、
`obd/RuleEngine`；它们不认识 BLE、ELM327 或公式。

## 2. 关键数据链路与排障

```text
BLE → BleTransport → ElmSession → ObdEngine → ObdProtocol
    → VehicleBus → RuleEngine / DashRenderer / CsvRecorder
```

| 现象 | 优先检查 | 对应日志模块 |
|---|---|---|
| 扫不到或连不上设备 | BLE 权限、扫描、GATT 服务与特征 | `BLE` |
| **连上了但所有 AT 命令都超时** | **看自动转储的 GATT 表**：写特征的 `props` 是否有 `Wn`/`W`、写类型是否被接受 | `BLE` |
| 初始化或请求超时 | 串行请求、协议协商、原始响应 | `OBD` |
| 已收到响应但数值异常 | `ObdProtocol.extractData`、PID 公式 | `OBD`、`DATA` |
| 仪表不刷新 | `VehicleBus` 是否有值、仪表绑定的 channel | `DATA`、`UI` |
| 规则不触发 | 数据源启用状态、阈值与持续时间 | `RULE` |
| CSV 没有记录 | 记录开关、存储权限与文件路径 | `DATA` |
| **日志页崩溃 / 日志文件异常大** | 环形缓冲溢出通知是否成对、是否有单点刷屏 | 见下方 |

### 2.1 实车踩过的两个坑（v1.3.0 修复，务必先读）

**① 「连上了但一个字节都收不到」** —— 2026-10-02 上车实测，
`ATZ/ATE0/…/0100` 全部超时。原因是 `BleTransport` 把写类型写死成
`WRITE_TYPE_DEFAULT`，而该适配器（`IOS-Vlink`，服务 `18F0`/写 `2AF0`/通知 `2AF1`）
的写特征只支持 write-without-response，于是 `writeCharacteristic()` 永远返回 false。

现在的对策：**连接后自动把整张 GATT 表写进日志**（`dumpGattTable()`），
包含每个特征的 `properties` / `writeType` / descriptor 数量。
排查这类问题**第一步永远是看这张表**，不要靠猜 UUID。

**② 「日志页崩溃 + 日志文件 57MB」** —— 两个独立缺陷：
- `LogAdapter` 环形缓冲满 3000 后是「挤掉队首 + 追加队尾」，
  但只发了 `notifyItemInserted`。RecyclerView 的位置表因此持续漂移
  （2999 → 3049 → 3084），最终抛 `Inconsistency detected`。
  **缓冲区溢出时必须成对通知**（`notifyItemRemoved(0)` + `notifyItemInserted(last)`）。
- BLE 写入失败进入了无限重试并逐次写日志，2 小时刷出 113 万行 / 57.9MB，
  占全部日志的 99.9%。现在 `AppLog` 有四条自我保护：
  重复消息抑制、单日文件上限、落盘队列有界、监听器批量派发。
  **这四条不可移除** —— 任何一处单点刷屏都曾把整个日志系统拖垮。

## 3. 横竖屏自适应

| 方向 | 布局 | 导航控件 |
|---|---|---|
| 竖屏 | `layout/activity_main.xml` | `BottomNavigationView` |
| 横屏 | `layout-land/activity_main.xml` | `NavigationRailView` |

两者共用 `navView` id，且都继承 `NavigationBarView`；新增导航项只需改
`menu/bottom_nav.xml`。

**仪表盘布局与方向无关**（v1.5.0 起）：位置尺寸用**归一化坐标**（`GaugeItem.x/y/w/h`），
同一份配置在竖屏与横屏都成立，所以仪表盘**不再按方向切换列数**。
旧版那套（`DashRenderer.columnCount()` / `GaugeItem.span` / `MAX_SCALE` /
`NestedScrollView`）**已废弃**，见 §6。

**导航控件才按方向切换**：竖屏底部 `BottomNavigationView`，横屏左侧 `NavigationRailView`
—— 横屏垂直像素只有竖屏的 62%（1600 vs 2560），底部导航要吃掉约 8% 屏高。

宽屏表单用 `MaxWidthViews.kt` 居中限制在 720–900dp：表单页用
`MaxWidthScrollView`，嵌套滚动页用 `MaxWidthNestedScrollView`，列表根布局用
`MaxWidthLinearLayout`，非滚动内容用 `MaxWidthLayout`。

旋转会重建 Activity；连接和轮询驻留在 `ObdController` 单例中，当前页面由
`MainActivity` 保存恢复。`switchTo()` 必须保持 `commitNow()`，避免快速切换时重复添加 Fragment。

## 4. 不可跨越的边界（**唯一权威清单**）

> ⚠️ **这份清单只在本文件维护。** `01-接手大纲.md` §6 与 `06-HANDOVER.md` §14
> 只做索引与补充说明，**不再重复列出条目**。
>
> 历史上这份清单曾在两处各写一份，结果分叉成「一处 7 条、另一处 12 条」，
> v1.1.0 新增的横屏约束只写进了其中一份。**新增/修改红线请只改这里。**

### 4.1 架构边界

1. UI 不得直接创建 `BleTransport`；车辆操作统一经过 `ObdController`。
   否则两条 GATT 连接会互相抢响应。
2. 不得绕过 `ElmSession.request()`；其 Mutex 是 ELM327 半双工串行化的唯一保证。
3. 不得给 `ObdEngine` 加并发请求；提速只能调整轮询间隔。
4. 不得放松 `PidScanner` 的限流、总量上限或危险模式拦截；Mode 04 会清除故障码。
5. 不得向 `DashRenderer`、`BaseGaugeView` 添加数据采集逻辑；
   渲染层只接收「已计算好的数值 + 可选覆盖色」。这是本项目最值得保留的设计。
   **报警状态也只有一处**：`BaseGaugeView.alertLevel`（v1.10.1 起）。
   曾经并存过一个 `warn: Boolean`（含下限、用于选色）与 `alertLevel`
   （只认上限、用于爆闪），两者重叠但不相等，加一档报警要改 7 个视图。
   现在颜色统一走 `alertColor()` / `valueTextColor()`，**不要再引入第二个报警布尔**。
6. 改动 `PidDefinition`、`Rule`、`GaugeItem` 字段时，必须同步 JSON 的
   `toJson` / `fromJson`，并考虑旧配置迁移；**同时同步
   `tools/icarui/index.html`**（否则 PC 端编辑器与 App 的校验会分叉）。
7. `GaugeTheme` 必须留在 `ui/view/`；放到 `ui/dash/` 会让底层绘制层反向依赖上层编排层。

### 4.2 UI 与自适应

8. 不得在 `GridLayout` 用高度 `weight`（`NestedScrollView` 内高度无界会塌成 0）。
9. 仪表内字号一律按视图尺寸取比例，不写死 sp（否则平板放大后「大表配小字」）。
10. 不得给任何 Activity 加回 `android:screenOrientation="portrait"`。
11. 不得改 `navView` 这个 id，也不得只改其中一个方向的布局；
    `layout/` 与 `layout-land/` 靠同名 id + 共同基类 `NavigationBarView` 才做到零分支。
12. `MainActivity.switchTo()` 必须保持 `commitNow()`；
    `commit()` 是异步的，会产生重复 Fragment。
13. 宽屏限宽不得用 `layout-land` 副本实现，统一走 `MaxWidthViews.kt`；
    复制 XML 会让后续改字段时两处不同步。

### 4.3 数据与日志

14. 不得移除 `AppLog` 的四条自我保护（重复抑制 / 文件上限 / 队列有界 / 批量派发），
    也不得在循环里逐次写日志 —— 实车上曾因此 2 小时刷出 113 万行 / 57.9MB。
15. RecyclerView 适配器做环形缓冲时，**移除与插入必须成对通知**；
    只发插入会让位置表漂移并抛 `Inconsistency detected`（实车复现两次）。

### 4.4 BLE

16. 特征选择必须校验 `properties`，不能只比对 UUID；
    写类型要在 `WRITE_TYPE_NO_RESPONSE` 与 `WRITE_TYPE_DEFAULT` 之间自适应。
17. **GATT 操作必须串行化 —— 同一连接同时只允许一个未完成操作。**
    这条是 2026-10-06 用**一轮实车日志**换来的：`requestMtu(512)` 与
    `writeDescriptor(CCCD)` 背靠背发出（相隔 12ms），描述符写的回调**再也没回来** →
    栈上永远挂着一个未完成操作 → **之后每一次 `writeCharacteristic()` 都返回 false**。
    症状是「连上了、通知也能收、但一个字节都发不出去」，一小时刷出 902 条
    「写入被拒」而**零有效数据**。

    **判据**：日志里必须有 `CCCD 写入完成 | status=0`。没有它 = 栈已卡死，
    此时**唯一有效的动作是断开重连**，继续写毫无意义。

    **两个具体禁令**：
    - `requestMtu` 之后**不能**紧接着 `writeDescriptor` —— 要在 `onMtuChanged` 里再开通知
    - 超时兜底**必须用显式的 `pending` 标志**做判据，
      **不能拿 `state == DISCOVERING` 代替** —— 前者会被另一个回调先改掉，
      兜底就变成**永不触发的死代码**（我们正是这么静默失效的）

### 4.5 其他

18. `settings.gradle.kts` 的阿里云镜像是当前网络环境的构建前提，不能删除。
19. `AppLog` 的模块常量是 `M_XXX`（`M_RULE` 不是 `RULE`）。
20. 不得把仪表盘布局改回「网格 + `span` + 高度 `weight`」：v1.5.0 起是
    **归一化自由画布**（`GaugeItem.x/y/w/h`），网格那套（自然高度 / `MAX_SCALE` /
    `NestedScrollView`）已废弃，见 §6。
21. 样式 → View 的映射只能写在 `ui/view/GaugeViewFactory.kt` 一处；
    渲染器与拖拽编辑器都调它，**分两处写必然分叉**（编辑器看到的与实际渲染的不一致）。
22. **性能判据只能是帧间隔，不能是 `DrawStats` 的每帧耗时。**
    开了硬件加速后 `onDraw` 只是把绘制指令**记录**进 DisplayList，
    真正的光栅化在**渲染线程**上做 —— `DrawStats` 量的是"记录耗时"，不是绘制成本。
    拿它下结论会得出过于乐观的答案（v1.10.1 差点这么干）。
    基准入口：连接页 →「运行选项」→「性能基准」，报告在 `files/bench-dashboard.txt`。
23. **设计文件（`icar.ui/1`）的校验规则必须与 `tools/icarui/index.html` 保持同源。**
    两边分叉的后果是「编辑器说没问题、App 加载报错」，而用户直到推上设备才发现。
    改任何一边都要改另一边，`ThemeStudioSampleTest` 会守住这条。

## 5. 维护约定

- 新增、删除或重命名文件后，更新 [FILE_MAP.md](05-FILE_MAP.md)。
- 变更架构边界、数据流或扩展机制后，更新本文。
- 每次发版在 [CHANGELOG.md](07-CHANGELOG.md) 记录版本、日期、验证方式和遗留问题。
- 新工具脚本放在 `tools/`，并登记到文件大纲。
- **改了渲染层或动画后重跑性能基准**（红线 21）。
- **改了 `GaugeItem` / `DesignFile` 字段后同步主题工具**（红线 22）。

## 6. 仪表盘渲染与布局（v1.5.0 起：自由画布）

> **这一节替代了 v1.4.0 及以前「网格 + span + 自然高度等比放大」那一套。**
> 如果你在别处看到「自然高度 186/92/54」「`MAX_SCALE` 2.2」「不要改成 weight」，
> **那是已废弃的描述** —— 现在既没有网格，也没有等比放大。

### 6.1 坐标系：归一化 0..1

`GaugeItem` 用 `x/y/w/h`（**归一化 0..1**，y 向下）描述位置与尺寸。

为什么不存像素：归一化坐标**与分辨率、横竖屏都无关**，同一份布局配置在手机竖屏与
平板横屏上都成立，不需要为每个方向存一套。像素换算只发生在 `DashRenderer.render()`。

### 6.2 渲染流程

```text
DashSpec.build(type)            → List<GaugeItem>
DashRenderer.render(spec, theme)
  ├─ applyOverlay(theme)        → 参考线覆盖层（z 序最底，永远盖不住仪表）
  ├─ 每个 item：
  │    ├─ GaugeViewFactory.create(ctx, style)    ← 样式→View 的【唯一】映射处
  │    ├─ view.bind(item, pid, theme, extras)    ← 副参数定义也在这里传进去
  │    └─ FrameLayout.LayoutParams(w*cw, h*ch) + margin
  └─ pushValues()  5Hz
       ├─ updateMulti(values, override)          ← 主参数 + 副参数一次取齐
       └─ 若 wantsHistory：updateHistory(...)    ← 只有趋势图要，避免无谓拷贝
```

### 6.3 为什么不再需要滚动容器

旧网格的高度是「自然高度 × 缩放」，内容可能超出视口，所以套了 `NestedScrollView`。
归一化坐标**天然铺满视口**，所以 v1.5.0 去掉了滚动容器，画布就是 `match_parent` 的
`FrameLayout`。

### 6.4 参考线

`DashGridOverlayView` 是画布的**第一个子 View**。开关、密度（列 × 行）、
样式（实线 / 虚线 / 点线）、透明度都存在 `Store.settings` 里。

> ⚠️ 它的属性叫 `linesEnabled` 而不是 `enabled` —— 后者与 `View.setEnabled`
> 撞 JVM 签名，编译期直接报 `Accidental override`。

### 6.5 多数据显示与历史

- 主参数 = `GaugeItem.pidId`，副参数 = `GaugeItem.extraPids`，`allPidIds()` 给出全部。
- **数值由渲染层推给视图**（`updateMulti`），视图**不读总线** —— 见红线 4.1.5。
- 趋势历史同理：`VehicleBus` 维护**有界环形缓冲**（150 点 ≈ 30 秒），
  只有 `ok` 且非 NaN 的值入历史（否则曲线会被无效值打断成锯齿）。

### 6.6 布局迁移与拖拽数学

- v1.4.0 及以前的 `dash.json` 只有 `span`（2 列网格语义）。`GaugeItem.fromJson` 读到
  缺 `x/y/w/h` 的条目会把 `legacyGrid` 置位，由 `DashLayout.migrateFromGrid()`
  **一次性迁移并回写**（行高按该行最高样式的自然高度占比还原）。
- 拖拽编辑器的坐标运算（吸附 / 夹取）是**纯函数** `DashLayout.Drag`，可单测。
  边界夹取用精确值 `1-size` 而不是吸附值 —— 贴边时允许不在网格上，
  但**绝不溢出画布**（这是刻意的取舍）。

## 7. 2026-10-13 全局源码审查快照（非修复、非设备验收）

§1是期望的依赖边界，不是当前实现完全符合的证明。本轮按入口、调用与导入扫描覆盖App Kotlin包、Manifest/构建及主要资源入口，详细反例/范围见[STATUS](../STATUS.md)，待修项及验收只在[迭代清单的App全局审查候选](03-迭代清单.md)维护，TASK仍为T11-I。

- 实际主路径支持BLE和SPP：ObdTransport→ElmSession串行请求→ObdEngine/ObdProtocol→VehicleBus→规则、仪表与CSV；模拟信号和传感器也写同一总线，需要明确来源/会话代际，不能把任意ok值当作车辆连接证据。
- 单请求Mutex不等于整段初始化/扫描/ATMA模式互斥。准备、运行、收尾及断连都需要同一模式所有者；原有FrameMonitor/CanSniffer running判断不覆盖所有操作者。
- 取值TTL有现成守卫，但轮询/模拟/派生值默认TTL=0，且部件渲染有自己的值缓存。所有消费路径都要传递“无效/未知”，不能只守总线某一入口。
- 当前多画布已隔离布局/主题/背景字段，但designBaseDir仍为全局，背景文件也共用bg/background.img；资源所有权尚未完整跟随画布。icarzip的现有导入在CanvasSettingsFragment和DesignPack，不能误记为无能力；工具icar.control/2不自动成为App消费格式。
- 实际导入存在data/CanFilterPresets、CanSnifferText→obd/SegmentRotation，以及service/ObdService→ui/MainActivity（通知PendingIntent目标）例外；ui/dash同时含配置Fragment与纯渲染器，不能将整个包笼统说成仅依赖模型。后续以中性共享模型/入口边界渐进收敛，不在本轮移动类。
- 分层、半双工串行、统一GaugeViewFactory、共享GaugeTicker、有界日志/历史与纯函数测试值得保留。先补请求安全、数据正确性与用户配置保护，再评审大文件拆分、索引缓存或退役LVGL构建；§4红线保持不变。

### 2026-10-13 App-A0：PID与内部会话命令边界

用户PID请求统一经过`obd/PidRequestPolicy.check`与`ElmSession.requestPid`，检查最终覆写请求、声明服务、来源和模块头，生成不可变command/header快照。轮询在任何ATSH前检查，运行中重新检查可变配置；PID编辑器测试/采样也使用同一快照。导入/备份不删除用户条目，拒绝记录本次不发送并标无效原因，修正配置后reload可恢复。

当前用户读取服务只允许项目已有01/09/21/22，必须完整十六进制字节，最终服务与声明一致；用户PID不接受AT覆写，来源仅poll，目标头仅空或合法11/29位CAN标识。`ElmSession.request/raw`仅供内部初始化/协议/监听，仍在发送前拒绝非允许读取服务及多命令；内部AT格式校验保留现有初始化、头切换和过滤路径。不能把用户customRequest交给内部raw以规避策略；不因新增接口放松Scanner原有总量/节流/危险模式守卫。

这些限制是应用读取用途的安全策略，不保证所有厂商服务在所有车型都无副作用；未知用途须另行评审，不靠用户字符串授予任意写入能力。本轮未扩展模型/JSON/共享设计格式，也未改变会话取消、模式所有权或重连语义；设备/车辆仍需专卡授权。

### 2026-10-13 App-A1-D：派生有效期与累计完整性

`VehicleBus.Derived` 对燃油流量、瞬时油耗、增压和续航在每次重算时明确输出有效或未知；缺源、ok=false、过期或非有限输入不再静默保留旧有效结果。未知输出用ok=false且值为NaN，通过既有总线订阅通知下游，不写有效历史，也不清无关通道或历史。有效派生输出的TTL取有TTL依赖的最早截止时间剩余量，不以重算时间延长上游寿命；源TTL=0仍不提供断连保证。

里程与用油量保留已确认的累计部分；积分时间非法、速度缺失/越界或燃油缺失时不能把漏计数据组成完整平均，平均与续航保持未知。瞬时量可随输入恢复，累计平均在resetTrip之后重新积满有效行程阈值才恢复。resetTrip清两项累计，并立即经总线发布0里程、未知平均及续航；原始PID、传感器值与历史不清除。此API目前没有生产调用方，用户可操作的行程重置入口仍须后续专卡，不宣称已提供按钮。

本次不改MAF估算口径、合法015E零值优先级、源会话代际、状态灯未知皮肤或重连；这些仍按[迭代清单](03-迭代清单.md)分卡。正式失败/通过回归和构建层级见[STATUS](../STATUS.md)，无设备或真车验收，也未改变共享格式/版本。

### 2026-10-13 App-A1-L：图片状态未知的运行时边界

NodeTreeRenderer调用NodeStateResolver选择皮肤和现有tick闪烁相位。DashRenderer继续将总线失败/过期/非有限读数推成null；有statePid但无有限值时走明确未知分支，清旧位图/tag、退出闪烁并由运行时视图画中性占位，数据恢复后重选皮肤。无statePid的静态节点仍走原normal/基础图。未知不等于正常、不猜报警，也不是新增的JSON状态名；normal/warn/critical及最低闪烁周期不改。

纯函数只接收数值与PID定义查询，不读VehicleBus；总线仍只由渲染编排层读取。已有显式阈值优先/库值回退和严重→警告→正常皮肤回退保留，无选中皮肤时恢复基础图而不是继续显示上个告警。原注释声称迟滞但实际仅直接比较阈值，本轮更正注释、不新增迟滞规则。占位大小/颜色以[排版总表](09-UI样式与排版总表.md)源码位置为准，职责以[文件大纲](05-FILE_MAP.md)为准。

正式回归验证生产解析及分发，不是Android像素或帧间隔证明。实际设备显示、首帧/缩放/自定义背景可读性与设备性能基准未运行，仍需后续授权专卡；没有增加动画线程/定时器，不宣称性能提升。源TTL=0仍可能传入旧有效值，源失效总项另卡，本轮不能关闭App-A1全部要求。


## 2026-10-13 T-App-A1-P：源归属与停止边界（方案，未实施）

源码确认VehicleBus.put实际生产调用者为ObdEngine、SignalSimulator、FrameMonitor、GForceSource及通过回调发布的Derived。raw是报文字节或sim/sensor/speed文本，不能拿它猜归属。Engine成功样本TTL=0，stop只取消job，循环检查根scope/running；Controller CLOSED/disconnect/stopPolling均委托engine.stop。Simulator退出页面刻意持续运行，显式stop只摘Handler。监控TTL沿用配置，G源停止只注销监听，派生累计与瞬时已在前项区分。

本轮正式SourceLifecycleTest直接运行生产Engine/Session/Protocol/Store/Bus，受控协程只替换调度，假传输不阻塞send/不接设备；稳定复现停源旧值、默认无限TTL、旧取消覆盖新值、重启旧job继续、失败仍running五项。三个对照保留其他源/历史及既有TTL过期。Controller、Simulator/监听/传感器Android生命周期本轮未执行。

拟定第一实施卡在Bus内部增加owner+epoch活动令牌和当前值归属，原子关闭只失效本令牌当前值，兼容put的外来新值不被旧关源误清，拒绝已关闭job晚到写；不改PidValue/配置/设计JSON、不全局clear、不删历史/累计。Engine捕获本轮令牌并检查当前job，stop/finally只收本轮，默认运行时TTL有限。模拟/监听/传感器逐卡接入，不能凭第一卡宣布全部源已失效正确。完整范围、风险及测试矩阵见[源生命周期方案](../stage/app-a1p-codex-20261013/SOURCE-LIFECYCLE-PLAN.md)；23条红线保持。


## 2026-10-13 T-App-A1-C：轮询来源失效实现

VehicleBus内部Source以owner对象身份区分采集实例、epoch区分启动代际；令牌状态、当前PID归属、当前值和历史写入共用sourceLock。关闭只把当前仍属于本令牌的有效值改为ok=false，重复关闭无操作，关闭后的put在历史/通知前拒绝。旧兼容put先解除该PID的旧归属；不从rawHex识别来源，不改PidValue七字段或配置/设计JSON。来源通知在Bus锁外，不保证跨线程通知总排序；现有消费者依get/value/snapshot读当前状态。

ObdEngine每次start以LAZY job先登记令牌/job再启动；停止与finally摘下自己的状态，关闭源后取消捕获的旧job，旧finally不清新代际。使用当前协程job活动状态和令牌检查，在请求返回、发布、下一请求、派生发布及onCycle前拒绝旧任务。接收结果和派生周期的共享状态在Engine同步块内；没有在Bus锁内调用监听者，也不在请求等待时持Engine锁。下一轮清调度截止以立即重新取值。

PollFreshness只控制轮询运行时：显式正ttlMs优先，否则max(2000ms,3×有效PID间隔)。有效间隔含单PID/全局周期、优先级与降频，最短30ms，Long运算并夹Int上界，避免溢出成为无限TTL。多PID排队允许旧值超时显示未知；策略尚未用真车节奏调参。Engine生成的瞬时派生输出和有效性依赖平均/续航随本轮关闭失效；calc_km不作实时失效，accKm/accLiters与历史保留，只显式resetTrip清累计。没有改油耗公式/MAF/015E口径。

本地正式红绿与完整JVM证据见[STATUS](../STATUS.md)。此卡只接轮询；Simulator/FrameMonitor/GForceSource仍走兼容put，不能据此关闭全部App-A1。平板模拟器已实际确认显式stop后旧读数仍挂着、提示消失，下一单卡处理模拟源。ADB显示/升级不等于实际OBD断连、Controller重连或真车验证，23条红线不变。


## 2026-10-13 T-App-CAN-1：CAN探测执行边界

CanSniffer按本次Run捕获环境/transport/session/engine，串行完成准备、各段采集和收尾；job取消覆盖准备等待，返回后校验当前Run/连接，接收回调同时绑定Run和段号。旧回调、忙时reset/start不改新一轮。先确认中断提示符再改过滤并重新ATMA，每段从实际开启采集计10秒，完整8段才标整轮完成；提前结束保留已有帧并明确部分结果。总聚合器直接喂实际帧，分段不再用合成值重建原始流。

CanReceiveFilter是接收过滤输入/说明/下发的共同校验：只接受3/8位合法ID、ATCRA单ID或成对同宽ATCM+ATCF；任意AT、多命令/换行/残缺组合不发送。09A预设实际ATCRA09A，全部11位用零掩码，第0段用700掩码，不再共用同一值。官方协议依据见[ELM327数据手册](https://www.elmelectronics.com/wp-content/uploads/2020/05/ELM327DSL.pdf)，适配器克隆差异和真实回执效果仍待设备/车上验证。

CanAdapterGate短临界区覆盖普通初始化进入/退出、CAN启动/收尾与轮询启动，锁不跨任何串口等待。FrameMonitor.active包含准备/采集/收尾，准备job和代际在停止时取消/校验；恢复前先清旧缓存，旧回调不更新新模式。Controller初始化恢复可明确startPolling=false，CAN先恢复设置/健康检查，再仅恢复此前运行的轮询；健康失败保持暂停并明确提示。普通初始化与Can/Monitor同时启动被拒。Controller自动重连、Session waiter、扫描器与全部操作的统一模式租约仍不由本卡宣称完成。

CanFrame拒绝坏字节而不改变后续字节位置，ID限29位、经典帧1~8字节；保留既有单数字DLC前缀，要求声明与实际长度一致，不新增CAN-FD。CanProbeRecord在终态生成观察/解码记录，Android运行时主线程保存到ProbeLog，页面退出/旋转不抢先记FINISHING。候选位只用于优先核对，不把相关性写成已确认因果/车型定义。共享PID/设计/CSV格式未变，FrameMonitor值失效源接入、模拟停源和真车仍未完成。


## 2026-10-14 CAN续轮：排队取消与监听停止边界

LAZY任务登记后若在IO线程尚未进入协程体时取消，体内finally不会运行；CanSniffer以entered标记和完成回调补走同一个NonCancellable finish。整个清理阶段仍持本轮active，未发送命令时只解除本轮和恢复原轮询，不重复记录。生产排队调度反例21项中1红，最终完整JVM1252项0失败错误跳过。

FrameMonitor准备最后的活动/代际检查、raw回调安装、ATMA与busy释放同停止摘状态共用CanAdapterGate短锁，防取消后旧准备重新开监听或解锁收尾；原始回调也检查捕获代际。锁不跨串口等待。这里只复核接线/编译及互斥纯逻辑；没有实际启动Android常驻监听，不宣称广播值来源令牌、断连/重连或全部传输归属已验证。13日段落的旧回调指本卡对应回调，不能外推Bus所有通知。


## 2026-10-14 PID探测局部维护（未发版）

ScannerStateModel持有PidScanRun，页面重建只重新订阅StateFlow；最终退出取消本轮任务，NonCancellable收尾仍受2500ms上限。扫描令牌经CanAdapterGate短锁占用至恢复结束，初始化（含不自动轮询的初始化）、CAN采集、常驻监听和Controller轮询入口互斥；不跨串口等待持锁。先暂停原Engine再快照其请求头，捕获transport/session/engine身份；每个读取前核连接身份，断连/换连接不向新会话发恢复命令。

请求头由显式CAN ID确认后才扫描；原轮询运行时收尾确认7DF以匹配Engine启动默认头，原轮询停止时恢复缓存的原请求头且保持停止。恢复没OK不自动开轮询。此契约尚无真实ELM/车辆证据，不能说串口物理设置已验。

PidScanner后端只允许01/09/21/22并校验字节宽度/范围/预算/参数。PidScanResponse独立严格路径先认帧边界再核服务+ID，不沿用ObdProtocol.extractData的历史兜底；普通轮询/编辑器的兼容解析本轮未全局修改。位图全零不盲扫，失败块记未探明且继续后块，多ECU取并集，至少保留01 C0；额外范围按对应块覆盖。PID读取上限含位图/重试/学习，AT请求头设置/恢复是至多各一条控制命令，保留收尾不受读取预算阻断。

ElmSession外部协程取消向上传播；超时仍返回空，flush/send异常仍向上传播以保留Engine故障停源契约，finally清本轮waiter。不是全局重连或任意晚到帧关联问题的解决方案，不关闭App-A1其他源/Session总项。


2026-10-14 PID收口补充：轮询重启/CSV恢复抛异常也释放本轮占用并发布失败终态，尝试停掉半开的轮询；原结果和ProbeLog保留。正式生产Run反例9项1红后修复，全量1284项全绿；不是实际硬件异常已验。


## 2026-10-14 T-App-A1-S：模拟来源生命周期（未发版）

SignalSimulator每次start创建独立Run及VehicleBus.Source，捕获本轮调度器/相位起点/TTL快照与独立ticker。执行、每条普通/G通道发布和重新排队查同轮活动身份，旧callback不能借新running继续；stop先在短锁摘active，再锁外closeSource通知并移除捕获的旧ticker，重入start不关闭新一轮。复用既有Bus归属接口，没有改Bus、Controller、其他源、共享JSON或派生口径。

通道表/一拍快照同步，数值发布在锁外；Bus关闭与带源发布同锁，停止期间的晚到写入不入当前/历史/通知。运行样本默认TTL1000ms（10Hz），每轮启动时已配置正TTL优先，后改TTL下次start生效；不修改DTO默认0或用户文件。非有限模拟值明确未知，合法0有效；停止仅失效本轮仍拥有的当前值，其他来源后来覆盖值及历史/累计保留，不还原旧缓存。

SimulatorActivity继续离页模拟；engineWasRunning改为进程内保留，离页/旋转后显式停止仍消费原恢复意图，失败未启动也回收。恢复需此前运行且仍连接，并经现有Controller.startPolling入口尊重模式互斥；模拟本轮真实设备启动前轮询未运行，实际OBD恢复仍未验。该局部接线不等于所有来源/模式的统一租约或重连问题解决。

SignalSimulatorRuntime只隔离时钟、主线程队列与PID快照；默认Android Handler仍lazy且100ms排队。正式回归执行实际start/ticker/stop，而非另写模拟器或直接Bus.put冒充停止。
