# 迭代日志 · CHANGELOG

## 文档工具登记：本地迭代看板（2026-10-11，未发版）

- 根目录“打开迭代看板.cmd”作为统一阅读入口；本地生成器汇集当前改进摘要、计划、两侧版本日志、文档原文与 Git 快照，支持切换和搜索。
- 摘要存于 STATUS.md，更新流程写入 AGENTS.md；使用说明见 [迭代看板 README](../tools/iteration-board/README.md)。生成页面含本地文档快照，已排除 Git 跟踪，不上传。
- 当前业务任务仍为 T2-R，验收未通过；看板不会改变任务状态或运行测试。验证结果见 STATUS.md 的独立看板记录。

## 文档变更登记：两端迭代同步文档（2026-10-11，未发版）

- 新增根目录 [AGENTS.md](../AGENTS.md)，明确 Codex 规划/审查、DeepSeekHarness 实现/验证/文档同步的职责。
- 同步根目录 SPEC.md、PLAN.md、TASK.md 与 [文档索引](00-README.md)：任务卡包含文档交付，文档一致性属于验收门槛，沿用现有权威表，历史纠错追加更正。
- 当前 T1-R2 的业务范围和状态未推进；本次未修改业务代码、版本号或构建产物。
- 验证命令与结果见根目录 [STATUS.md](../STATUS.md) 的“文档协作规则落地”记录。

> **维护约定**：每次发版追加一条，格式固定为
> `版本 → 日期 → 变更内容 → 验证方式 → 遗留问题`。
> 变更内容按「新增 / 修复 / 调整」分类，只写**会影响后续维护的事实**，不写流水账。
>
> 相关文档：`05-FILE_MAP.md`（改哪里）、`06-HANDOVER.md`（为什么这样设计）。


> **归档约定（v2.26.0）**：主文件超过 **100 KB** 就把最老的版本挪进
> `docs/archive/`，主文件只留**摘要表 + 指针**（见文件末尾的 v1.0~v1.8 那段）。
> 
> 为什么要定一条：v1.8.0 那节单独占了 7876 行（全文 83%），把主文件撑到 492 KB，
> 翻起来很难找当前的东西 —— 而它是**已放弃的 LVGL 调试日志**。
> 靠"感觉该整理了"不会触发，定成数字才会。
---

## 📚 文档变更登记 · `docs/` 全量文档迭代（第二轮）+ **活文档加数字前缀**（2026-10-11）

> **这一条没有对应的 App 版本** —— 本轮**一行 `app/` 代码都没改**
> （`versionCode` / `versionName` 也没动，测试数字逐条不变）。登记在这里是因为
> **`docs/` 的组织方式变了**（文件改名 + 归档），而那属于本文的职责。
> 索引与维护约定见 [`00-README.md`](00-README.md) 附录 A.4 / 附录 B 第 10 条。

**用户要求（原话三件）**：「同时检测全部文档、给文档排个序号、没用的文档删除掉」。

### ① 给 `docs/` 的活文档加数字前缀（`00-` ~ `26-`）

**为什么**：以前 27 份文档平铺，`Get-ChildItem` 按拼音/ASCII 排，**和"该按什么顺序读"无关**。
加编号后**目录顺序 = 阅读顺序 = `00-README.md` §1「按角色分」的索引顺序**（用户指定的依据）。
**`archive/` 与 `screenshots/` 不加编号**（历史归档改了 = 改历史；子目录有自己的 README）。
**新旧对照表**见 [`00-README.md`](00-README.md) 附录 A.4（27 行，逐份）。

**改名的连带改动（漏一处就是死链）**：
- `docs/**` 内部**全部**相对链接（Markdown 链接 + 反引号路径，含带 `:行号` 后缀的形态）；
- `00-README.md` 的按角色索引 + 权威表 + 三分钟版 + §5 一览 + 附录；
- `05-FILE_MAP.md` 的文件头表、§1 目录树、§7 文档清单（**顺带补全了原来漏登记的 6 份**）；
- 仓库根 `README.md` 的「文档索引」表；
- `tools/icarui/README.md` 的 3 条（工具侧，**死链守卫不扫这里，靠人工核**）。

**⚠️ 刻意不改的**：`07-CHANGELOG.md` 与 `03-迭代清单.md` 里**带版本号的历史叙述**、
以及 `archive/CHANGELOG-v1.0~v1.8.md` **整份**（维护约定 §4/§5：改它 = 改历史）。
这些行里的文件名是"当时的路径"，**保留原样**；代价是归档里新增了 5 条死链，
已逐条豁免在 `tools/doc-link-allowlist.json`（每条带 reason，见下面 ③）。

### ② 「下一步-*」那批已完成 → **标注完成 + 留在原地**（**没有移动、没有删除**）

`下一步-*.md` 那批**大部分已经做完了**。按用户要求**不删**（删了"当初为什么这么做"就没了）。
本轮的处理是**在 `00-README.md` §5 一览表里逐份标"✅ 已完成"**，并把完成状态写进本文 ——
**文件一个都没动**。理由见下面的「遗留 4」（为什么没搬进 `archive/`）：

| 文件 | 状态 | 落在哪 |
|---|---|---|
| `20-下一步-CAN信号库实现规格.md` | ✅ S1~S5 全部已做 | S1/S2 = v1.20.7、S3/S4 = v1.20.8、S5 = v1.20.10 |
| `21-下一步-主题工具与仪表盘重构.md` | ✅ 主要部分已做 | §1 / §2.4 完成；步骤 2~5 只剩可读性收益（见 §P7） |
| `24-下一步-控件检视器.md` | ✅ 已完成 | v1.20.14 / v1.20.15 / v1.20.17 |
| `25-下一步-UI改进四项.md` | ✅ 四项全部已做 | v1.20.17 + v1.20.18 |
| `26-下一步-全量文档迭代.md` | ✅ 已完成 | 交付物 = `00-README.md` §1/§2 + 附录 A |

> 每份文件头**本来就有**「✅ 已完成」状态表（首轮体检加的），所以"已完成"这件事**一直可追溯**，
> 不需要靠搬目录来表达。**未实现的两份**（`22-` 表盘制作与动效方案、`23-` 变量模式与组件变体）
> 保持 `⬜ 待评审`，是真正的待办。

### ③ 删除：0 份

本轮**没有删除任何文档**。三类判定的结果：
- **可证明没用** → **0 份**。逐份核过：**没有空文件**（29 份 md 无 0 字节）、
  **没有内容重复**（29 份 MD5 两两不同），也**没有"已被别处完整吸收"的** ——
  最接近的是 `26-下一步-全量文档迭代.md`（交付物已落进 `00-README.md`），
  但它同时是**这一轮的历史记录**（记着"用户当初为什么要求做这件事"），所以**保留**。
- **历史但有用** → 5 份（就是上面 ② 那批），**留在原地并标注"已完成"**。
- **拿不准** → 4 项，见下面「遗留」。

### 验证

```
node tools/check-doc-links.js
  → 扫描 29 份文档 · 候选 745 条（Markdown 链接 420 / 反引号路径 325）
  → 失效 0 条 / 已豁免 84 条 —— 全部通过 ✅

powershell -ExecutionPolicy Bypass -File tools\run-all.ps1
  → ① Kotlin 单测 TOTAL=1078 FAILED=0 SKIPPED=0 + 构建守卫通过
  → ② 浏览器套件 32 个 / PASS=1854 / FAIL=0 + 断言数基线核对通过
  → ③ docs/ 死链守卫 失效 0 条
  → exit 0
```

**测试数字与改动前逐条相同**（`TOTAL=1078` / `32 套 / PASS=1854`）——
证明这一轮**没碰到任何代码**。

### 遗留（拿不准，没动）

1. **`11-仪表框架.md` 的 §四「两条渲染路径」/ §六「已知问题」已过期** ——
   LVGL 在 v1.8.0 就被放弃了（`dashEngine` 默认 0），但文中仍把 LVGL 路径写成可选路径。
   ⚠️ **代码本身还在**（`app/src/main/cpp/lvgl` + `LvglDashView.kt` 都还在），
   所以"删掉这一节"和"保留"都能说通 → **没动**，只在 `00-README.md` §5 标了状态。
2. **`18-控件库优化建议.md` 建议 3 的 App 侧未做** —— 工具侧 v2.87.0 已落地 `bands`，
   App 侧不认这个字段（`app/` 本轮不许碰）→ 文档里已写明"工具侧已落地 / App 侧待办"。
3. **`PID_ALIASES` 条数**：首轮记 **35**，本轮实测 **36**（多了一条 `obd.odo`）。
   已按"以代码为准"改 `00-README.md` A.1 与 `05-FILE_MAP.md`；
   `13-UI设计指南.md` 里那句"27 条"是 v1.10.2 时的历史叙述，**保留**。
4. **那 5 份「已完成」的规格到底该不该搬进 `docs/archive/`** ——
   **试过，又退回来了**。搬进去会让它们**自己的**相对链接全部失效（`15-CAN-…md` 这类
   会解析成 `docs/archive/15-CAN-…md`），而且它们在**历史条目里被引用 20+ 处**
   （`03-迭代清单.md` 的版本表、`07-CHANGELOG.md` 的历史行）—— 那些行**按约定不许改**。
   搬一次的代价是"要么改历史、要么加十几条豁免"，而收益只是目录更短。
   → **决定：留在原地**，靠"数字前缀 + §5 里逐份标 ✅/⬜"表达状态。
   **如果用户更想要 `archive/` 里干净**，那要单独拍板"是否允许改历史条目里的链接"。

---

## 📐 格式变更登记 · `icar.ui/2` 新增可选字段 `bands`（工具 v2.87.0，**App 侧未做**）

> **这一条没有对应的 App 版本** —— 本轮**一行 `app/` 代码都没改**
> （`versionCode` / `versionName` 也没动）。登记在这里是因为
> **设计文件的格式多了一个字段**，而那属于本文的职责。
> 工具侧细节见 [`../tools/icarui/CHANGELOG.md`](../tools/icarui/CHANGELOG.md) v2.87.0。

**新增**：节点（`gauge`）可选字段 `bands` —— **多段色带**（画出来的分区参考）。

```json
"bands": [ { "from": 6000, "to": 7000, "color": "#FFB020" },
           { "from": 7000, "to": 8000, "color": "#FF4D4F", "alpha": 200 } ]
```

| 项 | 约定 |
|---|---|
| 段 | `{ from, to, color?, alpha? }`；`from`/`to` 是**量程上的值** |
| 上限 | `MAX_BANDS = 8`；`color` 只认 `#RRGGBB`；`alpha` 0..255 |
| 缺省 | **不写 = 空 = 完全旧行为**（红区仍由 `warnLow`/`warnHigh` 画） |
| ⚠️ 语义 | `bands` **只决定画出来的分区**；**报警判定仍然只看 `warnLow`/`warnHigh`** —— 两者不许互相影响 |

**App 侧状态**：❌ **未做**。`GaugeItem` 只有 `warnLow`/`warnHigh` 两个标量，
**读不懂 `bands`** → 带色带的设计在设备上**只会少画分区**（不报错，属"静默失效"）。
补齐清单（App 侧单独一轮）：

1. `data/PidModels.kt` 的 `GaugeItem` 加 `bands` 字段与 `fromJson` 解析；
2. `CircularGaugeView`（目前单段 `warnHigh→max`）与 `BarGaugeView`（目前只画两条竖线）按段画；
3. ⚠️ **必须同时补一条 `verify-crosslang.js` 断言**，把
   `MAX_BANDS` / `BAND_DEFAULT_COLOR` / `BAND_ALPHA_MIN` / `BAND_ALPHA_MAX`
   与工具侧**逐条钉住** —— 工具侧 v2.87.0 **故意没加**（单边常量，加了必红）。

---

## v1.20.22 · 2026-10-11 · 🎨 落地 `bands`（多段色带）的 **App 侧** —— 工具侧 v2.87.0 已落地、App 侧一直不认（**静默失效**）+ 补上工具侧**故意欠下**的跨语言断言 + `11-仪表框架.md` 的 LVGL 两节加警示行

> 这一版做的是 v2.87.0（工具侧）与 v1.20.21 的 CHANGELOG（格式变更登记）里**逐条写明的 App 侧待办**。
> 工具侧细节见 [`../tools/icarui/CHANGELOG.md`](../tools/icarui/CHANGELOG.md) v2.87.0，
> 契约见 [`12-主题设计大纲.md`](12-主题设计大纲.md) §2.116 / §2.117。

**问题**：工具侧 v2.87.0 就能在设计文件里写 `bands`（任意多段色带），
而 App 侧 `GaugeItem` 只有 `warnLow`/`warnHigh` 两个标量 —— **读不懂这个字段**。
后果不是报错，是**设备上少画分区**：用户在工具里精心画的"转速黄区 + 红区"
推到车上**一片都没有**，而**没有任何一条日志、任何一个警告**说这件事。
这正是本项目最恨的形态（静默失效）。

### ① 数据层：`GaugeBand` + `Bands`（`data/PidModels.kt`）

| 新增 | 说明 |
|---|---|
| `data class GaugeBand(from, to, color?, alpha?)` | 一段色带。`color` 是 ARGB `Int?`、`alpha` 是 `Int?` —— **没写就是 `null`，不填默认值** |
| `object Bands` | `bands` 的**唯一入口**：`normalize` / `parse` / `toJson` / `parseColor` / `hex` / `isUsable` |
| `GaugeItem.bands` | 新字段（缺省 = 空表） |
| `GaugeItem` 的 `BAND_*` 常量 | `MAX_BANDS` / `BAND_DEFAULT_COLOR` / `BAND_ALPHA_MIN` / `BAND_ALPHA_MAX` |

**规则与工具侧 `window.normalizeBands()` 逐条对齐**（这是"两侧各画一遍"的东西，
单边改了症状是"工具里 8 段、车上只剩 5 段"，**两边都不报错**）：

| 规则 | 值 |
|---|---|
| 不是数组 / 空数组 | → **空表**（= 没有色带 = 完全旧行为） |
| `from`/`to` | 取数字，**夹到 `[min, max]`**；夹完 `to <= from` 的段**丢掉** |
| `color` | **只认 `#RRGGBB`**（大小写都行）；不认的 → `null`（绘制时回落兜底色） |
| `alpha` | 取数字夹 `[0, 255]` 取整；没写 → `null`（绘制时按 255） |
| 段数 | 最多 `MAX_BANDS = 8`，**超出的丢掉** |
| 序列化 | **只在非空时写**；`color`/`alpha` **只在非 null 时写** |

⚠️ **夹取用 `minOf(maxOf(…))` 而不是 `coerceIn`**：量程写反了（`min > max`，手改文件就能造出来）
时 `coerceIn` 会**抛 `IllegalArgumentException: Cannot coerce value to an empty range`** ——
导入一份坏文件直接崩。与工具侧 `Math.min(Math.max(a, lo), hi)` 逐字同构（有专门一条用例钉着）。

### ② 绘制层：有 `bands` 就逐段画，没有走老路径

| 文件 | 改了什么 |
|---|---|
| `ui/view/CircularGaugeView.kt` | 新增 `zoneSegments()`：**`bands` 非空 → 只用它逐段画**；空 → 回落老路径 `warnHigh → maxVal` **那一段**。按段取色 + 按段透明度 |
| `ui/view/BarGaugeView.kt` | 新增 `bandPaint`（与描边用的 `markPaint` **分开**，混用会让 `style` 互相打架）；`bands` 非空 → 按比例画在轨道上，**画在填充之下**，圆角端头靠 `clipRect` 保住。**没有 `bands` 时这一段什么都不画** |

**两处刻意的取舍**：

1. **圆表的绘制顺序保持原样**（分区在数值弧**之前**）。工具侧 v2.88.0 把顺序调成了
   "分区在上"（值进红区时红区不被进度弧盖住）—— 那是**另一件事**，会动到
   **所有存量红区的像素**（见 §2.117），需要单独一轮 + 拍板。本版**只做"App 侧认这个字段"**，
   不动存量像素。
2. **条形表的分区画在填充之下**（与工具侧 style 2 同一取舍）：条上的填充是**主读数**，
   分区压在它上面会把读数整段盖住（50% 的油量条会显示成"整条红"）。

⚠️ **一个真踩到的坑**：`AlertPulse.mix()` 的返回值**把 alpha 写死成 `0xFF`**（它只混 RGB）。
所以色带的 `alpha` 必须在 `mix()` **之后**再上 —— "先 alpha 再 mix"等于没上，
而症状是"给色带写了 alpha 但车上一点不变"，**不报错**。

### ③ 补上工具侧**故意欠下**的跨语言断言

v2.87.0 的「App 侧待办」第 2 条写着：

> ⚠️ **`BAND_*` 常量做完后必须补一条 `verify-crosslang.js` 断言**……
> **这一版故意没加**（App 侧还没有这些常量，加了必红）。
> `verify-bands.js` 里已经有一条断言**反过来**守着这件事。

本版**两条都动了**（缺一条就是"守卫指着错的方向"）：

| 文件 | 改动 |
|---|---|
| `tools/icarui/tests/verify-crosslang.js` | **+12 条断言**：`MAX_BANDS` / `BAND_ALPHA_MIN` / `BAND_ALPHA_MAX` **逐字比**（先断言"解析到了"再比 —— 常量被改名时 `eq(null,null)` 会**静默通过**）；`BAND_DEFAULT_COLOR` 因为两侧**类型不同**（工具 `"#FF4D4F"` 字符串 / App `0xFFFF4D4F.toInt()`）**归一成 `#RRGGBB` 再比** |
| `tools/icarui/tests/verify-bands.js` | 第 0 节那条**反过来**的断言**翻面**：从"跨语言比对里**还没有** `MAX_BANDS`"（谁提前加谁红）改成"**必须有** `MAX_BANDS`，且 4 个 `BAND_*` 都在"（谁删了那 4 条谁红） |

⚠️ **为什么不直接比 `BAND_DEFAULT_COLOR` 的字面量**：一个是字符串一个是 Int，
直接比会报**假失败**；而"为了消红把它改成写死同一个字符串"就把这条断言变成摆设了。
所以归一成同一个色值再比（`0xFFFF4D4F` → `#FF4D4F`）。

### ④ `DesignNode.NUMERIC_GAUGE_FIELDS` 与工具侧**仍逐条一致**（刻意**没加** `bands`）

`bands` 是**数组**，而这张清单的用途是"哪些**标量**字段写了非数字要出声"
（`warnNonNumeric` 会对数组项报"不是数字"）—— 加进去会产出**假警报**，
而假警报的代价是用户学会无视整个警告列表。两侧清单**本来就一致**，
本版一个字没动（`verify-crosslang.js` 的 `NUMERIC_GAUGE_FIELDS` 那条照常比对通过）。

### ⑤ 五条向后兼容（**都有断言**）

1. ⚠️ **`bands` 只管"画出来的分区"，`warnLow`/`warnHigh` 继续管报警判定** ——
   报警源始终是 `BaseGaugeView.alertLevel`（由 `warnLow`/`warnHigh` 驱动），
   `bands` **一个字都不参与**。让色带顺带改报警 = **静默改变存量设计的安全语义**。
2. **缺省 = 空 = 完全旧行为**：缺字段 / 空数组 / 全非法一律归一成空表，绘制走老路径。
3. **`MAX_BANDS = 8`**（超出丢掉）· `color` 只认 `#RRGGBB` · `alpha` 夹 0..255。
4. **丢 `from >= to`**、**夹到 `[min, max]`**。
5. **老文件再存一次不会凭空多出 `bands` 键**（空表不写字段）。

### ⑥ 单测：`data/GaugeBandsTest.kt`（19 条）

| 组 | 覆盖 |
|---|---|
| 缺省 = 旧行为 | 缺省是空表 / **旧文件没有 `bands` 键时读成空表且回写不写这个键** / 空表与全非法都不写字段 |
| 逐段 / 往返 | 2 段写出 2 段、`color` 是大写 `#RRGGBB`、**没写 alpha 就不写这个键**、读回来仍是 `null` 不是 255、没写颜色的段 `color == null` 且绘制时才回落兜底色 |
| ⚠️ **不许碰报警语义** | **只加 `bands` 时 `warnLow`/`warnHigh` 仍然是 `null`** / 回写也不凭空长出阈值 / 色带边界与 `warnHigh` 可以不一致（样板 `g_rpmband` 就是黄 6000~7000 + 红 7000~8000 而 `warnHigh` 仍 6500） |
| 边界 | 越界夹到量程 / `from >= to` 丢掉且只丢坏的那段 / 12 段截到 8 / 坏颜色一律 `null`（三位简写、八位带 alpha、缺 `#`、非十六进制）/ alpha 夹 0..255 / 没写 alpha 按 255 画 |
| 脏数据不崩 | 段不是对象 / `from` 是字符串 / 缺字段 / **量程反了** / NaN 与无穷 / 零量程表 |
| 颜色与常量 | `hex` 丢 alpha 通道 / 4 个 `BAND_*` 的口径 / 兜底色必须与老红区**同一个红**（`#FF4D4F`） |

### ⑦ 任务 2 · `docs/11-仪表框架.md` 的 LVGL 两节加警示行

**背景**：那份文档 §四「两条渲染路径」/ §六「已知问题」仍把 **LVGL 渲染路径**当**可选路径**写，
而 LVGL 在 **v1.8.0 就已被放弃**（`Store.Settings.dashEngine` 默认 `0`），
**但代码还在**（`app/src/main/cpp/lvgl` + `LvglDashView.kt`）。
**用户已拍板：保留正文、不删历史**，只在**节首各加一行**：

> ⚠️ **此路径已于 v1.8.0 放弃（`dashEngine` 默认 0），代码仍在但不维护** —— 正文保留以记录当时的判断依据。

**只加了这两行，正文一个字没动**（那是历史记录）。`git diff` 实测就是 `+2` 行 × 2 处。

### 验证

```
powershell -ExecutionPolicy Bypass -File tools\run-tests.ps1
  → com.icar.obd.data.GaugeBandsTest   tests=19  skipped=0  failures=0  errors=0
  → TOTAL=1097  FAILED=0  SKIPPED=0
  → 构建守卫通过 ✅                                exit 0
    （基线 1078 → +19，全部来自新增的 GaugeBandsTest）

powershell -ExecutionPolicy Bypass -File tools\run-browser-tests.ps1 -UpdateBaseline
  → 32 个套件 / TOTAL PASS=1867  FAIL=0
  → ↑ verify-crosslang  157 → 169
  → ↑ verify-bands      129 → 130
  → 下限之和 1867（写入 expected-counts.json）

node tools\check-doc-links.js
  → 扫描 29 份文档 · 候选 745 条 → 失效 0 条 / 已豁免 84 条 ✅

:app:assembleDebug → BUILD SUCCESSFUL
  → dist/iCarOBD-debug-v1.20.22-android.apk
    **7,427,526 B**（7.08 MB）/ 单 ABI `arm64-v8a` / `versionCode=91` / `1.20.22`
    sha256 = 22BC08D01087BE932FCB0D7AC1FCA56E402BF439BC9FA318BC8E7F11CC69C299
    （`aapt dump badging` 核对 `versionCode='91' versionName='1.20.22'`）
```

⚠️ **体积与 v1.20.21 逐字节相同（7,427,526 B）**，所以另外做了两道核对，
而不是"体积一样就以为没重编"：

1. 解出 `classes5.dex` / `classes6.dex`，里面**确实有** `GaugeBand` 与 `com/icar/obd/data/Bands`；
2. `aapt dump badging` 报的是 `versionCode='91' versionName='1.20.22'`。

⚠️ **又踩了一次 v1.20.21 记的"增量打包留垃圾"**（这次是**实测复现**，不是转述）：
改完刻度那一节再 `assembleDebug`（不删旧 APK），产物变成 **7,541,130 B（+113,604 B）**；
`rm app-debug.apk` 后重跑 → **回到 7,427,526 B**。所以**发版前必须删掉旧 APK 再打包**
（构建守卫只查"有没有超 8 MB"，这 113 KB 它不报警）。
⚠️ 另外：`aapt` **读不了含中文的路径**（`Illegal byte sequence` / `no AndroidManifest.xml found`），
要核 `dist/` 里那份就**必须先拷到 ASCII 路径**，或者核 `D:\icarobd\app\build\outputs\...` 那份
（本版两份的 sha256 逐字节相同：`22BC08D0…`）。

### ⚠️ 装机实测：**未完成**（设备不在线）

本版要求的"**真机上分区真的画出来**（逐段取色、与设计里写的 `color` 对上）+
同一块表不带 `bands` 时与改前逐像素相同"**没有做**，原因是**平板不在线**：

```
adb devices -l                    → List of devices attached（空）
Get-PnpDevice（VID_2717，小米）    → Status=Unknown, Problem=CM_PROB_PHANTOM
                                     ProblemDescription: "Currently, this hardware device
                                     is not connected to the computer. (Code 45)."
```

`7E7D7BB4`（Xiaomi Pad 5 Pro）的 USB 节点还在设备树里，但状态是 **Code 45 = 幽灵设备**
（当前未连接）；同时 `REDMI K80 Pro` / `Galaxy Z Flip5` 等**全部** USB 复合设备也都是
`Unknown` —— 看起来是**数据线掉了或集线器断了**，不是 App 或 adb 的问题
（`adb kill-server` / `start-server` / `reconnect offline` / `mdns services` 都试过，列表始终为空）。

**已经准备好的东西**（设备一上线就能直接跑，不用重做）：

| 准备物 | 位置 |
|---|---|
| 两份**只差 `bands` 一个字段**的设计文件 | `stage/bands-verify/bands-with.json` / `bands-none.json` |
| 生成器（可复现，不是手抄） | `stage/gen-bands-design.js`（`node stage/gen-bands-design.js`） |

设计内容（每份 4 块表，**几何与量程完全相同**，右侧两块是对照）：

| 位置 | 表 | `bands` | 期望看到 |
|---|---|---|---|
| 左上 | 圆表 `obd.rpm` 0~8000 | 黄 `6000~7000` `#FFB020` + 红 `7000~8000` `#FF4D4F` alpha 200 | 弧上**两段彩色分区** |
| 右上 | 同一块表（对照） | **无** | **一条分区都没有**（`warnLow`/`warnHigh` 都留空） |
| 左下 | 条形表 `obd.fuel_level` 0~100 | 红 `0~15` + 黄 `15~30` + 绿 `30~100` | 轨道上**三段彩色分区** |
| 右下 | 同一块表（对照） | **无** | **一条分区都没有** |

> 对照表刻意把 `warnLow`/`warnHigh` **都留空** —— 于是"无 `bands`"那一份
> **一个分区都不画**（底轨纯净），像素差一眼可判；而"有 `bands`"那一份的分区
> **只可能**来自 `bands`（没有别的字段能画出颜色）。

**像素判据（拟用）**：截屏后沿圆表弧中心线按角度取样、沿条形表轨道中心线按 x 取样，
逐点分类到"最接近哪个设计色"，并取**紧邻但没有分区的区域**做对照以排除背景干扰
（本项目既有手法）。⚠️ **本节在设备恢复后必须补上实测数据**，否则这一版
"App 侧认得 `bands`"这句话**只有单测支撑，没有真机证据**。

### ⚠️ 遗留 / 没验到的（如实说）

1. **装机实测未完成** —— 见下面的「装机实测」一节（设备当时不在线）。
2. **工具侧 `verify-crosslang.js` 里 `BAND_DEFAULT_COLOR` 的比对是"归一后比"**，
   不是"逐字节比字面量"：两侧类型本来就不同（字符串 vs Int），
   所以这条断言的强度**略低于**另外三个（它挡不住"两边都是 `#FF4D4F` 但 App 侧 alpha 通道写错"
   —— 不过 App 侧的 alpha 通道对绘制**没有影响**，`GaugeBand.colorOf` 只取 RGB）。
3. **圆表的分区仍画在数值弧之前**（值进红区时进度弧会盖住红区）——
   与工具侧 v2.88.0 修好的行为**不一致**。这是**已知的、刻意的**差异：
   改它要动所有存量红区的像素，得单独一轮 + 拍板（§2.117 的遗留里也写着"换半径"这个更彻底的方案）。
4. **`Bands.normalize` 在每次 `onDraw` 里现算**（不缓存）。代价是每帧一个 ≤8 元素的小列表；
   换掉它要引入"缓存 + 失效"，而"忘了清缓存"的症状是"改了设计但表上还是老分区"且不报错。
   圆表侧每帧会因此多两次小分配 —— **没有实测对帧率的影响**（性能基准页没跑）。
5. **`BarGaugeView` 的色带是按比例铺满整条轨道的**（与工具侧 style 2 一致），
   而**圆表的老路径**（`warnHigh`）在 App 侧只画一段 —— 条形表那边**仍然画两条阈值竖线**。
   即：`bands` 与 `warnHigh`/`warnLow` 竖线**会同时出现**在条形表上。
   这是刻意的（竖线是"报警阈值在哪"、色带是"参考分区"），但**观感上是否冗余没有拍板**。
6. **圆表的刻度仍然只看 `warnHigh`，不跟着 `bands` 分段上色** ——
   底轨（弧）已经逐段画了，刻度没有。这是刻意的：刻度属于**存量像素**，
   动它就会让"没有 `bands` 的老设计"之外的东西也变；而"有 `bands` 时刻度要不要
   跟着分段上色"是个**观感决定**，得单独拍板。本版的边界是"让 App 认得 `bands`"，
   不是重新设计盘面（代码里那一节注释写明了"本版一个字没改"）。

---

## v1.20.21 · 2026-10-11 · 🔴 **一次规则弹了两个提示**（系统 Toast + 灵动岛）→ 只留灵动岛 + 预设音效 **4 → 9**（名字说人话）+ 动作行加 **▶ 预览**

**用户原话**：「还有弹出提示的时候是**两个弹出提示**、我只需要灵动岛的版本」、
「规则里增加更多的预设音效」、「弹出提示通知之类的**后面也增加个播放键**、**显示弹出效果啥样**」。

### 🔴 任务 1 · 两个提示各来自哪里

**根因是一处，不是两处** —— `obd/ObdController.kt` 的 `handleAction` 里 `"toast"` 分支
**同时调了两个出口**：

| # | 出口 | 调用点（v1.20.20） | 弹在哪 | 长什么样 |
|---|---|---|---|---|
| ① | **系统 Toast** | `handleAction` 的 `toast(msg)` → `ObdController.toast()` → `Toast.makeText(...).show()` | 屏幕**底部居中**（`Window{… u0 Toast} gr=BOTTOM CENTER ty=TOAST`） | 近白圆角框（`#F8F8F8` 占该区域 53%） |
| ② | **灵动岛** | 同一分支下一行的 `emitAlert("⚠ $msg")` → `MainActivity.onAlert` → `IslandNotice.show` | 屏幕**顶部居中** | 琥珀胶囊（用户当前配色 `#FFB020`） |

**先复现再修（旧包 v1.20.20，设备上装着的就是它）**：规则编辑器「▶ 模拟测试」起
「高水温告警」→ 24 帧连拍，**s03~s06 四帧同屏两处提示**：
`island=YES(6671 px 琥珀)` + `toast=YES(10453 px 近白)` = `prompts_on_screen=2`；
同时 `dumpsys window windows` 在 150 次轮询里有 9 次抓到
`Window{… ty=TOAST … appop=TOAST_WINDOW gr=BOTTOM CENTER}`。

**修法（"不再弹"，不是"藏起来"）**：新增 `data/RuleAlert.kt` —— `AlertChannel` 枚举 +
`RuleAlertRouting.channelsFor(type)`，**一个动作恰好一个可视出口**（返回值长度 ≤ 1，有单测）。
`"toast"` 分支现在只写 `emitAlert(RuleAlertRouting.islandText(msg))`。

⚠️ **没有误伤别处的 Toast**：`ObdController.toast()` **原样保留** —— 编辑器/设置页的
"保存成功 / 校验失败 / 模拟已开启" 那些是**操作反馈**，不是规则提示。这一版实测里
编辑器那句 `模拟已开启：回仪表盘看效果` 照常弹出（`dumpsys` 抓到 1 次，
且**全都在规则触发窗口之外**），正是要保留的行为。

### 任务 2 · 预设音效 4 → 9（名字说人话）

**改前实测清单**：`res/raw` 只有 4 个 wav（`tick_left` / `tick_right` / `warn` / `beep`），
而编辑器里**根本没有选择入口** —— `p1` 是一个自由文本框，用户得**手打** `tick_left`
这种机器名才用得上（打错了 `AudioPlayer` 静默回退 `beep`，现象上完全看不出来）。

**改后 9 个**（新增 5 个，覆盖需求点名的六类语义）：

| 机器名 | 显示名 | 语义 | 时长 | 文件 |
|---|---|---|---|---|
| `tick_left` | 左转向咔嗒 | 转向 | 55 ms | 4,894 B |
| `tick_right` | 右转向咔嗒 | 转向 | 55 ms | 4,894 B |
| `beep` | 提示「哔」 | 轻提示 | 130 ms | 5,776 B |
| `ding` | 轻提示「叮」 | 轻提示 | 220 ms | 9,746 B |
| `dingdong` | 叮咚（双音） | 轻提示 | 400 ms | 17,682 B |
| `success` | 成功「上行」 | 成功 | 300 ms | 13,272 B |
| `fail` | 失败「下行」 | 失败 | 320 ms | 14,154 B |
| `warn` | 警告（三声） | 警告 | 430 ms | 19,002 B |
| `alert` | 严重告警（低音双响） | 严重 | 400 ms | 17,684 B |

**音频全部由代码合成**（`tools/gen_sounds.py`，纯标准库：正弦/钟状泛音/近似方波 + 指数包络）——
**没有下载任何外部音频**（版权干净，且重跑脚本得到逐字节相同的文件）。
采样率 22050Hz/16bit/单声道 = **44 字节/毫秒** → 时长 ≤ 440ms 就自然满足
**"每个 ≤ 20 KB"**（单测逐个量文件大小；`warn` 从 46.8 KB 降到 19.0 KB，
所以**全部 9 个**都在预算内，合计 104.6 KB）。转向灯那两个刻意留 44100Hz
（咔嗒的"咔"在 11 kHz 以上还有能量，降采样会变闷），但它们只有 55 ms。

**三个入口 + 一张权威表**：新增 `data/SoundPresets.kt`（id / 显示名 / 分类 / 说明 / `R.raw`），
`AudioPlayer.sounds` **由它推导**（删掉了原来手抄的 `linkedMapOf` —— 两份表分叉的表现是
"编辑器里有这一条、播放器里没有"，选了不响）。编辑器音效行新增 **🎵 音效库** 按钮
（对话框列出 9 条，选中**立刻试听**）；`RuleAction.describe()` 对内置音效改显示**给人看的名字**
（"播放音效 警告（三声）"），认不出的名字**原样显示**（不许说成"未知音效"——它照样会响）。

### 任务 3 · 动作行加 ▶ 预览

音效行右侧：`🎵 音效库` / `📁 选文件` / `▶`（试听）；**弹提示行与系统通知行也各有一个 ▶**。

| 按 ▶ 的动作类型 | 发生什么 |
|---|---|
| `sound` | 按当前速率/音量试听一次 |
| `toast` | **真的弹一次灵动岛**（当前样式 + 当前文案） |
| `notify` | 真的发一条系统通知（复用规则那条 `notifyRule`，否则"预览和真弹的不一样"） |
| `log` / `gauge` / `vibrate` | **没有 ▶**（效果在日志页/仪表上，给个按了"没反应"的按钮不如不给） |

⚠️ **预览不落盘、不进规则记录、不触发别的动作**：灵动岛预览用的是
`RuleEditorActivity` **自己的** `IslandNotice`（`MainActivity` 那个挂在别的窗口上，编辑器里看不见），
**刻意不走** `ObdController.emitAlert`（那条路会 `VehicleBus.emit` + 通知所有监听者 = 真的触发一次）。
⚠️ 复用的是**同一个** `IslandNotice` + `IslandCapsuleView`，所以"不抢触摸"那三条硬约束
（`isClickable=false` 等）自动继承。⚠️ `onDestroy` 必须 `dismissNow()` ——
它内部有个 50ms 的 `postDelayed` 节拍，不摘掉会一直往主线程投。

**验证**：`run-tests.ps1` → **`TOTAL=1078 FAILED=0 SKIPPED=0`** + 构建守卫 + **exit 0**
（基线 1050 → **+28**：`RuleAlertRoutingTest` 10 / `SoundPresetsTest` 17 / `PidModelsTest` +1）；
`assembleDebug` 通过；APK **7,427,526 B**（+56 KB，v1.20.20 是 7,371,140 B）/
sha256 `1431FECC…` / 单 ABI `arm64-v8a` / `versionCode=90`。

✅ **装机实测**（平板 `7e7d7bb4` / 横屏 2560×1600 / 坐标先 dump 再点；
动手前 `cmd /c adb exec-out run-as … tar cf - files/config` 备份，tar 头 `66 69 6C 65`）：

**① 任务 1（同一台设备，先旧后新）**：旧包 v1.20.20 触发一次 →
**4 帧同屏两处提示**（顶部琥珀 6671 px + 底部近白 10453 px，`prompts_on_screen=2`），
`ty=TOAST` 窗口 150 次轮询命中 9 次。装上新包、**同一条规则、同一串操作**再触发 →
**连续 12 帧（s04~s15）全部 `island=YES(6671) / toast=no(0)`，`prompts_on_screen=1`**；
`ty=TOAST` 窗口 **130 次轮询（约 33 秒，跨 ≥2 个触发周期）命中 0 次**；`logcat` **6 次
`规则触发` 对应恰好 6 条 `[RULE] 提示 | 冷却液温度过高`**（一对一）。⚠️ 唯一那次 Toast 出现在
`12:58:20` / `13:12:40~43`（点「模拟测试」的**操作反馈**）—— 它的窗口在
**首次规则触发（`13:12:43.605`）之前 0.6 秒**就已销毁，全在规则触发窗口之外。

**② 任务 2**：重启后日志 `音效已登记 | tick_left,tick_right,beep,ding,dingdong,success,fail,warn,alert`
（**9 个**）；点 🎵 → 对话框标题 `选择音效（共 9 个预设）`，**9 条逐条读出**
（`左转向咔嗒 tick_left` … `严重告警（低音双响） alert`）；**逐个点一遍** →
9 条 `试听音效 | name=<id>` + 9 条 `已选择预设音效 | <id> · <label>`，
**`播放失败` / `音效加载失败` 0 条**；音效行的 ▶ 也验了（`试听音效 | name=alert`）。

**③ 任务 3**：点弹提示行的 ▶ → 日志 `预览灵动岛提示（不落盘） | 冷却液温度过高`，
截图 **`before` 0 处提示 → `preview`/`preview2` 各 1 处（琥珀 4931 px）**，
与 `before` 逐像素差分只出**一个连通块**（y82~160 / x1104~1456，编辑器顶部居中）；
点系统通知行的 ▶ → 日志 `预览系统通知（不落盘） | 冷却液温度 > 105℃` +
`dumpsys notification` 里出现 `pkg=com.icar.obd channel=icar_rule`、
`android.title=车辆告警`、`android.text=冷却液温度 > 105℃`。

**④ 收尾**：装完、跑完 9 次试听、弹过灵动岛与通知之后，
**5 个 config md5 与动手前备份逐个相同**（`dash/enabled/pids/rules/settings`）——
这一条同时证明"预览不落盘"；再从备份 `tar xf` 还原一遍并**再核一次 md5（5/5 相同）**；
预览留下的那条通知已消失（`dumpsys notification` 里 `com.icar.obd` 无 `NotificationRecord`）。

⚠️ **遗留（如实）**：
· **音效只验到"点了会播、没报错"** —— `adb` 抓不到音频，**没有听感验证**
（"叮咚像不像门铃"这类判断只能靠耳朵）；
· **灵动岛的像素判据用的是"琥珀色块"**（用户当前配色 `#FFB020`），换配色后这套判据失效
（判据脚本留在 `stage/v12021-verify/`，不是产品代码）；
· **`notify` 动作的真机验证是"预览"这一条路**，规则真正触发时那条 `notifyRule` 路径
本轮没单独跑（与预览**同一段代码**，但没跑就是没跑）；
· **`gauge` / `vibrate` 没加 ▶**（见上表），如果用户想要"振动预览"要另开一轮；
· ⚠️ **顺手修了别人刚提交的一处单破折号**（不是本版范围）：构建守卫报
`docs/22-下一步-表盘制作与动效方案.md` 第 274 行 —— 那是英文引文里的
`come baked in` 紧跟一个单破折号再加 `including`，改成「破折号前后各留一个空格」
（英文 em dash 加空格本来就规范），**只动这 1 处**；不改的话 `run-tests.ps1`
的构建守卫是红的、退出码 1。

### ⚠️ 顺带发现：`assembleDebug` 增量打包会往 APK 里留 206 KB 垃圾

本轮实测到的**可复现现象**：同一个 commit、连续跑两次 `assembleDebug`，APK 从
**7,427,526 B 涨到 7,634,035 B**（+206 KB），而两次的**内容压缩总和只差 0 字节**
（`CompressedLength` 求和都是 7,249,309）。用 Python 按**中央目录**逐条算
`header_offset + 30 + name_len + extra_len + compress_size` 与下一条的
`header_offset` 之间的空隙，定位到 **`classes6.dex` 前有 206,229 B、
`classes7.dex` 前有 92,198 B 的空白**（v1.20.20 只有末尾 `kotlin_builtins` 那 91,880 B）。
删掉 `app/build/outputs/apk/debug/app-debug.apk` 重跑 `assembleDebug` → **回到 7,427,526 B**
（与第一次逐字节同尺寸）。
**结论**：这是**打包任务的增量残留**，不是我们的代码/资源变大。
⚠️ **以后发版请核 APK 体积**：`run-tests.ps1` 的构建守卫只看"有没有超过 8 MB"，
**206 KB 的垃圾它不会报警**（本次 7.63 MB 照样通过）。
· ⚠️ **写 `stage/*.ps1` 时踩到了老坑的变体**：PS 5.1 读**无 BOM** 的 .ps1 按 ANSI 解码，
  中文注释的 UTF-8 字节被解成 GBK 时**可能产生尾字节 `0x60`（反引号）= 行继续符**，
  把下一行（`$TX0 = 1000; …`）整行吞掉 —— 表现是探针"恒为 0"而不是报错。
  `tools/` 下的 .ps1 有 BOM 守卫，**`stage/` 下没有**，所以探针脚本一律写成纯 ASCII。

---

## v1.20.20 · 2026-10-11 · 🔴 **v2 节点树里 gauge 坐标被 ×360**（导入弹假警报 `右=75600` + `Store.customGauges` 被污染）+ `parts` 上限与非数字警告（两侧成对）+ 浏览器套件"静默跳过"体检

> 任务 1 是上一版装机时挖出来、**明确留着要单独一轮**的那个既有缺陷。
> 它的危害不在渲染路径上（画面一直是对的），在**回退路径**上。
> 任务 2/3 都是同一主题：**让"没在验 / 静默做错事"变成"验不过 / 说出来"**。
>
> 工具版本 **v2.83.0 → v2.84.0**（改了 `schema.js` / `validate.js` 两个产品文件）。

### ① 🔴 v2 节点树的 gauge 坐标被又乘了一次 360

**根因**（与上一轮的判断一致，本轮复核确认）：`DesignNode.parse` 处理
`type == "gauge"` 的节点时**只往 JSON 里注入 `pid`、没注入 `unit` 标记**，
而 v1 的 `DesignFile.parseGauge` **一直注入了**（那里的注释甚至写着
"这个坑是单测抓出来的"）。于是 `GaugeItem.fromJson` 里那句
`val k = if (o.optInt("unit", 0) == CANVAS) 1f else CANVAS` 取到了 **360** ——
设计文件里 `x=30 w=180` 的节点，抽出来的 `gauges[0]` 是 `x=10800 w=64800`。

**为什么原来没抓到**：`DesignFileTest.v2 的节点树能被解析且仪表照常抽出来`
那条断言的是 `assertEquals(0f, d.gauges[0].x)` —— **`x=0` 时 ×360 是恒等变换**，
bug 就在断言底下安然通过。

**复现证据（改前，两处独立证据）**：

| | 证据 |
|---|---|
| JVM | 新增 `DesignCoordUnitTest`（8 条）**7 条红**：`x 被乘了 360 expected:<30.0> but was:<10800.0>`；假警报原文 `gauges[0]（std_0C）超出画布右下角：右=75600 下=57600（上限 360）` |
| 真机 | 用**设备上装着的旧包 v1.20.19** 导入同一份 v2 设计（一块表写在 `x=30 y=40 w=180 h=120`）→ 确认框原文：`⚠️ 1 条提示（不影响导入）：· gauges[0]（std_0C）超出画布右下角：右=75600 下=57600（上限 360）` |

**危害不是"多一条警告"**：渲染走 `designJson` 节点树，所以**画面是对的**；
但 `Store.customGauges` 拿到的是污染后的坐标 —— 一旦走「清除导入的设计文件」
回退到扁平表，**整盘表会跑到屏幕外**。`exportDesign()` 也会把 10800 导出。

**修法**（`DesignNode.parse` 的 `TYPE_GAUGE` 分支，与 `parseGauge` **逐字对齐**）：

1. `patched.put("unit", GaugeItem.CANVAS.toInt())` —— 就是这一行（v2 节点是 `CANVAS = 360` 单位）
2. 顺带补上**同一岔口的第二根枝**：`.also { it.legacyGrid = false }`。
   v1 的 `parseGauge` 结尾有这一句、v2 没有 —— 不置位时 `GaugeItem.fromJson`
   会按"元素里有没有 x/y/w/h"自行判断，而 `DashLayout.migrateFromGrid` 一旦
   看到任何一条 `legacyGrid`，就会把**整张盘**的 x/y/w/h 按 2 列网格重算一遍。

**回归单测**：新增 `DesignCoordUnitTest` **8 条** —— 坐标不被乘 360 /
**v1 与 v2 算出的 `gauges[]` 逐字段相等** / 分组内的仪表（递归路径）不被乘 /
**假警报消失** / 真越界两条路都报且文案一致 / `legacyGrid` 两条路一致 /
**多页面（`pages[i].nodes`，第三种入口）** 不被乘 / 节点几何与抽出的 gauge 几何一致。

**修后真机证据**（同一份设计、同一台平板、同一条导入路径）：
确认框变成 `导入设计文件 / 设计：**坐标单位复现盘**… / · 1 块仪表` ——
**`⚠️ N 条提示` 整段消失，`超出画布右下角` 一条都没有**。
再把 `Store.customGauges` **直接读出来**（点「导出画布」，它序列化的就是
`Store.customGauges`，导出文件在 `cache/design.json`）：
`"x": 30, "y": 40, "w": 180, "h": 120` —— 与设计里写的一模一样
（改前会是 10800/14400/64800/43200）。**横屏下再验一遍**，同样干净。

**顺带全库查过"v1 注入了、v2 没注入"这一类分叉**：全仓库只有**两处**注入点
（`DesignFile.kt:668`、`DesignNode.kt:430`），现在两处都注入了 `pid` + `unit`；
其余 4 个 `GaugeItem.fromJson` 调用点（`Backup.kt` / `DashCanvas.kt` /
`Store.kt` 旧 `dash.json`）读的都是**自己写出去**的 JSON（`toJson()` 会写
`unit=360`），旧 `dash.json` 那条**故意不注入**（那正是 ×360 迁移要治的存量格式）。
工具侧全程按画布单位工作、只做 `W / CANVAS`（单位→像素），**没有这个 bug**。

### ② `parts` 加条数上限（两侧）+ "非数字"要出声（两侧）—— 用户拍板，照做

**`parts` 上限**（`window.MAX_PARTS` / `GaugePart.MAX_PARTS` = **64**）：
`MAX_NODES` 数的是节点树的 `children`，`flatten()` **根本不看 `parts`** ——
一块表挂 100 万个部件时 `MAX_NODES=200` 一点忙都帮不上。修复前**两侧还不一样**：
工具侧 `normalizePart` 有一句写死的 `.slice(0, 64)`（**只夹了嵌套那一层**），
顶层 `parts` 无限；App 侧**一层都没夹**。64 **不是新拍的数** ——
它就是那句 `.slice(0, 64)`，只是原来没有名字。两侧**先截断、后报错**
（顺序要紧：反过来先遍历完，内存已经爆了才报错），超限是**硬错误**（与 `MAX_NODES` 同档）。

**"非数字只加警告、不改数值"**：`x="abc"` 现在当 0 —— 改成硬错误会**拒收存量文件**，
所以数值怎么回落**一个字没改**，只让用户知道"这个值被当成默认值了"。
⚠️ 上一轮指出"App 侧拿不到是不是非数字" —— 确实要改读法，但代价可控：
新增 `DesignFile.warnNonNumeric()`，**判据与 `optDouble` 会不会回落同源**
（数字与数字字符串都算数字，见 `OptJsonBehaviorTest` 实测），
在 `DesignNode.parse`（节点 + 仪表）与 `GaugePart.parseAll`（部件）、
以及 v1 的 `parseGauge` 各调一次。`GaugeItem.fromJson` **一个字没动**
（它被备份/画布加载 6 处复用，那里没有 warnings 通道）。
三张字段清单 `NUMERIC_{NODE,PART,GAUGE}_FIELDS` 与工具侧**逐条比对**，
**单边加字段 = 新的跨语言分叉**，所以让它**跑不过**而不是"看人记性"。

**单测**：新增 `DesignNumericGuardTest` **14 条** —— 上限边界（正好 64 过 / 65 拒 /
20 万项被拒**而不是被读进内存** / 嵌套 children 同上限）+ 非数字（给警告但**不拒收** /
**数字字符串不警告且照常生效** / 布尔与对象也警告 / 缺字段与 null 不警告 /
量程与部件字段也警告 / **v1 与 v2 对同一字段给同一条警告** / 清单非空无重复）。
⚠️ **这条改动让工具侧 `verify-bugfix.js` 的一条用例失效**（它靠"5000 个 parts"
造 >1000 条警告，现在是一条硬错误）—— **被测行为一个字没改**，只换了警告发生器。

### ③ 29 个浏览器套件的"静默跳过"体检 —— **找到 6 处，全修**

上一轮只修了眼前那一条（`if (kMax) eq(...)`）。本轮写了一个**括号配平**的扫描器
（行启发式不行：会把 IIFE / 对象字面量 / `cdp.eval` 里的字符串误判成条件块；
第一版行号还因为模板字符串里的换行被吃掉而整体漂移），把 29 个套件里的
`if (…) { 断言 }` / `else { 断言 }` / `try{断言}catch{}` / 提前 `return` /
`forEach` 回调里的断言**全部列出来逐个判断**。台账见
[`tools/icarui/CHANGELOG.md`](../tools/icarui/CHANGELOG.md) v2.84.0 §③ ——
**6 处判为"环境缺失就跳过"（已改成失败）**、**20 余处判为合理（逐条写了理由）**。

**反向验证过**：临时把 `DEFAULT_SIZE` / `NAMES` 改名 → 套件从
**PASS=153 FAIL=0（绿）** 变成 **PASS=153 FAIL=4（红）**。

### 验证

| 项 | 结果 |
|---|---|
| `tools/run-tests.ps1` | **`TOTAL=1050 FAILED=0 SKIPPED=0`** + 构建守卫通过 + `exit 0`（基线 1028 → **+22** = `DesignCoordUnitTest` 8 + `DesignNumericGuardTest` 14） |
| `tools/run-browser-tests.ps1` | **29 套件 / `PASS=1611` / `FAIL=0`**（基线 1596 → **+15**；`verify-crosslang` 139→157） |
| `assembleDebug` | 通过；APK **7,371,140 B** / 单 ABI `arm64-v8a` / `versionCode=89` / `1.20.20` → `dist/iCarOBD-debug-v1.20.20-android.apk` |
| 装机（平板 `7e7d7bb4`） | 升级后 **6 个 config md5 与动手前备份逐个相同**；收尾**还原并再核一遍 md5，6 个全一致**；旋屏设置也还原（`accelerometer_rotation=1` / `user_rotation=0`） |

### 遗留问题（如实）

- ⚠️ **"20000 层"只在真机验了 v2 的 `group` 嵌套**：确认框报
  `nodes[0].children[0]…（33 层路径） 的嵌套深度超过 32 层`、**进程存活、logcat 里
  没有 `StackOverflowError` / `FATAL EXCEPTION` / `OutOfMemory` / ANR**、
  `last-crash.log` 时间戳仍是 01:31（本轮没有新崩溃）。**竖屏与横屏各验一次**。
- ⚠️ **没有视觉复核**（当前模型无图像输入）—— 全部判据来自 `uiautomator` 节点文本
  与 md5 比对，**没有人眼看过一眼**。
- ⚠️ **`parts` 上限的"真机"路径没验**：只到单测（20 万项被拒）。造一个 20 万项的
  `parts` 文件推到平板上导，**本轮没做**（单测已经覆盖了"先截断后报错"这个顺序）。
- ⚠️ **非数字警告的覆盖面**：`canvas.unit` / `designW` / `designH` / `scaleMode`
  **刻意没进清单**（`unit` 的 0 是"没写"的哨兵值，非数字回落 0 与"没写"无法区分），
  所以那四个字段仍然**静默回落**。
- ⚠️ **"套件级 PASS 数基线"这个机制没做**（记在工具 CHANGELOG 的下次优化建议里）：
  本轮的 6 处是**人工扫**出来的；给每个套件钉一个最少断言数才能一劳永逸地
  拦住"断言静默消失"，但那是会影响全部 29 个套件维护方式的机制变更，该单独拍板。
- ⚠️ **20 余处"判为合理"的静默跳过没有加显式保险**（其中
  `AR.cases.every(...)`（`[].every()` 恒为 `true`）与 `SB.用例.forEach`
  是靠"数组空了必然是抛了异常"间接兜住的，属于"能成立但脆弱"）。
- ⚠️ 本轮**只验了导入**这一条路；「清除导入的设计文件」回退到 `customGauges`
  之后**画面上那 1 块表的位置**没有肉眼确认（导出文件里的 `x=30/w=180` 是直接证据，
  但"它画在画布左上角那块区域"是靠这个坐标推的）。

---

## v1.20.19 · 2026-10-11 · 🔴 **14 个跨语言用例静默不跑**（改名后路径没同步）+ App 侧补嵌套深度上限（与工具同一个数）+ `app/` 旧路径引用清零

> 两条任务，一条比一条更像"本仓库最恨的失效形态"：
> **任务 1 = 测试静默不跑**（工具改名成 `tools/icarui/` 之后，`ThemeStudioSampleTest`
> 的 5 个候选路径全部落空，而它用的是 `assumeTrue` → **14 个用例被跳过、汇总行照样绿**）；
> **任务 2 = App 会崩**（工具侧 v2.83.0 给 `parseNode` 加了 `MAX_NODE_DEPTH = 32` 的闸门，
> App 侧**同一个递归结构没有** → 同一份 2 万层嵌套的文件：工具里报友好错误、App 上爆栈）。
> 工具版本仍是 **v2.83.0**：本轮只动了工具侧的**两个测试文件**（`verify-crosslang.js` /
> `verify-rename.js`，都是为了把上面两件事钉住），**没有动工具的任何产品代码**。

### ① 🔴 `ThemeStudioSampleTest` 的 14 个用例在"安静地不跑"

**证据（改前 / 改后都是同一台机器、同一条命令 `tools/run-tests.ps1`）**：

| | `TOTAL=` | `ThemeStudioSampleTest tests=` | `skipped=` | 实际在跑 |
|---|---|---|---|---|
| 改前 | 1022 | 25 | **14** | **11** |
| 改后 | 1028 | 25 | **0** | **25** |

⚠️ **`TOTAL` 从 1022 只涨到 1028（+6 = 本轮新增的 `DesignNodeDepthTest`），不是 +14** ——
Gradle 的 `<testsuite tests="…">` **把被跳过的用例也算进去了**，所以"看总数"这件事
**从一开始就发现不了这个故障**。这也是为什么这一版把 `SKIPPED=` 加进汇总行
并且**只要有跳过就让脚本非 0 退出（3）**（见下）。

**根因**：`sampleFile()` 里 5 个候选路径写的是 `tools/theme-studio/sample.json`，
工具改名成 `tools/icarui/` 之后**一个都命中不了**，而 `loadSample()` 用的是
`assumeTrue(f.isFile)` —— "找不到就 Assume 跳过，不假装通过"。
意图是好的，后果是：**"工具产出的文件 App 到底能不能读"这条跨语言保证一个都没在跑**，
而汇总行是 `TOTAL=1022 FAILED=0` 全绿。

⚠️ 顺带纠正一个**记账错误**：工具侧 `verify-rename.js` 与它的 CHANGELOG 都把这个数字
记成 **12**，实测是 **14**（`skipped=14`，逐个列出用例名核对过）。"记账"本身也会错，
只有真跑一次才知道。

**修法（两件事，第二件比第一件重要）**：
1. 候选路径换成 `tools/icarui/sample.json`；`app/` 里其余 **10 处**旧路径引用
   （7 个文件）一并同步 —— 现在 `grep -rn "theme-studio" app/` = **0**。
2. **`assumeTrue` 换成硬失败**：找不到样例文件就 `throw AssertionError`，
   错误里列出**试过的每一个绝对路径** + 当前工作目录。
   跳过只能用来表达"这个环境缺少某个可选依赖"，**不能用来兜住"我们自己的文件被改名/搬走了"**。
   ⚠️ 源码注释里也**不再写旧目录名**（只写"由旧名改名而来，经过记在 CHANGELOG"）——
   写进去就会被后来的人复制回去。

**顺手堵掉同类雷（全库排查）**：

- `grep -rn "assumeTrue\|Assume\.\|@Ignore\|@Disabled" app/` → **只有那 1 处**（已修）。
  修完再 grep，`app/` 里剩下的命中**全是注释**（本版新增的那段历史说明），**没有第二处静默跳过**。
- `tools/run-tests.ps1`：汇总行加 `SKIPPED=`；**`$skip -gt 0` → 打印红字警告 + `exit 3`**
  （退出码 3 与 gradle 的 1 区分开：1 = 编译/测试失败，3 = **有断言没跑**）。
  一个"跳过也算过"的汇总行是**会骗人的绿**，比没有验证更危险 —— 它让人以为验过了。
- `tools/icarui/tests/verify-crosslang.js`：原来 `MAX_NODES` 那条是
  `if (kMax) eq(...)` —— 常量被改名/删掉时**整条断言静默消失**（套件照样绿）。
  同一种形态，已改成"解析不到就是失败"。**这类 `if (常量) 断言` 是 JS 侧的 `assumeTrue`**，
  本版只修了眼前这一条，其余套件**没有逐个体检**（见遗留）。

### ② App 侧 `DesignNode.parse` 补上嵌套深度上限（与工具同一个数）

**先证明它是真的会崩（不是理论风险）**：临时停用闸门后跑新增的回归用例，
`DesignNodeDepthTest > 20000 层嵌套 —— 不爆栈` **FAILED，异常就是
`java.lang.StackOverflowError`**（`at StringConcatHelper…`，即递归里拼 `$path.children[$i]` 那一步）。
恢复闸门后同一批用例全绿。

- `data/DesignNode.kt` 加 `const val MAX_NODE_DEPTH = 32`（注释写明
  **"必须与 `tools/icarui/js/schema.js` 的 `window.MAX_NODE_DEPTH` 成对改"**）。
- 闸门放在 `parse()` **第一句**（必须在递归之前），判定与文案与工具侧
  `if ((depth || 0) > window.MAX_NODE_DEPTH)` **逐条对齐**：
  `$path 的嵌套深度超过 32 层 —— 多半是文件损坏（正常设计不会超过 4 层：页面 → 分组 → 卡片 → 文字）`。
  根节点 depth=0、`children` 传 `depth + 1`，**与工具侧同一个语义**（第 33 层，0 起算）。
- 新增 `data/DesignNodeDepthTest.kt`（**6 条**）：上限常量就是 32 / **33 层以内不误伤** /
  **34 层报友好错误** / **20000 层不爆栈且只报一条** / 20000 层的**文本**不崩 /
  正常 4 层设计照常通过（防"把闸门写成永远报错"也能全绿）。
  ⚠️ 用例**必须用"手工迭代搭 `JSONObject` 树"走 `parse(root)`**：`parse(text)` 里
  `JSONObject(text)` 被 `runCatching` 包着，太深的文本会先在 JSON 解析器那层爆栈、
  被吞成一条"JSON 语法错误" —— **光喂字符串的话，没有闸门这条用例也照样绿**
  （实测确认：20000 层文本用例在停用闸门时仍然通过）。所以两条路都测，各守一件事。
- **跨语言钉住**：`verify-crosslang.js` 加
  `ok(从 DesignNode.kt 解析到 MAX_NODE_DEPTH)` + `eq(tool.MAX_NODE_DEPTH, kMaxDepth)`。
  ⚠️ **反向验证过**：把 App 侧常量临时改成 33 → 套件精确报
  `嵌套深度上限一致（MAX_NODE_DEPTH）（工具 32 vs App 33）`，`FAIL=1`。

### ③ 装机实测（平板 `7e7d7bb4`，v1.20.18 → v1.20.19）

动手前备份 `files/config`（`cmd /c` + `adb exec-out run-as … tar cf -`，tar 头 `66 69 6C 65`）。

- **升级安装**：`versionCode=88` / `versionName=1.20.19`；**5 个配置 md5 与备份逐个相同**
  （`dash.json 4700da540512` / `settings.json 2a917a587169` / `rules.json 439303dffc52` /
  `pids.json d75171398898` / `enabled.json 99914b932bd3`）。
- **导入一个"工具导出的设计包"仍然正常**（这一版的真正判据：改路径最容易把导入弄坏）：
  用**工具自己的模块**造包（`stage/v12019-import/make-pack.js`，加载
  `tools/icarui/js/{schema,model,presets,zip,pack}.js` 走同一条 `buildPackage`，
  自检 `verifyZip` 通过，6962 B / 5 个条目）→ 推 `/sdcard/Download/` → 从界面
  「仪表盘 → 设置 → 导入画布」走 SAF 选它 → 确认框：
  `已解开设计包：3 个素材（解出 5 个文件）` → 点「导入」。日志：
  `已解开设计包 | 文件=import-test.icarzip … 素材=3 解出=5 警告=0 设计=导入回归 v1.20.19`、
  `已导入设计文件 | canvas=画布 2 file=import-test.icarzip name=导入回归 v1.20.19 gauges=2 …`；
  设置页 `最近导入：import-test.icarzip · 2 块表 · 10-11 03:49`、该套画布从 `gauges=6` 变成
  `自定义仪表（设计文件） · 2 个仪表`。**解压出的 3 个 PNG md5 与
  `tools/icarui/assets/warning/` 里的源文件逐个相同**
  （`056c22c1343da7c76a4eb7891cc1d87d` / `0a31056ff0b16ae9f00d5f7da6a4d3fe` / `fd43745fc833264213fe4f6a3c7acd6a`）。
- **画出来了**（screencap 像素统计，`stage/v12019-import/analyze.js`，零依赖解 PNG）：
  全屏非背景像素 **23.08%**；按设计里 0..360 画布坐标折算的三个节点区域分别是
  转速表 **64.25%** / 水温表 **32.04%** / 水温灯 **7.46%**，而右下角**空白对照区 0.33%**。
  证据图 `stage/v12019-import/after-import.png`。
- **验完把设备还原**：`am force-stop` → 把备份的 5 个配置拷回 → **md5 与备份再次逐个相同**，
  并删掉这次导入产生的 `files/design/1791661745889`。

### ④ 🟡 装机时**顺带发现**的一个既有缺陷（**本版没改**，见遗留）

导入确认框里出现了两条**假警报**：

```
· gauges[0]（std_0C）超出画布右下角：右=75600 下=86400（上限 360）
· gauges[1]（std_05）超出画布右下角：右=115200 下=64800（上限 360）
```

`75600 = 210 × 360`、`115200 = 320 × 360` —— **坐标被乘了 360**，正是 v1.9.0 那个坑
（`DesignFile.parseGauge` 的注释里写着"必须注入 unit 标记再交给 fromJson，这个坑是单测抓出来的"）。

**v1 那条路修了，v2 节点树那条路没修**：`DesignNode.parse` 只注入了 `pid`：

```kotlin
val patched = JSONObject(o.toString())
patched.put("pid", pid)                       // ← 没有 put("unit", 360)
val g = GaugeItem.fromJson(patched)           // 元素里没有 unit → k = 360
```

**实测确认**（临时探针，跑完即删）：v2 里节点写 `x=30 y=60 w=180 h=180`，
`DesignFile.gauges[0]` 拿到的是 `x=10800 y=21600 w=64800 h=64800`（**×360**）
并附带那条"超出画布"假警报；同一份数据走 **v1** 的 `gauges[]` 则是 `x=30 w=180`、**无警报**。

影响面：① 每一份**带 gauge 节点的 v2 设计**导入时都会多出"超出画布"的假警报
（用户会学会无视整个警告列表）；② `CanvasSettingsFragment.applyDesign` 会把这份
×360 的值塞进 `Store.customGauges`（渲染走的是 `designJson` 节点树，所以**画面是对的**，
本轮像素证据也证明了），但它是 `DashCanvas.gaugeCount` /「改用我存着的 N 块表」那条路上的地雷。
⚠️ **属于既有缺陷（与本版两处改动无关）**，**本版刻意没动** —— 它是行为变更、
影响所有 v2 设计，要单独一轮回归（见遗留）。

### ⑤ 任务 3（只核实 + 建议，未动手）

**两侧真的完全一致** —— 用工具真实代码与 App 真实代码各跑了一遍（不是读注释）：

| 行为 | 工具（`js/validate.js`） | App（`DesignNode.parse` → org.json `opt*`） |
|---|---|---|
| `x="abc"` | `0` | `0.0` |
| `w="abc"` | `120`（默认值） | `120.0`（默认值） |
| `rotation="abc"` / `scale="abc"` | `0` / `1` | `0.0` / `1.0` |
| 上面的情况有没有报错/警告 | **0 错误 0 警告** | **0 错误 0 警告** |
| `parts` 条数 100 / 5000 / 50000 | 全部接受 | 全部接受 |
| 机制 | `num(v,d)`：`Number("abc")`=NaN → 返回 d | `JSONObject.optDouble("x", d)`：非数字 → 返回 d（`OptJsonBehaviorTest` 已实测钉住） |

**建议（请拍板，本轮一个字没改）**：
- **`parts` 无条数上限** —— 建议**两侧一起加**一个上限（比如 64），并且**在工具侧加**
  （编辑器是入口，早拦早好）+ 在 `verify-crosslang` 里把常量钉住；
  只改一侧会造成新的分叉（一边拒收、一边照收）。
- **非数字静默回落** —— 建议**只加警告、不改数值**：`x="abc"` 已经静默变成 0，
  改语义（报错/拒收）会**拒绝掉存量文件**；而"给一条警告"能保住兼容性又能让用户看见。
  代价：`DesignNode.parse` 现在对 x/y/w/h 只调 `optDouble`、**拿不到"是不是非数字"**，
  要判断得改读法（`o.has(key) && !o.isNull(key)` + `optString` 后试解析），
  这是**解析层的行为变更**，同样值得单独一轮。

### 验证

| 项 | 结果 |
|---|---|
| `tools/run-tests.ps1` | **`TOTAL=1028 FAILED=0 SKIPPED=0`** + 构建守卫通过 + **exit 0**（基线 `TOTAL=1022`，但其中 **14 条是跳过的**；本版 **+6** 条新用例） |
| `ThemeStudioSampleTest` | `tests=25 skipped=0`（改前 `tests=25 skipped=14`） |
| `tools/run-browser-tests.ps1` | **29 套件 / `PASS=1596` / `FAIL=0`**（基线 1590；`verify-crosslang` 139→**142**、`verify-rename` 29→**32**） |
| `assembleDebug` | 通过；APK **7,371,140 B** / 单 ABI `arm64-v8a` / `versionCode=88` / `1.20.19` → `dist/iCarOBD-debug-v1.20.19-android.apk`（`aapt dump badging` 核对过） |
| 装机 | 见 ③（升级 + 导入工具导出的设计包 + 像素证据 + 配置还原） |

### 遗留 / 没验证到的（如实）

1. 🔴 **v2 那条 ×360 没修**（见 ④）—— 一行就能修（`patched.put("unit", GaugeItem.CANVAS.toInt())`），
   但它改的是**所有 v2 设计**的 `DesignFile.gauges`，要配一轮回归（v2 坐标 + 假警报消失 +
   `customGauges` 不再被污染）**并且先让用户拍板**。
2. 🟡 **`if (常量) 断言` 这种 JS 侧"静默跳过"只修了 `MAX_NODES` 一条** ——
   其余 28 个套件**没有逐个体检**（本次 grep 只覆盖了 Kotlin 的 `assumeTrue`/`@Ignore`）。
3. 🟡 **任务 3 的两条只给了建议、没改**（用户明确要求先报告）。
4. ⚠️ **没有视觉复核**（当前模型无图像输入）：画布"画出来了"是**像素统计**（非背景占比）
   得出的，不是人眼看过；灯是暗是亮、两个表盘好不好看**没看**。
5. ⚠️ **`DesignNodeDepthTest` 的 20000 层只验到 JVM**：真机上 Android 的 `org.json`
   与测试用的 `org.json:json:20231013` **递归行为可能不同**（JVM 侧实测：2 万层文本会先在
   `JSONObject(text)` 那层爆栈、被 `runCatching` 吞成"JSON 语法错误"）—— 也就是说
   **"设备上到底会不会崩"没有真机复现过**，闸门是按"两条路都必须安全"来加的。
6. ⚠️ **`DesignNode.parse` 的 `depth` 只从 `nodes`/`pages[].nodes` 入口传 0**；
   `GaugePart.parseAll` 的 depth 上限 5 是**另一套**（没动）。
7. ⚠️ 设备是**竖屏 1600×2560**（`wm size`），与历史记录里的横屏不一致；本版像素判据
   按竖屏折算，**横屏没验**。

## v1.20.18 · 2026-10-11 · 🔴 **修模拟信号崩溃（空 range）** + 日志页观看体验三项（等宽对齐 / 跟随开关 / 长按复制）

> 任务 1 = v1.20.17 里「**只出方案、未实现**」的那三项（用户已批准方案，直接做）；
> 任务 2 = 一条**既有崩溃**（与本轮无关，但它会打断规则模拟，所以值得修）。
> 工具版本仍是 **v2.82.0**：**本轮我没有改 `tools/` 下任何一个文件**。
> ⚠️ **但工作区里 `tools/` 正在被另一个写者并发改动**（`tools/theme-studio/` → `tools/icarui/` 改名、
> `check-build-guard.ps1` / `run-browser-tests.ps1` 与若干 `docs/*.md` 也被改过，
> mtime 02:44~02:45，**与本版无关、不在本版范围内**）—— 因此本版**没有重跑浏览器套件**
> （我这边工具侧零改动），且本轮的单测/守卫是在**那个并发改动已经落进工作区之后**跑的。

### ① 🔴 模拟信号崩溃：`Cannot coerce value to an empty range`（`SignalSimulator.valueOf`）

**证据**（平板 `7e7d7bb4`，`files/last-crash.log`，2026-10-11 01:31:12，当时跑 v1.20.16）：

```
java.lang.IllegalArgumentException: Cannot coerce value to an empty range:
  maximum 120.5 is less than minimum 122.0
  at com.icar.obd.obd.SignalSimulator.valueOf(SignalSimulator.kt:136)
  at com.icar.obd.obd.SignalSimulator.tick(SignalSimulator.kt:300)
  at com.icar.obd.obd.SignalSimulator$ticker$1.run(SignalSimulator.kt:99)
```

**根因 —— 不是配置传反、也不是默认值有问题，是 UI 的 ± 档位可以合法地把两端推反**：

`Channel.min` / `Channel.max` 是**两个各自独立的可变量**，而 `SimulatorActivity.rangeSide`
只把**每一端**夹在 **PID 的量程**里（`(value ± step).coerceIn(pidMin, pidMax)`），**从不看另一端**
→ `min` 能合法地越过 `max`。`valueOf` 再拿它们去 `coerceIn(min, max)`，空区间就抛。

实机那一条是**冷却液温度**（PID 量程 -40~215 → 步进 `255/20 = 12.75`，自动通道起点 20~95）：

| 操作 | 结果 |
|---|---|
| 「最大」按 **+** 两次 | 95 → 107.75 → **120.5** |
| 「最小」按 **+** 八次 | 20 → … → 109.25 → **122.0** |

两端**各自都在 PID 量程内**，合起来 `coerceIn(122.0, 120.5)` → 抛。
（这两个数与崩溃消息里的 `120.5 / 122.0` **逐位吻合** —— 用 float32 复算过。）
异常抛在主线程且**没人接** → **进程被杀**（日志有 `01:31:13 ===== iCar OBD 启动 =====`），
而且 `ticker` 里 `postDelayed` 那行**执行不到** → **模拟永久停摆**。

**修法（结构上不可能再抛，四层）**：

1. `Channel.lo` / `Channel.hi` = `minOf/maxOf(min, max)`，**`valueOf` 只认这两个** ——
   `lo ≤ hi` 恒成立 → `coerceIn` 的空区间**结构上不存在**；
2. `Channel.normalized()` / `withMin()` / `withMax()`：改一端**不允许越过另一端**
   （`SimulatorActivity` 的 ± 改走这里 → 从源头杜绝）；
3. `stepRange()`：档位步进**两端先归一再夹**（PID 量程被写反时也不抛）；
4. `demoChannel()` / `update()` / `rebuildFromPids()` **入表前一律归一**；
   另给 `ticker` 加一层兜底（`runCatching` + 记一条 E），保证「再出别的意外也只是少一拍，不是停摆」。

⚠️ 顺带堵掉一条**潜在入口**：`demoChannel` 原来直接用 `p.minVal/p.maxVal`，而
`PidDefinition.fromJson` 对导入的 JSON **没有 min<max 校验**（`PidDraft` 有、CSV 导入也有 ——
只有 JSON 这条路没有）→ 量程写反的 PID 会让演示通道跟着反。

**✅ 装机实测**（平板 `7e7d7bb4`，v1.20.18，坐标先 dump 再点）：

| # | 构造 | 实测结果 |
|---|---|---|
| 1 | 模拟器 → 冷却液温度 → 展开 → 「最大」+2 次 → 「最小」+8 次 | 界面显示 **`最小 120.500` / `最大 120.500`** —— 最小**停在上界**，没有变成 122.0 |
| 2 | 上面这套操作**在模拟运行中**做完（旧代码就是在这里崩的） | 进程 pid 不变；`last-crash.log` 仍是 01:31:12 那条旧崩溃；日志里 `模拟信号 tick 异常` **0 条** |
| 3 | **按根因直接构造反向量程**：往 `files/config/pids.json` 塞一条 `min=122.0 / max=120.5` 的 PID → 重启 → 「满量程快扫」→ 「开始模拟」 | 通道 **37 个**（含该条）；界面显示 **`RevRangeTest  120.500~122 x`**（归一成 lo~hi）；连续 tick **30 秒无崩溃、无 tick 异常**；`grep -c 'empty range'` = **0** |

（第 3 步动过 `files/config/pids.json`，**验完立刻从备份还原**，5 个配置 md5 与动手前**逐个相同**。）

**单测 8 条**（`SignalSimulatorTest` 28 → **36**）：反向量程不抛 / 反向量程与正向量程产出同一区间 /
相等量程不抛且恒等于该点 / 极端量程（±`Float.MAX_VALUE`）不抛且不产生 NaN /
`normalized()` 摆正且正常通道返回自身 / **实机那条 ± 序列走一遍后 min 不再越过 max 且 `tick` 不抛** /
`tick` 遇到反向量程的通道不抛 / PID 量程写反时演示通道与档位都不反。

### ② 日志页：等宽对齐（`AppLog.Entry.format()`）

时间戳 `HH:mm:ss.SSS` 恒 12 位、级别恒 1 位，**只有模块列宽度在跳**（`UI` 2 vs `AUDIO` 5）
→ 每换一个模块，后面整行横移，屏幕上一半的行错位。

修法：`AppLog.MODULE_WIDTH = 5`，模块**左对齐补到 5 位**。
⚠️ 补位放在 `Entry` 的**体属性**里（构造时算一次），**不放进 `format()`** ——
`format()` 是 `LogAdapter.bind` 的每行路径，而日志页的性能红线是「**不加任何 per-bind 的分配**」；
放体属性还顺带不进 `equals/hashCode/copy`（既有语义零变化）。
比 5 位更长的模块**不截断**（宁可那一行不对齐，也不把模块名改掉 —— 日志是拿来排查问题的）。

**✅ 证据**（同一份日志文件里新旧格式并存，一眼看出差别）：

```
[02:30:56.502][UI][D] 渲染画布 | …          ← v1.20.17 写的（模块列不定长）
[02:40:16.973][SYS  ][I] ===== iCar OBD 启动 ===== | ver=1.20.18 sdk=33
[02:40:17.025][AUDIO][I] 音效已登记 | tick_left,tick_right,warn,beep
[02:40:17.052][RULE ][I] 规则已加载 | count=5
[02:40:17.064][BLE  ][I] 发起连接 | addr=41:42:86:9B:2E:7E name=null
[02:40:17.247][UI   ][D] 切换页面 | dash
```

`[SYS  ]` / `[AUDIO]` / `[RULE ]` / `[BLE  ]` / `[UI   ]` 宽度全是 5，
`][级别]` 与正文起始列逐行对齐；`uiautomator dump` 读到的 `tvLog.text` 同样是补位后的
（例：`[02:40:17.247][UI   ][D] 切换页面 | dash`）。

**单测 7 条**（新增 `AppLogFormatTest`）：时间戳/级别定长 + 模块补到 5 位 /
8 个内置模块正文起始列恒定（= 25）/ 1~5 字符模块同列 / 5 个级别下级别列与正文列都不动 /
`extra` 不影响列 / 超 5 位模块不截断（只影响自己那一行）/ 补位不进 `equals` 与 `copy`。

### ③ 日志页：跟随开关（滚上去看历史不再被拽回底部）

原来只有「暂停滚动」，而 `uiTick` **每 250ms** 都会 `rv.scrollToPosition(最后一行)` ——
用户滚上去看历史时**每 250ms 被拽回底部**，等于看不了历史。

修法：`rv` 加 `OnScrollListener`，**滚离底部 > 2 行就自动 `paused = true`**，
按钮文案跟着变（跟随中 `暂停滚动` ↔ 已暂停 `回到底部`）。
⚠️ **复用现有 `paused` 字段，不新增状态**；监听器里**只读**（不滚动、不 notify、不 requestLayout）——
它和 250ms 的 `uiTick` 抢同一个 RecyclerView，在里面动手就会互相打架（v1.18.4 那个 ANR 的同类）。
「回到底部」做成**同一个按钮的暂停态文案**（点它 = 关掉 paused + 立刻 `scrollToPosition`）：
`paused = false` 之后下一拍 `uiTick`（≤250ms）本来就会滚到最后一行，
再单独加一个「继续滚动」会是**同一个动作**，多一个只会让人犹豫按哪个。

⚠️ **判据用行号、不用像素**：`computeVerticalScrollRange` 对长列表是
**按已布局行的平均高度外推**的估计值，而行高并不相等（正文会折行）→ 3000 行时偏差足够大，
**贴着底也会被算成「还差几行」→ 一打开日志页就自动暂停、跟随直接失效**。
改用 `findLastVisibleItemPosition()`（精确行号，同样**只读、不分配**）。

**✅ 装机实测**（dump 逐次对比，统计行 `显示 42 条 · 缓冲 42 条`）：

| 步 | 动作 | 实测 |
|---|---|---|
| 1 | 基线（未滚动） | 按钮 `暂停滚动`；首行 `[02:40:17.247]` @y293、末行 `[02:43:24.296]` @y1499 |
| 2 | 向上滑（看历史） | 按钮变 **`回到底部`**；统计行追加 **`· 已暂停滚动`**；首行 `[02:40:16.973]` @y293、末行 `[02:42:12.818]` @y1547 |
| 3 | **停 2.5 秒不再触碰** | 首行/末行/位置**逐字节相同**（`[02:40:16.973]` @y293）→ **没有被拽回底部** |
| 4 | 点「回到底部」 | 按钮回 `暂停滚动`；首行/末行/位置**与第 1 步基线完全一致** → 真的回到底了 |

### ④ 日志页：长按整行进剪贴板

`LogAdapter.VH` 挂 `setOnLongClickListener` + `ClipboardManager`
（沿用检视器那套写法：剪贴板不可用**要说出来**；**API 33+ 系统自己会弹「已复制」浮标**，不再自己弹）。
⚠️ 监听器在 `init` 里挂**一次**、不在 `bind` 里挂（per-bind 分配 = 性能红线）；
文案直接读 `tv.text`（对已是 `String` 的 CharSequence，`toString()` 返回自身，不再分配）。
`textIsSelectable` **保留不动**（长按由本监听器接管并返回 `true`，点击/拖选原行为不变）。

**✅ 装机实测**（剪贴板读不到，用 MIUI 的剪贴板事件日志**逐字节核对长度**）：

| # | 长按哪一行 | 该行文本 | 期望 UTF-8 字节 | MIUI `extend_data len=` |
|---|---|---|---|---|
| 1 | y=500（`ObdService 已启动`） | `[02:40:17.448][SYS  ][I] ObdService 已启动` | **45** | **45** ✅ |
| 2 | y=435（`状态变更 \| CONNECTING …`） | `[02:40:17.441][BLE  ][D] 状态变更 \| CONNECTING 连接 41:42:86:9B:2E:7E` | **75** | **75** ✅ |

两次都伴随 `UniClipUniversalClipDataPublisher: onPrimaryClipChanged`，
且长按后 `uiautomator dump` 里**没有**出现文本选择工具条（`复制`/`全选`）→
`textIsSelectable` 与长按复制**不冲突**、事件被我们的监听器接管。
⚠️ `adb shell service call clipboard 2` 在 API 33 上**被拒**
（`Denying clipboard access to …, application is not in focus`）→ **读不到剪贴板原文**，
上面的字节数比对是能做到的最强证据。

### 明确**没做**（v1.20.17 已评估并获批准跳过，本轮照旧不动）

- ❌ 关键字高亮（per-bind 造 `Spannable` → 撞性能红线）
- ❌ 级别/模块多选 chips（会把筛选区撑到 2~3 行）
- ❌ 折叠相邻重复行（`AppLog` 已有抑制；列表层改 `notifyItemInserted` 增量路径**改错就是
  `Inconsistency detected` 崩溃**，v1.3.0 实车踩过）
- ⚠️ 性能红线一个字没碰：**没动 500 上限、没动 250ms 合并刷新、没加任何 per-bind 分配**。

### 验证

- `tools/run-tests.ps1` → **`TOTAL=1022 FAILED=0`**（基线 **1007** → **+15**：
  `SignalSimulatorTest` 28 → **36**（+8）/ 新增 `AppLogFormatTest` **7**）+ **构建守卫通过** + **exit 0**；
- 工具侧**零改动** → 浏览器套件仍是 **27 套件 / 1473 全过**（未重跑，`tools/` 下无改动文件）；
- `assembleDebug` 通过；APK **7,371,148 B**（与 v1.20.17 同尺寸 —— 巧合，已用 dex 字符串核对确认
  新代码在包里）、`versionCode=87` / `versionName=1.20.18`、单 ABI `arm64-v8a`；
- 装机：`adb -s 7e7d7bb4 install -r` → `Success`，`dumpsys package` 读出
  **`versionCode=87` / `versionName=1.20.18`**；升级前用 `cmd /c adb exec-out run-as … tar cf -`
  备份 `files/config`（tar 头 `66 69 6c 65` = `files/co`，**不是** `FF FE`），
  **升级后 5 个配置 md5 与备份逐个相同**；① 第 3 步临时改过 `pids.json`，**已还原并复核 md5**。

### 遗留 / 没验到的（如实）

1. **没重跑浏览器套件** —— 工具侧本轮零改动（`tools/` 下没有文件被改），故按惯例未重跑；
2. **长按复制的剪贴板原文读不到**（API 33 限制）→ 用 MIUI 剪贴板事件的**字节长度比对**代替（见 ④），
   **没有真正把内容粘到某个输入框里肉眼看过**（App 里只有 MainActivity 是 `exported=true`，
   `am start` 进不去带 `EditText` 的页面，而日志页本身没有输入框）；
3. **`textIsSelectable` 的「拖选文本」这条原行为没单独验**（只验了长按不被选择工具条抢走）；
4. **跟随开关的自动暂停只验了「手指滑动」这一种路径**：双指手势 / 惯性甩动 / 顶部回弹没单独造；
   ⚠️ 另外**故意没做「滚回底部自动恢复跟随」**（规格只要自动暂停）—— 用户手动滑回底部时
   按钮仍是 `回到底部`，点一下才恢复；
5. **① 里 `ticker` 那层兜底（`runCatching`）没有单独造异常验过** —— 它只是「再也不能因为一条通道
   而停摆」的保险，本轮验的是根因那一层（归一）；
6. 面板/列表的**外观没有视觉复核**（当前模型无图像输入）：列对齐的证据是 dump 文本与日志文件字节，
   **不是「人眼看过一眼」**。

---

## v1.20.17 · 2026-10-11 · **UI 改进三项**：检视器面板加「清除」+ CAN 过滤器预设 4→12 条（说人话）+ 文案优化

> 规格：[`25-下一步-UI改进四项.md`](25-下一步-UI改进四项.md)（用户 2026-10-11 提的四项，**已确认清楚**，含用户对第 1 项的选择）。
> ⚠️ **第 4 项（日志页观看体验）按规格要求"先给方案再动手"，本轮只出方案、未实现** —— 见文末「遗留」。
> 工具侧**一个字没动**（`tools/theme-studio/` 零改动），所以工具版本仍是 **v2.82.0**，浏览器套件 **27/1473** 不变。

### ① 检视器面板加「清除」按钮（用户已选 **B**）

**用户原话**：「检视器悬浮窗的按钮旁边加个按钮、按钮功能为 清除记录、按下后清除选中的记录」，
我给了 A/B/C 三个候选，**用户明确选了 B**：

> **B：面板只显示当前检视结果，按钮 = 清空面板内容（回到"点屏幕上任意控件查看信息"的占位）**

**做法**（`ui/view/UiInspectorOverlay.kt` + `data/UiInspectorInfo.kt`）：

- 「检视 开/暂停」药丸**旁边**加一个小药丸 `清除`（`UiInspectorInfo.CLEAR_LABEL`），
  与开关**同一套写法**（小 `TextView` 而不是 `Button`：320dp 面板塞不下，且触摸热区越小越好）；
- 点了 → `clearPanel()`：清描边高亮 + 把面板刷回占位 + 重对齐暂停态（`applyPausedToPanel` 内部**幂等短路**）；
- ⚠️ **只清内容，不动检视开关**：`enabled`/`paused` **一个都不写**（判据："检视状态不变"）；
- ⚠️ **占位文案是唯一一份**：`PLACEHOLDER_TITLE` / `placeholderLines()` 由 `show()` 与 `clearPanel()`
  **共用** —— 两处各写一遍字面量的话，"清除后回到占位"这条判据迟早靠不住（有单测钉着）；
- ⚠️ **它自己的点击不能被检视消费掉**：与开关同一条路 —— 命中判定 `isOnPanel` **先排除浮层自己**，
  宿主据此把这一次触摸交回 `super`；
- ⚠️ **不改任何 `layoutParams`**：面板宽度是常量、高度是 `WRAP_CONTENT`，
  清除只改文本 → **一次 `requestLayout` 都不会多触发**。

**顺带修两条文案**（同属规格 §3）：
- `HINT_OPS` 加上「清除 = 只清面板内容」（面板上多了按钮，提示里不提它，用户只会看见一个不知道干什么的小药丸）；
- `HINT_PAUSED` 原来写「点**左上角**「检视 暂停」恢复接管」—— 而那个药丸在**标题行右侧**（不是左上角），
  照着找会找错地方；现在只说"点那个药丸"，**不编方位**。

**✅ 装机实测**（平板 `7e7d7bb4` / 横屏 2560×1564，坐标先 `uiautomator dump` 再点）：

| 步 | 动作 | 实测结果 |
|---|---|---|
| 1 | 开检视 | 面板 = `控件检视` + `点屏幕上任意控件查看它的信息`（占位） |
| 2 | 点 `tvCurrentCanvas` | 面板 = `MaterialTextView` / **`tvCurrentCanvas`** / `尺寸 675.6×15.6dp（实测；声明 MATCH_PARENT × WRAP_CONTENT）… 层级 … > MaterialTextView` |
| 3 | 点「清除」 | 面板 = **`控件检视` + `点屏幕上任意控件查看它的信息`**（**回到占位**）；`检视 开` **不变** |
| 4 | 点 `btnCanvasTheme` | 面板 = `MaterialButton` / **`btnCanvasTheme`** / `尺寸 675.6×40dp… 层级 … > MaterialButton`（**又有内容**） |

四步里 `检视 开` **一直是 `检视 开`**（判据"检视状态不变"）；`tvSniffFilterNote` 式的小字与药丸 bounds 全程一致。

**✅ 像素证明"面板变高变矮不会把画布顶开"**（`stage/shot-t*.png`，`stage/compare-region.ps1`）：

- **噪声底 = 0**：占位态（`t1`）与占位态（`t3`，中间夹了两次点击 + 两次 dump）**全屏 4,003,840 px 逐点相同（0 变化）**；
  同状态连续两次截图也是 **0**；
- **面板内部**（正控，`[49,1364]-[725,1520]`）占位 vs 有内容 **changed = 21537 / 105456 = 20.42%**（证明比对有效）；
- **面板之外**：页头（`y0..200`）**0**、页尾（`y1470..1564`）**0**、面板右侧整块（`x760..2560`）的差异**全部落在"被检视那个控件自己的 bounds 内"**
  （`y=260` 那 1526 px 正好是 `tvCurrentCanvas` 的 `x 518..2042`）—— 那是**检视器给焦点控件上的高亮/焦点色**，不是位移；
- 判据"是不是整体位移"用**逐行扫描 + 偏移搜索**（`stage/find-offset.ps1`，−6..+6 行）验过：
  **没有任何一个偏移能把差异降到 0**（最优点就是 offset 0 = 10.37%，两侧对称升高）→ **不是位移，是元素变色**。

### ② CAN 探测的过滤器预设：4 → 12 条

**用户原话**：「优化CAN探测的过滤器预设、增加更多预设」。原来只有 4 个，而且**名字是 AT 语法**（`ATCM700+ATCF400`）。

**新增 `data/CanFilterPresets.kt`**（纯数据 + 纯函数，19 条单测）—— 预设表与"过滤串 → 实际 AT 命令"的解析
**都不写在 `CanSnifferActivity` 里**（那边一碰 Android 就跑不了 JVM 单测）：

| # | 标签（**人话**） | 值 | 说明要点 |
|---|---|---|---|
| 1 | `不过滤（整条总线）` | （空） | 最全的 ID 清单，代价是采样率摊薄（实测约 77 帧/秒 ÷ 80 个 ID = 每 ID 1 帧/秒） |
| 2 | `转向灯 0x09A（本车实测）` | `228` | **本项目唯一实测确认过的信号**（`docs/15-CAN-信号库与逆向框架.md` + v1.19.8）；0.7 → **20 帧/秒** |
| 3 | `全部 11 位 ID（高三位掩码）` | `ATCM700+ATCF000` | 等价于不过滤，但**只看 11 位 ID**（29 位被掩码挡掉） |
| 4 | `OBD 应答 0x7E8` | `7E8` | 只看诊断应答；⚠️ 过滤期间正常轮询收不到别的应答（收尾会 `ATAR` 清掉） |
| 5~12 | `0x000~0x0FF` … `0x700~0x7FF` | `ATCM700+ATCF<段>00` | 8 段，每段 256 个 ID 全采样率 |

⚠️ **三条硬要求（规格 §2 点名，全部有单测钉着）**：

1. **预设名说人话**：标签里**不许出现 AT 语法**（有单测扫全部 12 条）；命令退到下面那行说明里。
   用户要的是"选哪个能看见什么"，不是 AT 语法。
2. **⚠️ 不许编"哪个灯在哪个段"**：本项目**从没实测过**各灯在哪个段，所以常用段
   （`0x2xx`/`0x4xx`/`0x6xx`）的说明**只写「常见车身域（未在本车实测）」**，
   **一个灯名都不许点名** —— 单测里有一张禁用词表（转向灯/刹车灯/倒车灯/车门/车灯/大灯）逐条扫。
3. **⚠️ `ATCF000` 是全总线、不是「第 0 段」**：单独一行小字（`FULL_BUS_NOTE`）
   **只在"不过滤"与"选了全总线那条"两种状态下露出来**，写明"单独的 `ATCF000` 会放行全部 11 位 ID"
   + "要只看 `0x000~0x0FF` 请用带掩码的 `ATCM700+ATCF000`"。

**⚠️ 一个实测踩到的歧义**：`ATCM700+ATCF000` **同时**是"全部 11 位 ID"和"`0x000~0x0FF` 段"
（掩码之下它才等于第 0 段，见 `SegmentRotation` 的长注释）→ **两条预设的 `value` 逐字节相同**。
所以 `findAll` 会返回两条、`describe` 把**两条说明都写出来**（只报第一条的话，用户选中它只看到"等价于不过滤"，
会以为段 0 不见了）；按 value 反查标签会查到错的那一条 —— **单测第一版就是这么错的**（得到 9 个段而不是 8 个）。

**判据"选中后状态行显示实际下发的 AT 命令"**：过滤器框下面新增一行 `tvSniffFilterStatus`，
文本由 `CanFilterPresets.resolveCommands()` 算出来，而它与 `CanSniffer.start()` 里真正下发的那段
**同一套规则**（空 → 一条都不发；`AT` 开头按 `+`/`;` 切、**不转大写**；其余 → `ATCRA${uppercase()}`）。
⚠️ 两处各写一份的话，界面会**自信地显示一条根本没发出去的命令**，比不显示还糟 —— 有单测逐条对照。

**✅ 装机实测**：

- 预设条上 12 条都在，横滑能看到 `0x300~0x7FF`（8 个段一个不少）；
- 点 `转向灯 0x09A（本车实测）` → 输入框 = `228`、chip `checked=true`、
  状态行 = `本车实测确认过：转向灯在 0x09A（低两位）… 命令 ATCRA228` + **`下发 ATCRA228`**；
- 点 `全部 11 位 ID（高三位掩码）` → 状态行 = 两条预设说明 + **`下发 ATCM700 → ATCF000`**，
  **全总线小字 VISIBLE**；
- 点 `0x400~0x4FF` → 状态行 = `常见车身域（未在本车实测）：0x400~0x4FF 这 256 个 11 位 ID 全采样率。命令 ATCM700+ATCF400` + **`下发 ATCM700 → ATCF400`**，
  **全总线小字节点不存在**（`GONE`）。

### ③ 文案优化（与 ② 同批）

**原则**（规格 §3）：说人话 · 空态说清"为什么空 + 下一步" · 错误说清"怎么办"。

**改前 → 改后**（逐条）：

| 位置 | 改前 | 改后 |
|---|---|---|
| CAN 页空态 | `暂无数据。` | **分五种状态**：还没探过 →「还没探测过。点上面的「开始探测」；想先缩范围就点一行预设（每条都写着能看到什么）」/ 正在跑 →「探测进行中，还没有收到帧…等本趟跑完，如果仍是空的，换成「不过滤（整条总线）」再探一次」/ 失败 →「这一趟探测失败了…点「开始探测」重来一次」/ 常驻监听占着 →「点上面的「停止常驻监听」，再点「开始探测」」/ 跑完 0 帧 →「最可能的原因：过滤器太窄（这个 ID 本车根本没人发）…换成「不过滤（整条总线）」」 |
| CAN 页 `IDLE` 状态行 | `未开始。探测期间会暂停轮询引擎，并临时打开 ATH1（带 CAN 头）。只记录**变化了的**数据…` | `未开始。探测期间会暂停轮询（转速/水温这些会冻结），并临时打开 ATH1（带 CAN 头）。…` + **`点上面的「开始探测」开始；先点一行预设缩范围，采样率会高得多。`**（说清下一步） |
| CAN 页 `DONE` 状态行 | `按出现次数排序。次数高但「变化次数」低的 ID 通常是周期性心跳。` | 追加 **`要对上实物（如拨一下转向灯），用下面的「对比基准（找位）」：连跑两次再点它。`**（说清下一步怎么用） |
| CAN 探测 0 帧 | `到时自动停止 · 共 0 帧 / 0 个 ID` | 追加 **`⚠️ 一个帧都没收到。过滤器太窄（这个 ID 本车没人发）或车没在总线上说话时就是这样；换成「不过滤（整条总线）」再探一次。`**（错误说清"怎么办"） |
| 过滤器输入框 hint | `如 228，或 ATCM700+ATCF400 扫一段；留空=不过滤` | `留空=全收；也可只填一个 ID（如 09A）`（hint 不该是 AT 语法教学，点预设就行） |
| 日志页空态 | （**原来根本没有空态**，只有一行 `0 条`） | 新增 `tvLogEmpty`：**分三种原因**「这里没有可显示的行 —— 模块筛的是「X」，而缓冲区里那 N 条都不是这个模块。把上面两个下拉框都调回「全部」就能看到全部 N 条」/ 级别挡 → 同理 / 缓冲区本来就空 →「还没有日志。App 一用就会写（连接适配器、开轮询、跑规则都会留痕）；刚清空过、或刚装完还没连过车时，这里就是空的」 |
| 日志页统计行 | `12 条（缓冲 3000）` | `显示 12 条 · 缓冲 3000 条（只显示 W 及以上（警告与错误）、只看 OBD 模块）`（**两个数字不相等是常态**，不写清条件用户会以为日志丢了） |
| 日志级别下拉 | 描述由下拉框自己写 `V/D/I/W/E`（用户会奇怪"选了 W 为什么还有 E"） | `levelFilterText()`：`W 及以上（警告与错误）` / `E` → `只有 E（错误）` —— **判据是 `prio >= 选中级别`，不是"等于"** |
| 检视器面板 | `长按复制 · 拖动移动 · 右上角 × 关闭` | `清除 = 只清面板内容 · 长按复制 · 拖动移动 · 右上角 × 关闭` |
| 检视器暂停提示 | `已暂停：触摸已放行，App 可以正常用；点左上角「检视 暂停」恢复接管` | `…点「检视 暂停」恢复接管`（**不编方位** —— 药丸在标题行右侧） |
| 设置页检视摘要 | `已开启：点任意控件看它的类型 / ID / 样式；右上角 × 或本开关可关闭` | 追加 **`面板上的「清除」只清面板内容（不影响开关）`** |

**新增 `data/LogViewText.kt`**（纯函数，10 条单测）—— 日志页文案的唯一来源。
⚠️ **性能红线**（规格 §4）：这一份**只有字符串拼接、没有任何集合拷贝**，
且空态可见性**只在 `updateStats()` 里翻**（那是 250ms 合并刷新的落点），
**没有**挪进 `AppLog.addListener`（每条日志都跑 = 撞红线）。

### ④ 日志页观看体验 —— **本轮只出方案，未实现**（规格 §4 要求"先给方案再动手"）

读代码后**先纠正了两处与规格描述不符的现状**：`item_log.xml` **已经是 `fontFamily="monospace"`**
且已有 `textIsSelectable="true"`；`LogAdapter.VH.bind()` **已经按级别染色**（E 红/W 橙/I 白/D 灰/V 更灰）。

逐条取舍（已提交给用户确认）：

| 候选 | 判断 | 理由 |
|---|---|---|
| 等宽 + 对齐 | **做** | 时间戳定长 12、级别定长 1，**只有模块列宽度在跳**（`UI` 2 / `AUDIO` 5）→ 每行 `[级别]` 与正文都错位。修法 = `AppLog.Entry.format()` 里模块**左对齐补到 5 字符**（纯函数、零主线程开销、可单测） |
| 按级别染色 | **已有**，不再动 | —— |
| 关键字高亮（`7F`/`NO DATA`/`原因=`） | **跳过** | 每行扫 N 个子串 + 造 `SpannableStringBuilder`，而 `onBindViewHolder` 在突发洪泛时每秒被调几十次 —— 正是规格点名的性能红线 |
| 跟随开关 + 滚上去自动暂停 | **做**（价值最高） | 现在只有「暂停滚动」，用户滚上去看历史时**每 250ms 被拽回底部** |
| 长按复制单行 | **做**（低成本） | `setOnLongClickListener` + `ClipboardManager`，只在长按时跑 |
| 级别/模块改多选 chips | **跳过** | 会把筛选区从 1 行撑到 2~3 行，而日志页高度全给列表；替代做法（模块标签说人话 + 统计行写出筛的是什么）**已在 ③ 里做了** |
| 折叠相邻同内容行 | **跳过** | `AppLog` 层已有「重复 N 次已抑制」；列表层再折叠要在 `add()` 的 `notifyItemInserted` 增量路径上维护位置映射 —— **改错就是 `Inconsistency detected` 崩溃**（v1.3.0 实车踩过）。风险 > 收益 |

### 验证

- `tools/run-tests.ps1` → **`TOTAL=1007 FAILED=0`**（基线 **973** → **+34**：
  `CanFilterPresetsTest` **19** / `LogViewTextTest` **10** / `UiInspectorInfoTest` 39 → **44**（+5 条清除相关））
  + **构建守卫通过**（唯一警告是"APK 文件名写的是 v1.20.16，而 gradle 是 1.20.17"—— 已在发版时换掉）+ **exit 0**；
- `tools/run-browser-tests.ps1` → **27 套件 / `TOTAL PASS=1473 FAIL=0`**（**基线不变** —— 工具侧零改动）；
- `assembleDebug` 通过；APK **7,371,148 B**、`versionCode=86` / `versionName=1.20.17`、单 ABI `arm64-v8a`；
- 装机：`adb -s 7e7d7bb4 install -r` → `Success`，`dumpsys package` 读出 **`versionCode=86` / `versionName=1.20.17`**。

### 遗留 / 没验到的（如实）

1. **第 4 项（日志页）本轮没实现** —— 规格 §4 明确要求"先给方案再动手"，
   方案已交（上表），**等确认**。所以本版的日志页只改了 ③ 的文案与空态，**等宽对齐 / 跟随开关 / 长按复制整行都还没做**。
2. **"状态行显示的命令 = 真正下发的命令"只做了单测层面的同规则对照，没有真机下发** ——
   要真机验证得**已连接适配器**（`CanSniffer.start()` 要求 `ObdController.isConnected()`），
   而本轮平板没连车。代码层面两者是同一套规则（有单测逐条对照 + 注释交叉引用）。
3. **`ATCF000` 段 0 那条预设的"选中高亮"落在哪一条**：因为两条预设 value 相同，
   点"全部 11 位 ID"时高亮的是它（第一条），点段 0 chip 时 `setupFilterPresets` 里
   `current == p.value` 会让**两条都高亮** —— 本轮**没在界面上单独确认这一点**（没点段 0 那条 chip）。
4. **面板外观没有视觉复核**（当前模型无图像输入）：面板/药丸的证据来自 `uiautomator` 节点
   （文案 / `contentDescription` / `bounds`）与截图像素统计，**没有"人眼看过一眼"**。
5. **`清除` 按钮在「检视 暂停」态下没单独验** —— 暂停时面板本体 `isClickable=false`、
   `dragListener` 被摘掉，但药丸（开关 / 清除 / `×`）本身仍是 `isClickable=true`，
   所以**理论上仍可点**；本轮验的是「检视 开」态。同一条路（`isOnPanel` 先排除浮层）已经覆盖，但**没实测**。

---

## v1.20.16 · 2026-10-11 · 🔴 **19 个指示灯里 16 个永远不会亮**（拖出来永远是暗的）+ 告警闪烁降到 ≤3 Hz（WCAG 2.3.1）

> 两条都来自 [`18-控件库优化建议.md`](18-控件库优化建议.md) 的 P0。
> 工具侧同批发 **v2.82.0**（`tools/theme-studio/CHANGELOG.md`）。

### 🔴 修复 1：16 个指示灯的状态系统是**死的**（**用户会以为车没问题**）

**症状**：从控件库拖一个「胎压灯」出来，它**永远显示暗的 `lamp-off.png`**。
能拖、能摆、能存、能导出、构建守卫不报 —— 所以**用户会以为车没问题**，
而不是"这个灯没接上"。这是这个库里**最贵的一条**。

**根因链（三处代码，缺一条都看不出来）**：

| # | 位置 | 做了什么 |
|---|---|---|
| 1 | `tools/theme-studio/js/presets.js` 第二批 16 个灯 | 写的是 `n.pid` / `n.rawPid`，**不是 `statePid`**（第一批 3 个灯写对了） |
| 2 | `ui/dash/NodeTreeRenderer.kt` `resolveState()` | **只读 `node.statePid`**，`isBlank()` 就 `return STATE_NORMAL`，根本不看 `pid` |
| 3 | `tools/theme-studio/js/model.js` 的 `nodeToJson`（`NODE_IMAGE` 分支） | **只序列化 `statePid`/`states`**，`pid`/`rawPid` 被丢掉 → 连设计文件都进不去 |

**净结果**：设计文件里既没有 `statePid` 也没有 `pid`，灯永远是 `normal`。

**实测计数**（实例化全部 122 个控件后读回）：

| | 修复前 | 修复后 |
|---|---:|---:|
| `states` 非空 | 19 | 19 |
| `statePid` **有值** | **3** | **19** |
| `statePid` 为空 | 16 | 0 |

> ⚠️ **语义变了，不是"修好了 12 个不存在的 PID"**：这 16 个灯绑的 PID 大部分
> **还不存在**（等 P9 上车逆向），改完之后 `guard-pid-probe.js` 照旧报它们 12 条待办
> —— **那是对的**。区别是：以前"压根没接线"，现在"线接好了、等数据"。

### 🔴 修复 2：告警闪烁全部超 WCAG 2.3.1 的「每秒不超过三次」

标准原文：*"Web pages do not contain anything that flashes more than
three times in any one second period..."*（Level A）

| 位置 | 修复前 | 换算 | 修复后 |
|---|---|---:|---|
| `ui/view/AlertPulse.kt` 危险档 | `square(nowMs, 200, 0.5f)` | **5.0 Hz** | 400ms = **2.5 Hz** |
| 控件库第一批灯 `critical.blinkMs` | `220` | **4.5 Hz** | 400ms |
| 控件库第二批灯 `critical.blinkMs` | `260` | **3.8 Hz** | 400ms |
| 工具侧下限 `Math.max(60, …)` | `60` | **16.7 Hz** | 400ms |

**周期的唯一真源**：`data/DesignNode.kt` 的 `NodeState.MIN_BLINK_MS = 400`。
`AlertPulse.CRITICAL_PERIOD_MS` 直接引用它（不是另写一个数）；
工具侧 `window.MIN_BLINK_MS` 与它同源，由 `tests/verify-crosslang.js` 逐条比对守着
（**只改一侧是静默失效**：只改 App → 工具里还能调到 60ms；只改工具 → 老设计文件照闪 16.7Hz）。

**三处落地 + 两道守卫**：

| 落地 | 位置 |
|---|---|
| 渲染路径 | `NodeTreeRenderer.applyStates` 的 `coerceAtLeast(NodeState.MIN_BLINK_MS)` |
| 解析路径 | `NodeState.parseAll` 的 `coerceAtLeast(MIN_BLINK_MS)`（**文件里写 100ms 也不许照闪**） |
| 工具侧 | `validate.js` / `app.js` / `editor.js` / `panels.js` |

| 守卫 | 断言 |
|---|---|
| Kotlin（`AlertPulseTest`） | **直接数 10 秒的上升沿**换算 Hz ≤ 3.0 —— 而不是断言"常量等于 400"（后者在有人把 duty 改成 0.25、一轮亮两次时照样绿） |
| Kotlin（`NodeStateTest`） | `MIN_BLINK_MS` 换算 ≤3 Hz、文件里写 60ms 也被抬到 400ms、合规值不被改 |
| 工具（`verify-crosslang.js` §3b + `verify-lamp-state.js`） | 两侧下限逐字一致、全库无低于下限的闪烁周期、`Math.max(60, …)` 不得残留 |

> ⚠️ **危险档的 `square` 没有一起降成 `pulse`**：`DashRenderer` 只以 **5 Hz 的 tick**
> 采样状态相位（"不引入第二个动画驱动"）。400ms 周期下每周期恰好 **2 个采样点**，
> 闪烁照旧可见 —— 反而比原来更稳：修复前的 200ms **正好等于一个 tick**，
> `(nowMs / 200) % 2` 与 tick 同频，采样点可能**恒落在同相位**。

### 新增测试

- **`app/src/test/.../data/NodeStateTest.kt`（11 条）** —— 状态系统的数据层契约。
- **`AlertPulseTest` +4 条** —— 危险/警告档的闪烁频率红线、`tintMix` 与 `intensity` 相位一致、
  下限常量与数据层同源。
- **`tools/theme-studio/tests/verify-lamp-state.js`（新套件，36 条）** —— 全库
  「`states` 非空 ⇒ `statePid` 非空」断言（**跑全库，不是只查那 16 个**）、
  胎压灯接线、序列化、往返、闪烁下限三路（全库 + 输入夹取 + 解析夹取）、跨语言一致性。
- **`verify-crosslang.js` +7 条**（见上表）。另把一条老断言
  「blinkMs 原样读入 150」改成「150 被抬到 400」—— 原来那条钉的正是要修掉的行为。

### 顺带修掉的两个问题

1. **`validate.js` 与 `model.js` 的 `statePid` 不同源**（工具侧）：
   `validate.js` 直接抄 `o.statePid`、而且**不设 `rawStatePid`**。后果是
   **导出再导入之后**编辑器里状态 PID 输入框变成空的（`std_05` 认不出别名），
   **再保存一次就把 `std_05` 写回文件**（丢掉可读的语义别名）。由新套件的往返用例抓到。
2. **`docs/12-主题设计大纲.md` 的过期数字**：§2.40 写「116 / 319 / 容器·基础 3」、
   §2.44 素材合计写 328 且**少列一类**、§2.45 又提素材 344 —— 同一份文件多个数字互不相同。
   按实测统一为 **122 控件 / 355 素材 / 40 PID**，并新增 §2.113 / §2.114 记录本轮两条修复。

### 验证

- `tools/run-tests.ps1`：**973 全过**（958 → 973）+ 构建守卫通过
- `tools/run-browser-tests.ps1`：**27 套件 / PASS=1473**（26/1430 → 27/1473）全过
- `assembleDebug` 通过，APK **7.03 MB** / 单 ABI `arm64-v8a`
- ✅ **装机实测**（小米平板 5 `7e7d7bb4` / 2560×1600 横屏 / Android 13）：
  见下面的「装机验证表」

### 装机验证表（任务 1 的真正判据）

| 步骤 | 结果 |
|---|---|
| 备份 `files/config/*.json` | `stage/tablet-backup-20261011-011226/config.tar`（tar 头 `66 69 6C 65` = "file"，**不是 `FF FE`**） |
| 升级安装 v1.20.16 | `versionCode=85 versionName=1.20.16`；**升级后 6 个配置的 md5 与备份逐个相同** |
| 用**工具自己**造 `.icarzip` | `stage/v12016-lamp/make-lamp-pack.js` —— 加载 `schema/model/presets/zip/pack` 五个**工具模块**，`buildPackage` + `verifyZip` 自检通过；条目 = design.json + 3 素材 + manifest.json |
| 导入 | 日志 `已解开设计包 \| 素材=3 解出=5 警告=0` → `已导入设计文件 \| name=指示灯状态验证 素材=3` |
| 驱动 PID | 「连接 → 模拟信号」36 通道 @10Hz 驱动 `obd.coolant`（`std_05`）；设计里显式阈值 `stateWarn=55 / stateCritical=75` |
| **灯真的会亮** | 同一位置连拍到三种帧：**灭** `rgb(7,16,24)`（纯背景）/ **琥珀** `rgb(255,176,32)`（= `lamp-warn.png` 主色）/ **红** `rgb(255,77,79)`（= `coolant-warn.png` 主色）。三个颜色与素材文件**逐个对上** |
| **对照区** | 紧挨着灯、没有灯的区域（`[426,620,398,120]`）**全程 warm=0%** —— 排除"那里本来就有暖色背景" |
| 对照组控件 | `lamp_coolant`（第一批，本来就对）与 `lamp_temp` **同步**切换 —— 证明两条路径现在一致 |

证据图（从 2560×1600 截图裁出，零依赖 PNG 编解码见 `stage/v12016-lamp/px.js` + `crop.js`）：
`stage/v12016-lamp/evidence-lamp-LIT.png` / `-OFF.png` / `-RED.png`。

### 遗留 / 没能验证的

- ⚠️ **闪烁周期在真机上量不准**：`adb exec-out screencap` 一次要 **536ms**，
  对 400ms 的周期是**欠采样**（实测量出 1106 / 1607ms 的**混叠值**，不是真周期）。
  要量准得换路子（`screenrecord` 拆帧，或让 App 自己把相位写进日志）。
  **本次的 400ms 由单测直接数上升沿钉住**；装机只验到"会亮 / 会变色 / 会闪"。
- ⚠️ 平板横竖屏在验证过程中被系统切过一次（`user_rotation` 被清成 0），
  已重新固定成横屏（`accelerometer_rotation=0 / user_rotation=1`）。
  期间**重装过一次**（同一个 APK，不是重新构建），导入操作重做了一遍。
- 报告里另外几条 P0/P1（多段色带 `bands`、`marker` 阈值标记控件、告警条控件、
  把 12 类闲置素材接进控件库）**本次没做** —— 见 `18-控件库优化建议.md` 表 3。
- `lamp_coolant` 与 `lamp_temp` 是**真重复**（同 PID、同 crit 图，只差闪烁策略），
  报告建议 7 提过合并，**本次没动**（删 key 会让老设计文件里的 `controls` 悬空）。
- ⚠️ **观感**：危险档从 5Hz 硬方波降到 2.5Hz。本次**只用像素证明了它会亮/会变色**，
  **没有**用主观标准判断"冲击力够不够"。若后续觉得不够，
  报告里给的替代方案是"只换颜色、不做明暗交替"（纯色相变化理论上不构成 flash），
  但那要重写 `AlertPulse.tintMix` 那一层，**本次没做**。

---

## v1.20.15 · 2026-10-11 · **修 v1.20.14 的卡死级 ANR**（纯函数死循环）+ 浮窗加「检视 开 / 暂停」开关

> 用户原话：「悬浮窗上面加个检视器的开关」+「开着检视器切页后卡死」。

### 🔴 修复：控件检视开着、点中某个控件 → 主线程死循环 → ANR（**v1.20.14 引入，卡死级**）

**现象**（真机 7e7d7bb4 / Android 13 / 2560×1600 横屏，`logcat -b events` 原文）：

```
I am_anr: [0,15409,com.icar.obd,... Input dispatching timed out
           (... is not responding. Waited 5000ms for MotionEvent(action=DOWN))]
```

`logcat` 里 MIUI 看门狗（`MIUIScout App`）打出的主线程栈，**三次现场完全一致**：

```
at com.icar.obd.data.UiInspectorInfo.chainLine(UiInspectorInfo.kt:226)
at com.icar.obd.data.UiInspectorInfo.render(UiInspectorInfo.kt:324)
at com.icar.obd.data.UiInspectorInfo.renderBody(UiInspectorInfo.kt:342)
at com.icar.obd.ui.view.UiInspectorOverlay.inspect(UiInspectorOverlay.kt:190)
at com.icar.obd.ui.MainActivity.consumeForInspector(MainActivity.kt:904)
at com.icar.obd.ui.MainActivity.dispatchTouchEvent(MainActivity.kt:631)
```

**根因（不是遍历 View 树，也不是浮层挂错父容器）**：
`data/UiInspectorInfo.kt` 的 `chainLine`（父链截断）里那个收敛循环**不收敛**：

```kotlin
while (parts.size > 2 && body.length > CHAIN_MAX) {
    var rest = parts.drop(1)                                   // ← 第一轮之后
    while (rest.isNotEmpty() && rest.first() == ELLIPSIS) rest = rest.drop(1)
    parts = listOf(ELLIPSIS) + rest                            // ← 又加回来
    body = parts.joinToString(SEP)
}
```

第一轮把链首换成省略号之后，**`parts` 的头就是省略号**，于是下一轮
`parts.drop(1)` 恰好只丢掉那个**标记**，紧接着 `listOf(ELLIPSIS) + rest` 把它原样加回来 ——
`parts` 与 `body` 成了**不动点**：只要第一轮之后长度仍 > `CHAIN_MAX`(56)，`while` **永不退出**。

触发窗口很窄但真实：链折叠成 5 段后 `|c1| + |c_{n-2}| + |c_{n-1}| > 42`（长度 59 > 56）就进去。
实测在「连接」页点中一个 `MaterialButton`（父链含
`ContentFrameLayout / LinearLayout / AppCompatImageView / MaterialButton`）命中；
而 v1.20.14 验收时点的 `btnGestures` 父链恰好算出来 53 ≤ 56，**刚好躲过** ——
所以上一版"8 条判据全过"是真的，这个 bug 也是真的，**是覆盖面的问题，不是造假**。

**为什么"切页后才卡死"**：`inspect()` 只在 `ACTION_DOWN` 时解析命中的控件，
而**命中哪个控件决定父链长度**。仪表盘/设置页点到的控件父链短，连接页/PID 页/日志页
里的 `MaterialButton` / `MaterialTextView` 父链长 —— 换页 = 换了一棵更深的树。
（**用户的怀疑方向"反向遍历 View 树卡住"是起点不是结论**：遍历本身没问题，
死在拿到命中控件之后拼字符串的那一步。）

**修法**：收敛条件从"字符串长度"改成 **`dropCount` 单调递增的有界 for 循环**
（轮数上界 `clean.size + 1`），把每轮要拼什么抽成无循环的纯函数 `chainBody(clean, dropCount)`。
**结构上不可能不终止**，不再依赖"每轮真的变短"这个假设。

### 🔧 加固（无论根因是什么都该做的四条，本轮一并落地）

| 要求 | 落点 |
|---|---|
| **遍历必须有界** | 新增 `data/TreeWalkBudget.kt`（纯类，JVM 可测）：深度上限 32 / 节点数上限 4000 / **按身份去重断环**。`UiInspectorOverlay.hitTest` 每次触摸开一个预算，用尽就**收手**（退化成"没检视到"）。`chainOf`（向上找父链）也加了硬上限 |
| **主线程不许做重活** | 坐标查询从"每个节点 `new IntArray(2)`"改成复用 `locTmp`/`baseTmp`；`applyPausedToPanel` 加**幂等短路**（宿主每秒的 ticker 反复调它，状态没变一点都不做，不再每秒新建 `GradientDrawable`） |
| **切页 / `onPause` 安全摘浮层** | `MainActivity.onPause()` 摘掉浮层（只摘视图，**不动** `enabled`/`paused`，`onResume` 原样挂回）；`switchTo()` 末尾立刻对齐一次；`show()` 多一道 `panel?.parent !== h` 检查 —— 挂到失效父容器上会**先摘干净再重建**，不会再出现"开着检视却什么都没有" |
| **异常兜底：放行触摸** | `inspect()` 现在返回 `Boolean`；整段包 `runCatching`（连 `StackOverflowError` 一起接），失败就清高亮 + 面板写明，返回 `false`；`MainActivity.dispatchTouchEvent` 与 `consumeForInspector` 据此**不消费**这一次触摸。**宁可漏检，不能卡死** |

### 新增：浮窗上的「检视 开 / 暂停」开关

用户要的「悬浮窗上面加个检视器的开关」。与右上角 `×` 的分工：

| | 触摸 | 面板 | 恢复方式 |
|---|---|---|---|
| **检视 开**（默认） | 被接管 | 在 | 点一下变「暂停」 |
| **检视 暂停** | **放行（App 正常用）** | **还在** | 点一下变「开」 |
| **`×`** | 放行 | **摘掉** | 回设置页重开 |

- 开关是面板标题行里一个**小药丸 TextView**（不是 `Switch`）：320dp 宽的面板塞不下 Switch，
  而且**可点热区只有这一小块** —— 用户明确要求"面板其余部分仍不抢触摸"，Switch 的热区比看上去大。
- **暂停时面板本体不抢触摸**：`isClickable=false` **并且**把拖动 `OnTouchListener` 摘掉
  （只改 `isClickable` 不够 —— 监听器返回 `true` 照样消费）。面板描边从青转**琥珀**、底部提示换成"触摸已放行"。
- **开关自己的点击不会被检视吃掉**：命中判定 `isOnPanel` **先排除浮层自己**，宿主据此把这次触摸交回 `super`。
- **默认值 = 接管**（`paused = false`，写进 `UiInspectorOverlay.paused` 的注释）：
  默认接管才看得出开关生效，且 v1.20.14 那 8 条判据的语义**一个字都不用改**。
- **暂停不落盘**（与 `enabled` 同一条理由：它是临时状态，App 重启/旋屏都回到接管）。

### 验证

- `run-tests.ps1` → **TOTAL=958 FAILED=0** + 构建守卫通过 + **exit 0**（基线 944 → +14：
  `UiInspectorInfoTest` 33 → 39 条，新增 `TreeWalkBudgetTest` 8 条）；
- `:app:assembleDebug` 过；APK **7,370,856 B**（7.03 MB）sha256=`6723CB47…` 已进 `dist/` 并装机；
- **装机实测**（平板 `7e7d7bb4` / Android 13 / 2560×1600 横屏，坐标一律先 `uiautomator dump` 再点）：

  **① 复现（先证明 bug 是真的）**：v1.20.14 装机包上「开检视 → 切到连接页 → 点画布」
  稳定复现 `am_anr: … Waited 5000ms for MotionEvent(action=DOWN)`；
  `/data/anr/` 里同时躺着**用户报的那一次**（`anr_2026-10-11-00-10-33`）与我复现的那次。
  主线程栈由 MIUI 看门狗打出，**三次现场逐帧一致**，全部停在 `chainLine`。

  **② 任务 1**：检视开着，在**连接 / PID / 日志 / 规则 / 知识库 / 仪表盘 6 个页**
  各点 3~6 下 → `logcat -b events | grep am_anr` **0 条**；
  `uiautomator dump` **2.7s** 返回（主线程没被占住）；
  每页面板都解析出了控件，例如连接页
  `尺寸 655.1×48dp（实测；声明 MATCH_PARENT × 48dp）… 层级 … > AppCompatSpinner > AppCompatCheckedTex…`
  —— 那**正是以前必挂的"从头部丢"那条路径**（现在渲染成 `… > X > Y` 并且**返回了**）。

  **③ 任务 2（17/17 通过）**：ACTIVE 时点 `swSound` 与横滑**都被消费**（开关不动、不翻页）
  → 点面板开关 → 变「检视 暂停」，面板仍在、面板根 `clickable=false`、
  药丸描边色取样 `#00D8FF` → `#FFB300`
  → **暂停后**点 `swSound` **生效**、横滑**能翻页**（画布名 `画布 2` 出现）
  → 再点开关 → 恢复接管（点控件 / 横滑又被消费）→ 右上角 `×` 仍能彻底关闭，关闭后一切正常。

  **④ v1.20.14 那 8 条判据一条没坏**，逐条对过：开关→浮窗出现 · 关掉→消失且触摸恢复 ·
  **检视开着横滑不翻页** · 关掉后横滑恢复 · **画布像素不受影响** ·
  点有 id 控件显示资源名 · 点无 id 控件显示「（无 id）」· 点仪表盘自绘区出提示。
  其中**像素**是逐点比对（画布本体区 `800,200`–`1700,1100`，步长 2 = 202,500 个采样点）：
  `ACTIVE / PAUSED / CLOSED` 三态两两 **changed = 0 / 202,500 = 0.000%**，
  且**同状态重复截图的噪声也是 0**（所以这个 0 不是"截图没变"的假象）。
  自绘区那条命中 `CircularGaugeView`，面板出现 `⚠ 这里是仪表盘自绘区：刻度/指针/数值不是控件，检视不到`。

  **⑤ 新加的 `onPause` 摘浮层**：HOME → 回 App，浮层自动挂回、仍是接管态、页面状态不丢。

### 遗留（如实）

- 新增的 `TreeWalkBudget` 只测到**判定逻辑**（8 条）；"`hitTest` 确实按预算收手"需要
  一棵超过 4000 节点的真实 View 树才验得到，本轮**没有构造**，属未验证。
- `×`（彻底关闭）与设置页开关两条路的**状态一致性**靠代码审查（都走 `setInspectorEnabled`），
  未做自动化断言。
- 拖动浮窗、长按复制仍然只能用手指验（`adb` 发不出这两类手势）。
- **本轮没有"人眼看过一眼"**：当前模型没有图像输入。面板外观的证据是
  `uiautomator` 节点（开关文案 `检视 开` / `检视 暂停`、`contentDescription`、bounds）
  加截图像素取样（药丸描边色）—— 布局是否好看、字有没有被挤掉，**没有人确认过**。
- ⚠️ 动手前那次"整目录备份"（`tar cf -` 重定向）**实际是坏的**：
  PowerShell 的 `>` 把 adb 的 stdout 按 UTF-16 文本写，产物头部是 `FF FE` 而不是 tar 的 `ustar`。
  有效的那份只有单独存的 `settings.json`。收尾时已用 `cmd /c` + `adb exec-out` 重做了一份
  二进制安全的备份（`_dev_backup/post-verify-20261011/`，5 个文件），
  并逐字段核过：**测试前后 `settings.json` 的标量差异 = 0**（`sound` / `activeCanvasId` / 画布套数都没变）。
  **下次备份 config 一律用 `adb exec-out` + `cmd /c` 重定向，别用 PowerShell 的 `>`。**


---

## v1.20.14 · 2026-10-10 · **控件检视器**（点控件看它的类型 / ID / 样式）

> 用户原话：「开启之后显示悬浮窗、**点击控件后悬浮窗会显示控件的类型、ID、样式之类的东西**」。
> 规格：`docs/24-下一步-控件检视器.md`（§2 交互 / §3 显示哪些信息 / §4 硬约束 / §5 与样式总表配合 / §7 验收判据 / §8 明确不做）。
> **只看不改** —— 本版**没有任何一行**去改被检视控件的属性。
>
> ✅ **本版交付前已按用户要求把 `UiScale`（全局字号 / 间距 / 导航栏缩放，设置页那一行叫「界面调参」）
> 整套撤掉** —— 用户明确否掉过这个方向（「实时调参这个不需要了、和我的想法不同」），
> 而且它有一个真 bug：`UiScaleApplier.scaleText` 把 `textSize`（**px**）当 sp 写回
> （`setTextSize` 收的是 sp），于是「1.3× → 恢复默认」之后字号停在 `density` 倍
> （平板 2.25×，11sp 变 **25sp**）—— 它文档里"默认档 = 升级前的样子"**不成立**。
> 撤掉的是 3 个纯 UiScale 文件 + 混在 `Store` / `MainActivity` / 画布设置页里的接线；
> **控件检视器（`UiInspector*`）完整保留**。本节下方凡是与它有关的记录一律标注「已撤」。

### 新增

- **控件检视器**（用户点名要的）。两个新文件，**分层与既有 `FrameRateGate`/`CanvasRebuildPolicy` 同一套路**
  （能跑 JVM 单测的部分全在 `data/`）：

  | 文件 | 干什么 |
  |---|---|
  | `data/UiInspectorInfo.kt` | **纯函数**（33 条单测）：px→dp/sp、四边数值、颜色、父链拼装、整屏内容渲染 |
  | `ui/view/UiInspectorOverlay.kt` | 浮窗本体：面板 + 描边高亮 + **自己遍历 View 树**解析命中 |

  - **入口**：仪表盘设置页（`fragment_canvas_settings.xml`）一个 `MaterialSwitch` `swInspector`，
    与「音效」「手势」「灵动岛」并排；下面一行小字写当前状态（与「手势」「灵动岛」同一写法）。
  - **开启后**：`android.R.id.content` 上挂一个浮层 —— 默认**左下角**（躲开顶部居中的灵动岛
    与顶部的监听警示条），半透明、可拖动、右上角一个 `×` 关闭。
  - **点控件**：`MainActivity.dispatchTouchEvent` 在检视模式下**消费**触摸，
    用 `MotionEvent.rawX/rawY`（屏幕坐标）从 `android.R.id.content` **反向遍历**子 View
    （后加的在上层），递归钻到**最深的那个**；命中后把该控件描边高亮 + 面板显示它的信息。
    （"遍历 View 树"这个思路正是被撤掉那版全局缩放实现唯一可复用的部分。）
  - **长按面板**：全部信息进剪贴板，**第一行带 `控件检视 · 版本号 · 时间`**
    （粘给作者时上下文会丢，裸的一串看不出是从哪台机器、哪个版本复制的）。
  - **`MaxWidthViews.kt` 加 `MaxWidthCapable` 接口**（暴露 `maxWidthPx`）——
    面板因此能显示「限宽 720dp」，而那是 `09-UI样式与排版总表.md` 里搜得到的一项。

- **与 `09-UI样式与排版总表.md` 的配合**（规格 §5，这是这个功能真正的价值）：
  面板第 2 行**单独一行、单独配色（琥珀）**显示 **id 的资源名**
  （`resources.getResourceEntryName`），面板底部常驻一句 **「搜这个 id 到 UI样式与排版总表.md」**。

### 四条"为什么"（都是踩过或差点踩的）

- 🔴 **只在检视模式抢触摸**。`dispatchTouchEvent` 里那一段的第一句就是
  `if (UiInspectorOverlay.enabled && consumeForInspector(ev)) return true` ——
  **关着的时候一次都不进**，与加这段代码之前逐字节等价。判据是 `UiInspectorOverlay.enabled`。
  （v1.20.4 那条贴边把手就栽在"总抢系统手势"上。）
- 🔴 **描边高亮是"整屏一层 + 只 `invalidate()`"，不是"跟着控件走的小 View"**。
  小 View 每次命中都要改 `layoutParams` → 父容器一次 `requestLayout`；
  而这一层**永远 `MATCH_PARENT`**，命中矩形只重画 —— **一次布局都不触发**，
  画布因此不可能因为"点了一下控件"而重排（v1.20.12 那个「画布 0×0」的触发条件就是布局重排）。
- 🔴 **检视开关刻意不落盘**（不在 `Store.Settings` / `settingsToJson` / `applySettingsJson`）。
  它一开就把全部触摸消费掉；跟着 `settings.json` 活到下一次启动的话，用户打开 App 会
  **点哪儿都没反应**，只能以为"装坏了"；而且备份导出会把它带到另一台机器上。
  放在 `UiInspectorOverlay.enabled`（`@Volatile`，进程内）：旋屏重建保持，
  杀进程 / 重启 / 从备份恢复之后一律回到 `false`。**有单测钉着**
  （`UiInspectorInfoTest.检视开关不许进 settings_json`）。
- 🟡 **导航栏在检视模式下必须放行、且保持可见**（实测补的）。
  不加这条会有死胡同：检视模式消费全部触摸，而开关在**画布设置页**（仪表盘 pager 的最后一页，
  **只能靠横滑到达**）—— 于是用户打开检视之后既滑不回去、也切不了 tab，
  **只能检视设置页这一个页面**，"点任意控件"根本做不到。
  现在：导航栏的触摸**放行**（但**照旧 `inspect` 一次**，点导航栏也能看到它的信息），
  并且检视期间 `if (railHidden) setRailVisible(true)`。导航栏是本项目**悬浮**的
  （v1.20.4：平移不占布局），所以让它显示**不会改变画布尺寸**。

### 显示纪律（规格 §3）

- **拿不到就明说"（无）"，不编**：非 `TextView` 的字号/颜色行写「（无）」；
  `wrap_content` 的控件没有"声明的宽高"，就写
  「尺寸 120×40dp（实测；声明 WRAP_CONTENT × 40dp）」。
- **id 必须是资源名**（不是数字）—— 数字拿去搜样式总表搜不到任何东西。拿不到资源名才是「（无 id）」。
- **背景**：`Resources.getResourceName` 要的是**资源 id**，而 `View.getBackground()` 给的是已经
  inflate 好的 `Drawable` —— 公开 API 里**没有**"这个 Drawable 是哪个资源"这条路（规格 §6 也预告了）。
  所以：**尽力反射** `mResourceId`（先看 Drawable 自己、再看它的 `ConstantState`，结果按类缓存、
  全程 `runCatching`），**拿不到就退化成类名**（`背景 RippleDrawable（无资源名）`）——
  **绝不编一个看起来像资源名的假名字**。
- **父链**：层数多就中间省略；还是太长就**从头部按整段丢**（尾部 = 最近的父容器，最有用）。
  实测踩过：第一版从尾巴砍，最有用的一段显示成 `… > M…`（`MaterialTextView` 被砍成 `M…`），
  等于什么都没说 —— 现在有单测钉着（`父链太长时从头部丢，尾部永远完整`）。
- **仪表盘自绘区必须给提示**（规格 §8）：命中 `BaseGaugeView` / `DashGridOverlayView` 时，
  面板额外出一行 **「⚠ 这里是仪表盘自绘区：刻度/指针/数值不是控件，检视不到」** ——
  免得用户以为"点了表盘没反应 = 坏了"。
- **单位标注"声明"还是"实测"**：宽高**都**是固定 dp 才写「（声明）」，否则写「（实测）」并把
  声明值一起摆出来（`声明 MATCH_PARENT × 40dp`）—— 用户看到 `675.6dp` 却不知道为什么这么宽时，
  答案就是后面那句。

### 验证方式

- **单测**：`tools\run-tests.ps1` → **TOTAL=944  FAILED=0**（基线 911）+ 构建守卫通过（**exit 0**）。
  944 里 **33 条**是本版的 `data/UiInspectorInfoTest.kt`；`UiScaleTest` 那 19 条**已随全局缩放一起删掉**
  （962 − 19 = 944，与预期一致）。
- **构建**：`:app:assembleDebug` 通过；APK 单 ABI `arm64-v8a`。
- **装机实测**（小米平板 5 `7e7d7bb4` / 2560×1600 横屏 / 应用区 2560×1564），
  **坐标一律先 `uiautomator dump` 再点**，动手前备份 `files/config/*.json` 到
  `stage/tablet-backup-20261010-222217/`：
  - **判据 1（开/关）**：点设置页 `swInspector` → 应用日志
    `[22:53:45.427][UI][I] 开启控件检视 | 浮窗=已挂上，触摸被接管`，
    设置页那行小字变成「已开启：点任意控件看它的类型 / ID / 样式；右上角 × 或本开关可关闭」。
  - **判据 2（有 id 的控件）** ⚠️ **观测时点的是「界面调参」按钮 —— 该按钮已随 `UiScale` 撤掉
    （见本节顶部说明），下面记的是当时面板**真实**打出来的内容**：
    面板逐行显示 `MaterialButton` / **`btnUiScale`**（**资源名，不是数字**）/
    `尺寸 675.6×40dp（实测；声明 MATCH_PARENT × 40dp）  边距 0/6.2/0/0` /
    `内边距 24/6.2/24/6.2` / `字号 12.9sp  色 #00D8FF` / `背景 RippleDrawable（无资源名）` /
    `可见 VISIBLE  可用 true` / `层级 … > FrameLayout > … > LinearLayout > MaterialButton`。
    （`40dp` 是 XML 声明值、`675.6dp` 是实测；`12.9sp` 对应 XML 的 `13sp` ——
    dp/sp 往返各差一次取整，**这是对的**。尾部完整 = 父链截断修好了。）
  - **判据 3（没有 id 的控件）**：点设置页那个没有 id 的 `TextView`（"全局（与画布无关）"，
    `resource-id=''`）→ 面板显示 **`（无 id）`** + `MaterialTextView` +
    `尺寸 116×17.8dp（实测；声明 WRAP_CONTENT × WRAP_CONTENT）  边距 0/0/0/0` /
    `内边距 0/0/0/0` / `字号 12.9sp  色 #9AA8BC` / `背景 （无）` / `可见 VISIBLE  可用 true` /
    `层级 … > FrameLayout > … > LinearLayout > MaterialTextView` —— **不崩、不空白**。
  - **判据 4（描边高亮）**：对上面那个控件的矩形 `[520,1079][781,1119]` 数**青色像素**
    （`B>140 && G>110 && R<130`，即 `#00D8FF` 描边）→ **3148 px**；
    同样大小、但离它很远的一条空带（`y=700..760`）→ **161 px**（那点残留是面板自己的边框）。
    **高亮确实画在被点中的控件上。**
  - **判据 5 前半（检视模式下横滑不翻页）**：检视开着时 `input swipe 2100 700 → 500 700`，
    dump 前后**都还是画布设置页**（`swInspector` 仍在）—— 触摸确实被消费了。
  - **导航栏放行 + 保持可见**（这条是 v1.20.14 实测**新发现并补上**的，规格里没有）：
    `22:58:50` 的 dump 里同时出现面板与 `仪表盘/连接/PID/规则/日志/知识库` 六个导航项；
    并且**在检视开着的情况下点「仪表盘」真的切到了画布页**（`dashPager` 在、设置页的文字全没了）——
    证明"打开检视之后就切不了页"这条死胡同已经堵上。
- ⚠️ **踩到"装的是旧包"（这一版最重要的方法论教训）**：中途面板一直不出现、
  设置页那行小字一直是**空的**，我一度以为是自己代码的 bug。查下来是
  **另一个智能体在 `23:00:02` 把它自己那份 APK 装了上去**（`pm path` 拉出来的
  `base.apk` = 7,355,408 字节 = 它 `22:47:38` 放进 `dist/` 的那个），
  而我最后一次 `assembleDebug` 是 `22:58:12`。**重新装回自己那份之后，
  面板、`（无 id）`、高亮、小字全部正常。**
  教训：**"面板不出现"先查装的到底是谁的包**（`dumpsys package | grep lastUpdateTime`
  + `pm path` 看体积），别急着改代码 —— 与 v1.20.11 那次"装的是旧包"是同一个坑。
- ⚠️ **另一个坑：MIUI 上 `uiautomator dump` 会静默失败并留下上一次的 `/sdcard/u.xml`**。
  本轮因此两次得出过**错误**结论（"点了控件面板没变"）。稳定做法：
  `rm -f /sdcard/u.xml` → `uiautomator dump` → `stat -c %s` 校验大小 → 才 `pull`。
  **凡是没有校验过大小的 dump 一律不作数。**
- ⚠️ **本趟装机验证被并发干扰**：同一台平板上**另一个智能体也在跑它自己的验证**
  （`22:49:48` / `22:51:35` / `22:51:50` / `22:52:55` 有不是我发的翻页与弹窗；
  `23:02` 起反复挂着它的**模态对话框**（「界面调参（实时生效）」—— 该功能**已撤**），我后续的点击**全落在那个对话框上**）。
  所以判据 5后半/6/7/8 **本轮没验成**，见下。

### 遗留（**如实列出，别当成已验**）

- ⚠️ **判据 5 后半（关掉后横滑恢复）没验成**：`×` 与设置页开关两条出口都写了、
  都走 `MainActivity.setInspectorEnabled`（唯一写者）；装机上确实观察到"关掉之后面板消失"
  （dump 里 `搜这个 id` 那行没了、设置页小字变回「已关闭。开启后 App 的触摸会被接管…」），
  但**"关掉之后 swipe 真的翻页"没拿到干净的实测记录**（那一次 swipe 落在了另一个智能体的对话框上）。
- ⚠️ **判据 6（画布尺寸不受影响）只拿到"检视器关着"的基线，没拿到"开着"的对照**：
  - 画布页（检视器**关**）实测：非背景像素 **3.12%** / 亮行 **171** / 平均亮度 **17.99**
    （`stage/z-02-canvas-off.png`，采样步长 2、阈值亮度 40）；
  - 想拍对照那一帧时，检视开关已被并发操作关掉 / 页面被它的对话框挡住，
    **"检视器开着 + 画布页"那一帧没拍成**。
  设计上成立（高亮层永远 `MATCH_PARENT`、只 `invalidate()`；浮层挂 `android.R.id.content`，
  `activity_main.xml`/`fragment_dash.xml` 一个字没动），但**这一条算"没验成"，不算"验过了"**。
  ⚠️ 统计脚本 `stage/px.ps1` 第一版有个**自己咬自己**的 bug：循环变量写成 `$y`/`$x`，
  而 **PowerShell 变量名大小写不敏感** → 它把 `$Y`/`$X` 两个**参数**覆盖掉了，
  于是 2560×1400 的区域只扫了一行（报 `samples=1280 / nonbg=0%`）。
  已修（循环变量改 `$py`/`$px`）并复算：`samples=896000 / nonbg=27940 (3.12%) /
  brightRows=171 / avgLum=17.99`，与上面那条**逐位一致**。截图都在 `stage/`，可复算。
- ⚠️ **判据 7（拖动 / 不盖灵动岛与警示条）没验成**：默认位置是左下角（灵动岛在顶部居中、
  警示条在顶部），逻辑上错开；拖动只到代码层面。
- ⚠️ **判据 8（长按复制）没验成**：`ClipboardManager.setPrimaryClip` 那条链没有真机证据
  （Android 10+ 也没法用 adb 读剪贴板）。
- ✅ **（已解决）`sp` 的取值曾被全局缩放污染**：面板显示的是**当前** `TextView.getTextSize()` 换算出的 sp，
  而 `UiScaleApplier.scaleText` 把 `textSize`（**px**）当 sp 写回（`setTextSize` 收的是 sp）——
  于是**「1.3× → 恢复默认」之后字号停在 `density` 倍**（平板 2.25×），实测设置页 11sp 的说明文字
  显示成 **25sp**。**这不是检视器的 bug**（`px / scaledDensity` 是对的）。
  这套全局缩放**已按用户要求整套撤掉**，这一条随之消失（`grep -r UiScale app/` = 0 命中）。
- ⚠️ **对话框里的控件命中不到**：检视器挂在 `MainActivity` 的 `android.R.id.content` 上，
  而 `AlertDialog` 是**另一个 window**，它的控件不在那棵子树里 —— 点对话框时命中的是
  content 里被盖住的那个控件（或空白）。这是"浮层挂 content"的固有边界，**规格没写、本版也没处理**
  （要处理得遍历 `WindowManagerGlobal` 的全部 root，风险大得多）。
- ⚠️ **双指手势 / 长按这些"adb 发不出来"的路径**（本轮只用到单指 tap/swipe）：
  拖动浮窗与长按复制都属于这一类，需手指实测。

---

## v1.20.13 · 2026-10-10 · **灵动岛样式可自定义**（位置/尺寸/配色/停留/圆角）+ **燃油两条 PID 合并** + 补真机（平板横屏）验证

> 用户两条：① 「我希望可以自定义样式」（指灵动岛通知）；② 「燃油可以合并」。
> ①做成**有界设计**（五组有限选项），**默认值 = v1.20.12 的样子**（升级后观感逐像素不变）。
> ②**没有删任何一条 id** —— 只在列表里不再重复显示（理由见下）。
> 另外把 v1.20.12 只在**模拟器竖屏**验过的三件事，在**目标平板 2560×1600 横屏**上补验了一遍。

### 新增

- **灵动岛样式可自定义**（用户点名要的）：新增 `data/IslandStyle.kt`（纯函数，17 条单测）
  + `ui/view/IslandCapsuleView.kt`（胶囊本体，样式 → View 的**唯一**映射）。
  五组选项，全部有界：

  | 组 | 取值 | 默认（= v1.20.12 的样子） |
  |---|---|---|
  | 位置 | 顶部居中 / 顶部靠左 / 顶部靠右 | 顶部居中 |
  | 尺寸 | 小 / 中 / 大（字号 12/13/15sp + 内边距） | 中（13sp / 14dp / 7dp） |
  | 圆角 | 小 / 中 / 大（6 / 12 / 18dp） | 大（18dp，矮胶囊上被夹成全圆角） |
  | 停留时长 | 2 / 4 / 6 秒 | 4 秒 |
  | 配色 | 跟随主题 / 自定义（8 色背景板 + 4 色文字板 + 手打 `#RRGGBB`） | 跟随主题（`#F01A1F27` + 白字 + 琥珀 `+N`） |

  **为什么是"有界"而不是自由样式编辑器**：它悬在画布正上方，任意坐标意味着用户可以把它
  拖到正中间 —— 那正是 v1.20.12 花一整版修掉的病；任意字号能小到看不见、大到占半屏；
  任意透明度会让它淡到读不出来，而用户会以为"提示坏了"。所以只给五组**有限**选项，
  **位置只有水平三个档、没有纵向自由度**（纵向永远由警示条让位决定）。
  入口在仪表盘设置页「灵动岛」按钮（与「手势」「画布名浮标」同一写法：按钮写功能名，
  当前取值写在下面一行小字里）；对话框里有**实时预览**，用的是**同一个** `IslandCapsuleView`
  + **同一个** `IslandStyle.spec`（红线 4.5：样式 → View 的映射只能一处，
  否则"预览里看到的和真弹出来的不一样"）。

  **三条硬约束一条都没放松**（v1.20.12 验过的）：
  ① **不盖住画布** —— 仍是挂 `android.R.id.content` 的 `WRAP_CONTENT` 浮层，
  **没有任何具体宽高**（`IslandNotice.layoutParams()` 里不许出现尺寸）；
  ② **不抢触摸** —— `IslandCapsuleView` 构造里 `isClickable=false` / `isFocusable=false`，
  **子 TextView 也一样**；
  ③ **与 `MonitorWarnBar` 错开** —— 位置档位只改**水平** `Gravity`
  （`START` / `CENTER_HORIZONTAL` / `END`），纵向**永远**是
  `topOffsetPx + TOP_MARGIN_DP`，所以改成靠左/靠右时**依然**在警示条下面那一行。

  **落盘**：七个键走 `settingsToJson` / `applySettingsJson`（`islandPos` / `islandSize` /
  `islandCorner` / `islandHold` / `islandColorMode` / `islandBg` / `islandFg`），
  **旧配置没有这七个键 → 逐个过 `IslandStyle` 的归一化函数兜默认值**，
  而默认值就是 v1.20.12 写死的那些数（有单测逐个断言：13sp / 14dp / 7dp / 18dp /
  `#F01A1F27` / 白 / 琥珀）。手改坏的 `settings.json`（档位越界、`islandHold=999999`、
  颜色全透明）在**读取时**就被夹回默认值，且**写回去的也是归一化后的值**
  （坏值不会被"洗白"成正常配置传下去）。

  **实现上的两处克制**：`IslandNotice` 每次 `show()` 从 `Store.settings.islandStyle()`
  **现读**样式（设置页改完，下一条提示立刻是新样式，不需要任何接线），但只有
  `Spec` 与上次**不同**时才真的去设 View 属性 —— 转向灯那种每 450ms 触发一次的规则
  不会每次都动一遍布局；`IslandStateMachine.holdMs` 改成 `var`（停留时长进了设置，
  而**重建**状态机会把"正在显示的那条"一起丢掉，表现是"改完时长后提示闪一下"）。

- **`data/PidMerge.kt`：燃油两条同义 PID 在列表里只出现一条**（用户拍板「燃油可以合并」）。

  **先读代码确认了关系**（不是凭名字猜）：

  | id | 名字 | 来源 | 谁在用它 |
  |---|---|---|---|
  | `std_5E` | 燃油消耗率 (L/h) | **输入**：Mode 01 PID `5E` | `VehicleBus.Derived` 的 `fuelRate` |
  | `calc_lh` | 燃油流量 (L/h) | **派生输出**：`Derived.computeAll` 算出来 | `calc_l100` / `calc_avg_l100` / `calc_range` |

  而 `Derived.computeAll` 的优先级是写死的：`std_5E` 有值且 >0 → 直接用它；
  否则由空气流量 MAF 推算；两者都写进 `calc_lh`。**所以 `calc_lh` 是"超集通道"，
  两者数值上不等价**（车不支持 `01 5E` 时 `std_5E` 根本没值、`calc_lh` 有值）——
  **"删掉其中一条"是错的**，那正是任务里说的"合并不安全"。

  **做法：保留两个 id，只在列表里不重复显示**（`PidMerge.filterForList`）。
  留下的是 `calc_lh`（任何车上都有值），收起 `std_5E`。三条不许破的约定：
  ① **`Store.allPids()` 一行没动** —— 轮询 / 模拟器 / 派生通道读的都是它，
  过滤**只发生在拿去做列表的那一步**（PID 管理页 / 仪表编辑器 / 规则编辑器）；
  ② **编辑器里"当前已经绑定的 id"必须保留**（`filterForList(keep=…)`）——
  这是个**真陷阱**：`addConditionRow` / `showEditDialog` 都是
  `indexOfFirst` 找不到就不设 → Spinner 停在 **0 号（发动机转速）** → 点一下「确定」
  就把老仪表**静默改成转速表**（有单测钉着这条路）；
  ③ **列表里那一行会说明另一条去哪了**（`已合并「燃油消耗率 01 5E」：…`），
  否则用户只会看到"少了一条"。说明文案是**纯文本**（这一页不做 Markdown 渲染）。

### 验证方式

- `tools/run-tests.ps1` → **`TOTAL=911 FAILED=0`**（基线 881 → **911**，+30：
  `IslandStyleTest` 17 / `PidMergeTest` 13）+ 构建守卫通过。
- `:app:assembleDebug` BUILD SUCCESSFUL；APK 进 `dist/iCarOBD-debug-v1.20.13-android.apk`
  （**7.00 MB** ≤ 8 MB、单 ABI `arm64-v8a`、`versionCode=82 versionName=1.20.13`）。
- **装机实测（目标平板小米平板 5 / `7e7d7bb4` / 2560×1600 / 横屏 ROTATION_90 /
  Android 13）** —— 这一趟平板在线，把 v1.20.12 只在模拟器竖屏验过的三件事补上了。
  **动手前先备份 `files/config/*.json` 到 `stage/tablet-backup-20261010-210210/`，
  5 个文件的 md5 与设备逐一相同**（升级安装后**再核一遍**，五个 md5 一个都没变）。
  坐标一律先 `uiautomator dump` 再点，**没有复用任何记忆中的坐标**。

  - **画布 P0（真机 + 横屏）**：规则「高水温告警」用编辑器里的
    「▶ 模拟测试（回仪表盘看效果）」触发（日志 `21:10:40.688 规则触发 | name=高水温告警
    actions=4` + `提示 | 冷却液温度过高`）。**16 帧连拍**（`stage/v12013/sim_*.png`）：
    画布主体（y 210~1500）非背景像素 **12.93%~15.53%**、亮行 **654~710 行**、
    平均亮度 **20.77~28.36** —— **一帧都没有掉到 0**。
    同一批帧里灵动岛胶囊**出现（s02~s04）→ 消失（s05~s12）→ 再来（s13~s15）**，
    说明"提示在弹"与"画布还在"是同时成立的（这正是 v1.20.12 那个 P0 的反面：
    那时 `childCount=9` 而像素是 0×0）。
    另外 `uiautomator dump` 里 `android.view.View` 节点 **= 9**（1 参考线 + **8 块表**）、
    日志 `仪表盘已落盘 | 表=8 容器=2560x1600` —— 与 v1.20.12 修好后一致。
  - **灵动岛（真机 + 横屏）**：胶囊**出现/收起**清楚（默认样式 4 秒，
    改 6 秒后连拍窗口内 `s01~s05` 在、`s06~s13` 不在、`s14~s15` 又来）；
    胶囊**里有字**（框内亮像素 **1762**，同一框在没弹的帧上只有 **127** —— 那是画布本身的像素）；
    **画布全程可见**（上面那组统计）；**从胶囊正上方起手横滑照常翻页**
    （`input swipe 1279 46 → 600 46`：画布名从「你好」变成「画布 2」，
    日志 `已切换画布 | name=画布 2`）；**横屏位置正确**
    （默认居中时胶囊中心 x **= 1279**，屏幕宽 2560 的**正中心**）。
  - **本轮样式（真机）**：在设置页对话框里改 **位置 → 尺寸 → 圆角 → 停留 → 配色**
    （背景选「琥珀」色板、文字选「黑」），点「确定」后：
    `settings.json` 里七个键 = `islandPos=1 islandSize=2 islandCorner=0 islandHold=6000
    islandColorMode=1 islandBg=-20448(#FFB020) islandFg=-16777216(#000000)`；
    设置页小字变成 `当前：顶部靠左 · 大 · 圆角小 · 6 秒 · 自定义`；
    **重启后七个键与小字都还在**。
    **三个位置逐个上真机量过**（用琥珀底色在截图里定位胶囊外接框）：

    | 位置档 | 实测胶囊 bounds | 说明 |
    |---|---|---|
    | 顶部靠左 | `[24,24][373,108]`（w=350 h=85） | 左边距 ≈10dp |
    | 顶部居中 | `[1105,24][1454,108]`（w=350 h=85） | 中心 x=1279 = 屏幕正中心 |
    | 顶部靠右 | `[2186,24][2535,108]`（w=350 h=85） | 右边距 ≈10dp（2535 = 2560−25） |

    三档下**画布统计都稳**（非背景 59.51%~59.54%、亮行 1212 行，一帧没掉），
    三档下**从胶囊正上方横滑都照常翻页**（居中/靠右各实测一次）。
    「大」档 350×85 与「中」档 294×46 的尺寸差也实测到了（尺寸档真的生效）。
  - **PID 去重（真机）**：平板 `pids.json` 里那条真重复（`TestMonitor09A` /
    `bitsAt(18,1,0,0)`）在 PID 页显示 `⚠ 重复：与「左转向灯」同报文 09A 同一位段`，
    按钮 `清理 1 条重复` → 确认框逐条列出理由 → 点「删除这 1 条」后：
    按钮消失、自定义组消失、`pids.json` = `[]`、`enabled.json` = `{}`。
    **清理后仪表仍 8 块表**（`android.view.View` 节点 = 9）、
    **规则仍正常触发**（清理后继续模拟，日志又出现多次 `规则触发 | name=高水温告警`）。
    全程应用日志 `[E]` **0 条**、无崩溃无 ANR。

### 遗留

- ⚠️ **"灵动岛与监听警示条同屏错开"仍然没验**（与 v1.20.12 同一条）：
  警示条只在 `FrameMonitor.running` 时出现，而它要求**已连接适配器**
  （平板上有配对的 `IOS-Vlink`，但 `GATT 断开 status=255`）→ **造不出两者同屏**。
  判据（上车补）：开启常驻监听后触发一条 toast 规则，应当看到
  **上一条红底警示条 + 下面一行灵动岛胶囊**，两者不重叠。
  ⚠️ 本轮**改了位置档位**，所以这条要多验两个：**靠左 / 靠右时也要不错开**
  （代码上纵向偏移与位置无关 —— `layoutParams()` 里纵向永远是
  `topOffsetPx + TOP_MARGIN_DP`，但**没有实测**）。
- ⚠️ **圆角三档只验到"设置生效 + 摘要正确"，没逐档量像素**：
  `GradientDrawable` 会把半径夹到高度的一半，所以默认尺寸上 12dp 与 18dp
  渲染出来**可能是同一个全圆角**（6dp 肉眼可辨）。三档给的是**真的不同**的半径，
  但"中"和"大"在小胶囊上差别很小 —— 没有逐档截图比对。
- ⚠️ **双指手势本身 adb 验不了**（`adb input` 发不出多点触控）→ 本轮用
  **双击左缘兜底**呼出导航栏（日志 `双击：呼出导航`），双指手势仍需手指实测。
- **`std_5E` 被收起是"显示层"行为**：想在新建仪表/规则时**主动选**它做不到
  （列表里不再单列）—— 这是有意的（`calc_lh` 是超集通道），但如果用户
  确实要按"车的原始 `01 5E` 读数"建表，得先改 `PidMerge.FOLDED_IDS`。
  老配置里已经绑着 `std_5E` 的仪表/规则**不受影响**（编辑器会把它保留在列表里，
  有单测钉着）。
- **`TestMonitor09A` 已从平板上删除**（v1.20.12 的遗留项本轮清掉了）。
  平板现在 `pids.json = []`、`enabled.json = {}`，其余配置与动手前**逐字节相同**。

---

## v1.20.12 · 2026-10-09 · 🔴 **P0：规则 toast 一弹、整个画布消失**（根因：在 layout 期间 `addView`）+ PID 去重 + 灵动岛

> 用户三条：① 「当规则 toast 弹出提示的时候、**整个画布都会不见**」；
> ② 「检查 PID 页面、将重复多余的清除掉」；③ 「增加个悬浮窗通知、类似于**灵动岛**那种效果、
> 用于规则的一些提示或啥的」。
> ①是这一版的重点 —— 它**不是**"看起来修好了"，根因用 logcat 钉死了。

### 修复

- **🔴 P0：规则 toast 弹出时整个画布消失**（根因：`DashRenderer` 在 **layout 期间**重建视图）

  **症状**：规则动作 `toast` 一触发，8 块表全部看不见；而且**不会自愈** ——
  告警条 4 秒后收起也回不来。用户原话「整个画布都会不见」。
  实测（模拟器 1080×2400，规则「高水温告警」模拟触发）：
  画布主体平均亮度 **27.64 → 14.52**、亮像素 **6.44% → 2.52%**；
  截图里画布区域 **99.96% 是一片纯背景色 `#080A0E`**。

  **根因（不是推测，是 logcat 抓到的）**：
  `DashRenderer` 唯一的重排入口 `relayout()` 挂在
  `container.addOnLayoutChangeListener` 上 —— 而它是在 **`View.layout()` 内部**被回调的。
  在 layout 期间 `addView` 出来的子 View，父容器**这一轮的 `onMeasure` 已经跑完**，
  于是它**永远不会被 measure**；`FrameLayout.onLayout` 取
  `getMeasuredWidth()/getMeasuredHeight()`（都是 0）把它摆成 **0×0 @ (0,0)**。

  ```
  D ICARDBG: 布局后 container=1080x2164 子数=9 ::
      [0]1080x2164@0,0   [1]0x0@0,0   [2]0x0@0,0 … [8]0x0@0,0   ← 8 块表全是 0×0
  ```

  为什么这么难查：**所有常规判据都显示"一切正常"** ——
  `container.childCount = 9`（1 参考线 + 8 块表）、应用日志照打
  `仪表盘已落盘 | 表=8`、`uiautomator dump` 里那一层**整个消失**
  （`isVisibleToUser=false` 被跳过）—— **只有 `screencap` 的像素能看出来**。

  **触发链**（与"Toast 本身"无关）：
  ```
  规则动作 toast → ObdController.handleAction → emitAlert
    → DashFragment.onAlert → showAlert：alertBanner VISIBLE
    → fragment_dash.xml 是 LinearLayout、pager 是 layout_weight=1 → 2272 → 2164
    → gaugeGrid 尺寸变化 → relayout()（在 layout 里）→ 8 块表 0×0
  4 秒后告警条收起 → 2164 → 2272 → **又**在 layout 里重建一次 → 仍然 0×0
  ```
  **定位突破口**：滑到设置页再滑回来画布就回来了 —— 那条路是"在 layout 之外"的重建。

  **修法**：`relayout()` **post 到下一轮消息**再重建（新增 `postRebuild()`，
  同一帧里连续几次尺寸变化只排一次）。这样 `addView` 发生在这一轮 traversal 之外，
  正常触发下一轮 measure+layout+draw，**一帧内就是正确尺寸，不会闪**。
  另外把"什么时候该重排 / 几块表是 0 尺寸 / 要不要补一次"抽成纯逻辑
  `ui/dash/CanvasRebuildPolicy.kt`（17 条单测），并在每次重建后挂一个
  **布局结束后的自检**（`OnGlobalLayoutListener`）：量到 0 尺寸就记一条 W 并补重建一次
  —— 让这类"树上正常、屏幕上没有"的失败**下一次能一条日志定性**，而不是再靠量像素。

- **规则提示不再让画布重新量一次**：`DashFragment.onAlert` 不再显示页面内告警条
  （那条 `LinearLayout` 子 View 就是上面那个触发条件）。规则提示改由 `MainActivity`
  的灵动岛出。告警条**留着**，只再负责常驻的「⚠ 模拟数据（非真车）」提醒。

### 新增

- **灵动岛式悬浮提示**（用户点名要的）：`ui/view/IslandNotice.kt` + `ui/view/IslandStateMachine.kt`。
  - **位置/形态**：顶部居中，小胶囊（实测 bounds `[365,154][714,240]`，宽 349px、高 86px
    = 画布高度的 **3.8%**）；**平时完全隐藏**，规则触发时展开，**4 秒后淡出收起**。
    「平时收起」刻意做成**完全隐藏**而不是"留一个缩小的小点"——常驻的小点会永远压在画布顶部，
    正是任务 1 那条教训的反面。
  - **绝对不盖住画布**：浮在 `android.R.id.content` 上、`WRAP_CONTENT × WRAP_CONTENT`，
    **不改任何布局**（与 `MonitorWarnBar` 同一个宿主、同一条理由）。
  - **不抢触摸**：`isClickable=false` / `isFocusable=false`，**连展开时也不可点**
    （它悬在画布正上方，能点就会吃掉横滑/双击呼出导航的一部分手势）。
    实测：**从胶囊正上方起手横滑，页面照常翻过去**。
  - **与 `MonitorWarnBar` 错开**：警示条是 `MATCH_PARENT` 常驻在顶部，
    灵动岛用 `MonitorWarnBar.heightPx()` 往下让一行，两者不叠。
  - **复用而不是新增动作**：没有新造 `island` 动作类型 —— 它就是规则动作 `toast`
    那条提示链（`emitAlert`）的**显示层**。原来"规则提示"有两处（系统 Toast + 页面内告警条），
    现在统一到一处（系统 Toast + 灵动岛），**没有第二套"提示"概念**。
  - **`IslandStateMachine` 是纯逻辑**（12 条单测），语义三条：
    空闲来一条→展开；**同一条文本**再次到来→**只续期**（转向灯那种每 450ms 触发一次的规则
    不会变成一直闪、`+N` 也不会涨到几百）；**不同文本**→换文案并 `+N`。
    刻意**不做严格 FIFO**：严格排队会让第 3 条要等 8 秒才看到，行车场景里是有害的。

- **`data/PidDedup.kt`：PID 重复判定**（用户要求「检查 PID 页面、将重复多余的清除掉」）。
  把"什么叫重复"从感觉变成判据（28 条单测）：
  - **请求型**（`mode != MON`）：`mode + pid + 公式` 相同 = 同一个量；
  - **监听型**：`报文 ID + 位段指纹` 相同 = 同一个量；
  - ⚠️ **监听型与请求型不互判**（一个被动听广播、一个主动问 ECU，取到值的时机完全不同）；
  - ⚠️ **内置之间不判重复**（内置表是刻意设计的，且永远不给用户删）。
  - **位段指纹**把 `bit(C,2)` / `bits(A,6,4)` / `bitsAt(18,1,0,0)` / `signed(A)`
    都归一成「帧内起始位:长度:字节序:符号 + 系数/偏移」——
    设备上那条真重复（`TestMonitor09A` 的 `bitsAt(18,1,0,0)` vs 内置「左转向灯」的 `bit(C,2)`）
    文字完全不同，**指纹相同**，正是靠它判出来的。
    认不出的公式返回 `null` → **一律判"不重复"**（宁可漏报，不能误删真数据）。

- **PID 页「清理 N 条重复」**（`fragment_pid.xml` 的 `btnDedup` + `PidFragment`）：
  **默认 GONE**，只有真有重复时才出现并显示条数；点开是一个**逐条列出理由**的确认框。
  行内也会标 `⚠ 重复：与「左转向灯」同报文 09A 同一位段`。
  安全闸三样（`Store.cleanupDuplicatePids`）：① **只删自定义**，内置一律不碰；
  ② **被仪表/规则引用的不删**（删了仪表会变空、规则永远不成立）；
  ③ **先把清单给用户确认**，不静默改数据。

### 调整

- **`Store.importTemplatesAsCustom()` 不再复制实车确认过的监听型**。
  它原来无条件复制 `MANUFACTURER_TEMPLATES` 全表，而那张表里混着
  `mon_turn_left` / `mon_turn_right`（2026-10-06 实车确认的真条目）——
  复制的结果是 PID 页凭空多出**两条一模一样信号**（同报文同一位，只有 id 和分组不同，
  副本还 `enabled=false`）。**这是"重复"的代码级发生器**，判据用 `PidDedup.isMonitor`。
- **`Store.deletePid` 顺带清 `enabledOverride`**：原来 `enabled.json` 会永久留着
  指向已删条目的 id（每删一条攒一个），而且"删除后重建同 id"会被这条陈旧覆盖静默改掉启用状态。
- `ui/view/MonitorWarnBar.kt` 新增 `heightPx()`：给灵动岛让位用。
- `DashFragment` 删掉 `hideBanner` / `main` 两个只为旧告警条存在的字段。

### 验证方式

- `tools/run-tests.ps1` → **`TOTAL=881 FAILED=0`**（基线 824 → **881**，+57：
  `PidDedupTest` 28 / `CanvasRebuildPolicyTest` 17 / `IslandStateMachineTest` 12）。
  ⚠️ **构建守卫这一项没全过，但不是本轮的改动**：唯一的 ❌ 是
  `docs\知识库审校.md` 里有一处单破折号 —— 那是**另一个智能体正在写的未跟踪文件**
  （`git status` 里是 `??`，本轮写入范围不含它）。
  按守卫**完全相同的口径**（只扫 `tools` + `docs`、排除 `check-build-guard.ps1`）
  复算过：88 个文件里只有它 1 处，**我的改动没有引入任何新的守卫问题**。
- `:app:assembleDebug` BUILD SUCCESSFUL；APK 进 `dist/iCarOBD-debug-v1.20.12-android.apk`
  （**6.98 MB** ≤ 8 MB、单 ABI `arm64-v8a`、`versionCode=81 versionName=1.20.12`）。
- **装机实测**（本机 `qz33` x86_64 模拟器 1080×2400 / Android 13；
  ⚠️ **目标平板 `7e7d7bb4` 这一趟没插上**（`adb devices` 空、PnP 里 Xiaomi ADB 接口
  `Unknown`），所以下面全部证据来自模拟器 —— 为此**临时**给 `abiFilters` 加了 `x86_64`
  出了一版可装的包，**交付前已删掉**（`git diff app/build.gradle.kts` 只剩版本号两行）。
  坐标一律先 `uiautomator dump` 再点（脚本 `stage/bug1/drive.py`）：
  - **任务 1 复现 → 修好**：修复前 12 帧连拍，画布主体亮度**一路 11.10**（纯背景）、
    `gaugeGrid` 在 dump 里只剩 1 个子 View；修复后 16 帧连拍，
    **告警条在（band1=40）与不在（band1=9）时画布都保持 19~29 的条纹**、
    画布主体亮度 **21~24 全程不掉**，`gaugeGrid` 恒为 17 个节点。
    应用日志里自检那条 W（"画布有 0 尺寸的表"）**一次都没出现**。
  - **任务 3 灵动岛**：10 帧连拍里 s02/s03/s08/s09 出现
    `冷却液温度过高`（胶囊 bounds `[365,154][714,240]`，**顶部居中**），
    s01/s04~s07/s10 消失 —— 展开→4 秒收起→按 15 秒冷却再来一次；
    **每一帧 `gaugeGrid` 都是 17 个节点、画布亮度 20.47~20.67**（画布全程可见）。
    **不挡横滑**：从胶囊正上方 `(539,197)` 起手左滑 → 页面翻到设置页、再滑回来 ✓。
    `logcat` 无 `FATAL` / `ANR in com.icar.obd`。
  - **任务 2 PID 去重**：把平板上的那条重复**原样**灌进模拟器
    （`TestMonitor09A` / `0cb7ad46-…` / `09A` / `bitsAt(18,1,0,0)`）→
    PID 页出现 `清理 1 条重复` + 行内
    `⚠ 重复：与「左转向灯」同报文 09A 同一位段 —— 可用上方「清理重复」一键删掉`；
    确认框逐条列出理由。**清理前 41 条**（标准 25 + 派生 9 + 厂家模板 4 + 监听型 2 + 自定义 1）
    → **清理后 40 条**（自定义组整个消失）、`pids.json` 变 `[]`、`enabled.json` 变 `{}`、
    按钮自动隐藏、`TestMonitor09A` 从列表消失。
    **仪表/规则绑定完整性**：清理后仪表盘仍是 8 块表、规则「高水温告警」仍正常触发（见任务 1/3 的连拍）。

### 遗留

- ⚠️ **目标平板（小米平板 5 / `7e7d7bb4`）这一趟没插上**，所以三条任务的装机证据都来自
  **x86_64 模拟器**（Android 13 / 1080×2400 / 竖屏）。**横屏 2560×1600 下的表现没验**：
  灵动岛是 `Gravity.TOP|CENTER_HORIZONTAL` + `WRAP_CONTENT`，横屏只会更不占地方，
  但**没有实测**。上车/上平板时按 §「判据」补一遍。
- ⚠️ **灵动岛与 `MonitorWarnBar` 的"错开"只验到逻辑，没验到画面**：
  警示条只在 `FrameMonitor.running` 时出现，而它要求**已连接适配器**
  （`FrameMonitor.start()` 会拒绝），模拟器上没有蓝牙设备 → **造不出两者同屏**。
  判据（上车补）：开启常驻监听后触发一条 toast 规则，
  应当看到**上一条红底警示条 + 下面一行灵动岛胶囊**，两者不重叠。
- ⚠️ **`docs/17-知识库审校.md` 导致的构建守卫 ❌ 不在本轮范围内**（另一个智能体的未跟踪文件）。
  `run-tests.ps1` 因此**整体 exit 非 0** —— 单测那半边是干净的（881/0），
  守卫那半边只差那一处破折号。谁收尾那份文档，谁顺手把那个单破折号改成 `——` 即可。
- **PID 去重的两个"刻意不判"**（写在这里，避免下一轮又当成漏报去修）：
  ① `std_5E 燃油消耗率(L/h)` 与 `calc_lh 燃油流量(L/h)` **同单位、同一个量**，
  但前者是**输入**（`VehicleBus.Derived` 优先取它）、后者是**派生输出**（平均油耗/续航都用它）
  —— 功能上两条都要，**没有删**；
  ② 4 条 `tpl_*` 厂家模板（`pid=2400/2500/1234/2300` 是**占位号**、`enabled=false`）
  是"上车逆向的起点"，删了就少了那条工作流，**没有删**。
  如果用户认为这两类也该清，下一轮按「清单 + 判据」再定。
- **`TestMonitor09A` 那条真重复仍然留在平板上**（这一趟没插上，删不了）。
  已经核实它**没有被任何仪表/规则引用**（`dash.json` / `rules.json` / `settings.json` 里
  都没有 `0cb7ad46-d120-4b1d-8952-9462a9f71414`，只有 `pids.json` 和 `enabled.json` 有），
  所以**在平板上升级到 v1.20.12 后，PID 页会直接出现「清理 1 条重复」，点一下即可**。

---

## v1.20.11 · 2026-10-09 · 知识库补到 v1.20.10 + 新增**「软件使用手册」12 节**（并清掉正文里的 Markdown 星号）

> 用户两条要求：① **知识库要更新** —— 它停在 v1.20.2 的内容（13 节 / 8 标签），
> 而 v1.20.3~v1.20.10 加了多画布、手势、设计包、监听型 PID 录入、三运行时语义、
> 信号表、分段轮换一堆东西，一条都没进去；② **增加一个类目「软件使用手册」** ——
> 给每个功能写使用教程，**流程清晰、简单易懂**。
>
> 写法上刻意把这一页分成两段：**知识**回答"为什么是这样"，
> **手册**回答"我下一步点哪里"（前置 / 步骤 / 判据 / 没成功怎么办）。
> 手册的排序按**"用户第一次用会卡在哪"**，所以第 1 节是"连不上适配器"，
> 而不是"架构分层"。

### 新增

- **知识库补 6 节**（v1.20.3~v1.20.10 的新功能，逐条回代码/CHANGELOG 核实过）：
  - `12. 多画布：一页一套，各管各的` —— `[画布0][画布1]…[设置]`、每套各自的
    主题/背景/设计文件/页号、操作菜单 6 项、**上限 8 套**、**至少留 1 套**、
    内置布局"表还在但没显示"这条容易误解的事。
  - `13. 双指手势与双击兜底` —— 4 方向 × **7 个动作**、**出厂默认值逐个列出**、
    48dp 阈值与"先比主轴再比阈值"、切画布只在仪表盘页生效、切 tab 在 6 页之间循环、
    双击兜底不可改不可关（以及"落点在导航栏上不算"这条 v1.20.6 的修）。
  - `14. 「控件 / 主题 / 设计包」到底是什么关系` —— **回答用户那个疑问**（见下）。
  - `15. 运行时三语义` —— `invalidRaw` / `ttlMs` / `minDlc` 三条各自"为什么必须有"，
    以及"为什么变成 `ok=false` 就够了（下游零改动）"。
  - `16. 信号表（25 列）导出 / 导入` —— **25 个列名逐个列出**、按列名匹配、
    硬错误/软警告的区别、可信度=候选**不启用**、重复导入是覆盖。
  - `17. 分段轮换扫描` —— 8 段 × 10 秒、**掩码与过滤必须成对**（`ATCF000` 单独发是全总线）、
    三条读「整车 ID 清单」的判据、29 位 ID 扫不到这条已知边界。
  - 收尾节从「一句话记住三件事」扩成**四件事**（加了"布局跟设计文件走、配色跟主题走"），
    并从索引 12 **挪到 18**（中间插了 6 节）。
- **新增「软件使用手册」12 节**（每节固定四栏：`【前置】/【步骤】/【判据】/【没成功怎么办】`）：
  `手册 1 连接适配器` · `2 仪表盘` · `3 手势` · `4 PID 页（含自己造监听型 PID）` ·
  `5 PID 探测（扫描器）` · `6 CAN 探测` · `7 找信号的标准套路` · `8 分段轮换扫描` ·
  `9 信号表导出/导入` · `10 设计包` · `11 规则与音效` · `12 日志与导出`。
  - 每节的**判据都落到"看哪一行日志 / 界面出现什么"**上（照抄
    [`16-上车监控清单.md`](16-上车监控清单.md) §11 与各版本 CHANGELOG 的实测文案，
    例如 `轮换中：第 3/8 段 …`、`信号跳过 | 原因=DLC不足 需要=4 实际=2`、
    `已加为监听型 PID：…`、`至少要留一套画布`、`请先勾选安全确认`）。
  - **`【没成功怎么办】` 是每节最值钱的一栏**（2~4 条最常见的排障），
    有单测钉着"手册每一节都必须有这四栏"。
  - 步骤里写的都是**界面上真实存在的文案**（`＋ 新增画布`、`改用我存着的 N 块表`、
    `分段轮换`、`导出信号表模板`、`开启常驻监听（转向灯）`…）——
    不是"大概有个按钮"。
- **标签从 8 个加到 11 个**（+「全部」= **12 个 chip**）：新增 `使用手册`（整类）+
  `连接` / `仪表盘` / `规则`（手册按功能细分）；**手册里的探测几节复用已有的 `探测` 标签**。
  刻意停在 11 个：标签条是一屏内要一眼扫完的东西，再加就要占两三行，
  而"筛选手册"这个动作比"看清标签"更常用。**上限写进了单测**。
- **`app/src/test/java/com/icar/obd/ui/KnowledgeFragmentTest.kt`（新文件，12 条）** ——
  这一页是"文档性质的代码"，**没有编译期约束**，有三件事会静默坏掉：
  - **`TAG_MAP` 按节索引挂标签**：中间插一节忘了改映射 → 点「CAN」筛出别的东西，
    而页面看起来完全正常。用例钉住"索引正好是 `0..size-1`"（不漏、不多、不跳号）。
  - **正文里写 Markdown 会原样显示**（见下面的"修复"）。用例逐节扫 `**` 与反引号
    （**只扫成对的 `**`** —— 公式里的单个 `*` 是正常的，如 `A * 0.1 - 48`）。
  - **标签词表与映射会分叉**：词表里多写一个 / 映射里少挂一个，表现都是
    "某个 chip 点下去永远是 0 节"。两个方向各一条用例（没有拼错的标签、没有死标签）。
  另加：手册正好 12 节且编号连续、**每节四栏都在**、知识节不许混进 `使用手册`、
  标题不重复、正文不许有 Tab（Tab 不参与 `trimIndent()` 的公共缩进计算，
  表现是"整段左边多出一截空白"）。

### 修复

- **🔴 知识库正文里的 Markdown 标记全部清掉**（`**粗体**` 与反引号，共 **144 个 `**`**）。
  这一页是 `TextView.text = 字符串` + `LinkMovementMethod`（**只处理链接**），
  **不做 Markdown 渲染** —— 所以从 v1.20.2 起，用户在平板上看到的一直是
  "`**受轮询节奏限制**`"这种带星号的原文。
  - 这一版**顺手把两段都对齐了**：新写的正文按约定用纯文本 + 编号 + `·`，
    同时把原有 13 节的 `**`/反引号一起清掉（不然半页带星号半页不带）。
  - **代码注释（KDoc）里的 Markdown 一个字没动** —— IDE 会渲染，不受影响；
    约定本来就只管"正文"。
  - 新加的 `KnowledgeFragmentTest` 有一条用例**专门守这个**，防止下一个人再写回去。

### 核实（用户那个疑问，结论写进了知识第 14 节）

> 「电脑版主题制作里做的新控件，导出**主题**的话，手机端能直接用吗？」

**不能** —— 控件不属于主题。逐条读代码核实的结果（三条判断里**有一条要修正**）：

| # | 待核实的说法 | 结论 | 证据 |
|---|---|---|---|
| 1 | 控件属于设计文件、不属于主题 | ✅ **对** | 工具侧 `window.GAUGE_THEMES` + `themeColors` **只有配色**（12 色 + 辉光 + 卡片描边/不透明度）；控件是设计文件的顶层 `controls` 段（`[主题设计大纲.md](12-主题设计大纲.md)` §2.8 原话："`controls` 段里的模板（**跟着设计文件走**）"）。而且工具里**根本没有"导出主题"这个按钮** —— 能导出的只有「保存 v2 / 导出 v1 / 导出 PNG / 导出设计包」 |
| 2 | 拖到画布上会**深拷贝**进节点树，手机端不需要控件库 | ✅ **对** | `presets.js` 的 `instantiateControl` = `clone(template)` + **递归换新 id**；拖放落点 `dropControlAt` 直接把结果 `push` 进 `nodes` |
| 3 | 变量/绑定在导出时**解析成字面值** | ✅ **对** | `toV2Json` 走 `resolveDesign`（**唯一入口**），它的第 3 步就是"bindings → nodes（**引用换成字面值**）"；`root.bindings` 仍会写出（供回编辑），但节点字段已经是最终值 |
| 4 | 「**必须用设计包才能带过去**」 | ⚠️ **要修正** | 控件库**本来就写在 design.json 的 `controls` 段里**（`toV2Json` 确实写它）—— 所以"控件库带不过去"这个说法不准确。**真正的分界线是素材**：设计里的图片是相对路径（`assets/xx.png`），单文件导入拿不到旁边的 `assets/` → 表盘只剩空卡片。**必须用设计包的是素材**；而控件库带过去也**没用**，因为 App 侧**完全不读 `controls`**（`DesignFile.kt` 只解析 `nodes`/`assets`/`pages`/`themeColors`，`NodeTreeRenderer` 只认 nodes/assets）—— App 只是把设计原文存下来原样保留 |

补充一条读代码时发现的边界（也写进了第 14 节）：**设计包收集素材时不看 `controls` 段**
（`pack.js` 的 `collectAssetRefs` 只走 `nodes` / `states` / `parts` / `background` / 所有页）。
所以**只存在控件库里、没拖到画布上**的素材**不会进包** ——
"我把控件存进素材库了，为什么导出后它缺图"的答案就在这里。

### 调整

- `KnowledgeFragment` 的 `Section` 与 `companion object` 从 `private` 改成 **`internal`**：
  这一页唯一会静默坏掉的东西（`TAG_MAP` 的索引对齐、标签词表分叉）没有别的守门人，
  而本项目的既定做法是"能测的判定就抽出来测"（见 `data/GestureActions.kt`、
  `obd/SegmentRotation.kt` 的类注释）。**没有抽新文件**（正文 1200 行，抽出去只是搬家），
  只把可见性放宽到"同模块的 JVM 单测够得着"。注释里写了为什么。

### 验证方式

- `tools/run-tests.ps1` → **`TOTAL=824 FAILED=0`**（基线 812 → **824**，+12 =
  `KnowledgeFragmentTest`）+ **构建守卫通过**（`versionName = 1.20.11` /
  APK 6.97 MB ≤ 8 MB / 单 ABI `arm64-v8a` / 11 个 `.ps1` 编码正常 / 122 个控件都有分类）。
  - ⚠️ **这 12 条用例当场抓到了两个真问题**（不是"写完就绿"）：
    ① 我第一版正文里**自己写了 144 个 `**`** —— 正是这一版要修的那个坑，
    被 `正文里没有Markdown标记` 逮到；
    ② `手册各节都有前置步骤判据与排障` 第一版查的是完整的 `【步骤】`，
    而手册 4 把步骤栏拆成 `【步骤 A · 日常使用】` / `【步骤 B · …】` → 误报"缺一栏"。
    两处都是先看到失败再改的。
- `:app:assembleDebug` BUILD SUCCESSFUL（**6.97 MB**）；APK 进
  `dist/iCarOBD-debug-v1.20.11-android.apk`（`dumpsys package` 核对
  `versionCode=80 versionName=1.20.11`）。
- **装机实测**（小米平板 5 / `7e7d7bb4`，横屏 2560×1600；**坐标一律先 `uiautomator dump` 再点**）：

  | # | 判据 | 结果 | 证据（`uiautomator dump`） |
  |---|---|---|---|
  | 1 | 标签条上**有** `使用手册`，且一共 12 个 chip | ✅ | dump 出 `全部/基础/OBD/CAN/ELM327/探测/分析/术语/使用手册/连接/仪表盘/规则`（两行） |
  | 2 | 默认显示全部 | ✅ | 提示行 `共 31 节 · 当前显示 31 节` |
  | 3 | 点 `使用手册` **只显示手册各节** | ✅ | 提示行 `共 31 节 · 标签「使用手册」 · 当前显示 12 节`；标题逐条是 `手册 1 · 第一次连接适配器` … `手册 12 · 日志与导出（怎么给作者）` |
  | 4 | 点 `CAN` **只显示 CAN 相关** | ✅ | 提示行 `共 31 节 · 标签「CAN」 · 当前显示 8 节`；每一节的小字标签都是 `#CAN · #术语` / `#CAN · #分析` / `#CAN · #探测` |
  | 5 | 搜索框仍能用 | ✅ | 输入 `ATCM700` → `共 31 节 · 当前显示 5 节`，命中的正好是 `5. 怎么分析 CAN`、`17. 分段轮换扫描`、`手册 6`、`手册 7`、`手册 8`；输入 `instantiateControl` → `当前显示 1 节`，只有 `14. 「控件 / 主题 / 设计包」…` |
  | 6 | **每节标题 + 标签显示正常** | ✅ | 知识节 `#仪表盘 · #术语`（第 14 节）、手册节 `#使用手册 · #连接`（手册 1）；标题都是 `N. xxx` / `手册 N · xxx` |
  | 7 | **正文里不再有原样显示的 `**`** | ✅ | 先后 20+ 屏 dump（默认 31 节 / 使用手册 12 节 / CAN 8 节 / 搜索命中）**`**` 计数一律为 0**；第 0 节与手册 1 的正文整段 dump 出来逐字可读 |
  | 8 | 无崩溃 / 无 ANR | ✅ | `logcat -b crash` 里 `com.icar.obd` 最后一条停在 **10-07**（v1.20.5 那个已修的 `BottomNavigationView` 上限，早于本轮）；`am_anr` 无本轮记录；当日应用日志尾部只有 `双击：呼出导航` / `切换页面 \| knowledge`，无 `[E]` |

  - ⚠️ **踩到一次"装的是旧包"**：第一次装机用的是**清理 `**` 之前**构建的 APK
    （`run-tests.ps1` 只跑单测 + 守卫，**不重建 APK**，而守卫只核 APK 的名字/体积/ABI），
    于是 dump 里还看得到 `**`。重新 `assembleDebug` + 覆盖 `dist/` + 重装后为 0。
    **判据：改了 `app/` 源码之后要重装，不能只看"守卫通过"。**
- ⚠️ **`uiautomator` 的一个观测限制**（如实记录）：把标签筛到只剩 1 节时，
  该节的**正文节点取不到**（标题与小字标签都在 dump 里，正文那一坨不在）——
  滚动之后 dump 里连整页内容都会消失，往回滚就恢复。
  **不是内容丢失**（滚回来 22 个节点全在），是 dump 只收录可见区 + 短列表下的滚动位置问题；
  正文渲染本身由第 0 节与手册 1 的整段 dump 证明。
  这个滚动位置现象**与本次改动无关**（`fragment_knowledge.xml` 与 `applyFilter` 一个字没动）。

### 遗留问题

- ⚠️ **手册里的"判据"是照 CHANGELOG / 上车监控清单的实测文案写的，不是这一版重新跑出来的。**
  具体说：CAN 探测的帧率数字（77 / 344 帧/秒、0.7→20 帧/秒）、常驻监听的
  `监听通道 | 帧=… 命中=…`、分段轮换的 `轮换换段/轮换段结束/轮换合并`、
  三语义的 `信号跳过 | 原因=DLC不足` —— 这些**设备侧真机路径至今没验过**
  （平板没有连着的适配器 / 车不在旁边，见 v1.20.6~v1.20.10 各自的遗留）。
  手册把它们写成"判据"是对的（那是设计意图），但**别把这一版当成"那些功能已验证"**。
- ⚠️ **手册 3（手势）没法用 adb 验**：`adb input` 只能发单指，双指手势只能靠手指。
  手册里"双指不灵怎么办"那几条是按 `GestureActions.slotOf` 的判据（48dp、先比主轴）
  与 `MainActivity.dispatchTouchEvent` 写的，**没有真机手感依据**。
- ⚠️ **手册没有测试守着"内容对不对"**：单测守的是**结构**（索引对齐、四栏齐全、
  没有 Markdown、标签不分叉），**守不住"步骤写的和界面一致"**。
  界面文案改了（比如按钮改名）手册就会过期 —— 这一页仍然属于
  "文档性质的代码"，改 UI 时记得顺手看一眼。
- **知识库正文的长度**：31 节 / 1285 行源码，全部展开后要滑很久。
  标签与搜索就是为这个加的；如果以后还嫌长，正确的做法是**再拆标签**或
  把"知识"与"手册"做成两个 tab（**但那就违背用户"保持一页"的要求**，要先问）。
- 设备上**没有留下任何测试痕迹**：这一轮只做了只读操作（切标签、输入搜索词），
  没有改任何配置；`settings.json` / `pids.json` / `dash.json` / `rules.json` 一个字没动。

---

## v1.20.10 · 2026-10-09 · 手势加**切上/下一个 tab**（7 个动作）+ **P12 S5 分段轮换扫描**

> 两件事。①用户点名要的两个手势动作：在 6 个导航页之间**循环**切页。
> ②P12 的最后一步 S5：8 段 × 10 秒自动换段，把「哪些 ID 在说话」摸一遍，
> 汇总成**整车 ID 清单**。帧率闸（v1.20.6 的产物）**一行没动**，直接复用。

### 新增

- **双指手势加「切上一个 tab」/「切下一个 tab」**（`data/GestureActions.kt` +
  `ui/MainActivity.runGesture`）—— 动作从 **5 个变 7 个**。
  - **循环顺序只有一处**：`GestureActions.TAB_TAGS = [dash, connect, pid, rule, log, knowledge]`，
    与 `res/menu/bottom_nav.xml` 一致。计算相邻页的是**纯函数**
    `GestureActions.adjacentTab`（`floorMod` 回绕），`MainActivity` 只做
    "tag → `R.id.nav_*`" 的映射。
  - **⚠️ 两个新动作的默认值都是「无」**（`DEFAULTS` 一个字没改）。
    v1.20.9 及以前根本没有这两个动作，升级后任何一个方向突然开始切页，
    用户只会认为"手势坏了"。**这一条有单测钉着**（`GestureActionsTest`）。
  - **新动作排在 `ACTION_IDS` 末尾** → 原有 5 个动作的下标一个都不动，
    旧的 `settings.json` 读回来仍落在同一个动作上。
  - **复用 `switchTo`**：改的是导航栏的 `selectedItemId`，由
    `OnItemSelectedListener` 走**同一条**页面切换路径（不另写一套，
    否则"手势切过去的页面"与"点导航栏切过去的页面"会不是同一个 Fragment）。
  - **认不得的当前页返回 null、什么都不做**（不落回第一个）——
    落回第一个等于"一次手势把用户从任何页面拽到仪表盘"，那正是
    `GestureActions` 刻意不给的"跳指定页"能力。
  - 设置页对话框的说明补了一句"切 tab 在 6 个导航页之间循环"。
- **P12 S5 · 分段轮换扫描**（新文件 `obd/SegmentRotation.kt` + `obd/CanSniffer.kt` +
  `ui/CanSnifferActivity.kt` + 布局加一个勾选框与一行进度）——
  8 段（`0x000`~`0x7FF`）× 每段 10 秒，自动换段，一轮 **80 秒采集**（含 AT 开销约 90 秒）。
  - **掩码 + 过滤成对下发**：`ATCM700` + `ATCF<段>00`（段 0 → `ATCF000` … 段 7 → `ATCF700`）。
    ⚠️ **`ATCF000` 单独发是全总线、不是"第 0 段"**（规格 §7 的同类坑）——
    少了 `ATCM700` 掩码就会得到一份"第 0 段 ID 特别多"的假象，
    而帧数/ID 看起来都正常。`segmentCommands(seg)` 一次返回**两条**，
    单测逐段钉住。
  - **判定全是纯逻辑**（新文件 `SegmentRotation.kt` 里的 `object SegmentRotation` +
    `class RotationPlan`）：段号 / 段范围 / 命令 / 合并语义 / 轮换状态机。
    理由与 `FrameRateGate` 一样 —— `CanSniffer` 是 `object` 且持有
    `Handler(Looper.getMainLooper())`，**JVM 里一碰就抛 `Stub!`**，
    判定写在里面就一条都测不到。⚠️ 状态机**刻意不叫 `SegmentRotation`**：
    同名 `object` + `class` 会把 object 的作用域整个弄坏，
    而报错会跑到**调用方**去（这次真踩了，见"踩坑"）。
  - **"现在第几段"是算出来的**（`elapsed / segmentMs`），不是累加出来的：
    累加式漏一次 tick 就永久偏移，而 ticker 是 500ms 一次的主线程回调。
    `segmentsToAdvance` 返回**列表**：被拖慢的一拍会把欠下的段命令补齐，
    跳过一段的代价是"那一段的 ID 一个都没收到，而日志看起来一切正常"。
  - **换段在 `uiTicker` 里判**（不是独立定时器）：换段要动 `acc`，
    而 `acc` 同时被主线程的 `onChunk` 写 —— 同一个线程里天然串行，不需要锁。
  - **收尾时最后一段先结算**（`finish()` 里 `closeSegment`）：`uiTicker` 一停
    就没人取最后一段的统计了，症状是"`0x700` 那一整段凭空消失"。
  - **合并要补记"段间边界"**（`SegmentRotation.merge`）：每段的累加器都从零开始，
    所以段内 `changed` 少算一次（首帧没有"上一帧"可比）。补的判据是
    "这一段的第一帧与上一段的最后一帧不同 → 那是一次真实变化"。
    不补的后果不是"数字小一点"，而是**按 changed 排序会把跨段跳动的信号埋掉** ——
    而那正是要找的东西。`count`/`values`/`maxDlc` 也一并合（`Accumulator.feedRepeated`）。
  - **每段都有明确日志**（否则出问题没法查）：
    `轮换换段`（第几段/范围/命令/距本轮开始）、
    `轮换段结束`（第几段/帧数/ID 数）、
    `轮换合并`（段数/合计帧/整车 ID/各段逐条）。
  - **界面有进度，不让用户盯着一片空白等 90 秒**（新的一行 `tvSniffRotate`）：
    `轮换中：第 3/8 段 0x200~0x2FF · 本段还剩 6.4 秒 · 整轮还剩 51 秒 · 已收 42 个 ID`。
    勾上「分段轮换」后「采集」下拉框与「过滤器」输入框**置灰**（不是隐藏）——
    隐藏会让人以为控件消失了，置灰能看出"它还在，只是现在不归你管"。
  - **结果走的是同一条导出路径**：合并后的 `acc` 就是普通累加器，
    `aggregates()` / `aggregateCsv()` / 「导出信号表模板」/ S4 解码显示**零改动**。
  - ⚠️ **29 位 ID 一段都扫不到**：掩码 `ATCM700` 只覆盖 11 位 ID 空间。
    这是方案的已知边界（不是 bug），界面上在勾选后的提示里说清了。
- **`CanFrame.Accumulator.feedRepeated(f, now, times)`** —— 补"同一个值又出现了 N 次"，
  与 `repeat(times) { feed(f, now) }` 逐字段等价（有单测）。不循环调 `feed`
  是因为后者每次都建一次 `dataHex()` 字符串并查 `values`，而轮换合并要补的
  次数可能上千。**刻意不追加原始帧流**：补的是聚合计数，不是新观测。

### 修复

- **无**（本轮没有修既有缺陷；`FrameRateGate` / `FrameMonitor` 的帧率闸**一行未动**）。

### 踩坑（记下来，别再犯）

- **`object X` 与 `class X` 同名会让整个 object 的作用域坏掉**：Kotlin 报
  `Redeclaration`，然后 object 里**所有成员**都变成 `Unresolved reference` ——
  而报错出现在**调用方**（`CanSniffer.kt` 里 20 多条"`Unresolved reference 'aggregates'`"），
  根因看起来像是 `CanFrame` 坏了。这次的第一版就是把状态机也叫
  `SegmentRotation`，改成 `RotationPlan` 之后所有报错一次消失。
- **不要用 PowerShell 的 `-replace` + `Set-Content` 改这些带中文的源文件**：
  一次 `Set-Content` 把 `CanSniffer.kt` 的中文全部变成 `?`、并且**吃掉换行**，
  文件从 764 行变成 1 行。已 `git checkout` 还原后重做。
  带中文的源码只能用编辑工具逐处改。

### 验证方式

- `tools/run-tests.ps1` **812 全过**（基线 773 → 812，**+39**：`SegmentRotationTest` 22 /
  `GestureActionsTest` +13 / `CanFrameTest` +4）+ 构建守卫通过。
- `:app:assembleDebug` 通过；APK 进 `dist/iCarOBD-debug-v1.20.10-android.apk`
  （`aapt dump badging` 核对：`versionCode=79 versionName=1.20.10`）。
- **装机（小米平板 5，横屏，`adb -s 7e7d7bb4`）** —— 坐标全部**先 `uiautomator dump` 再点**：

  | 判据 | 结果 | 证据 |
  |---|---|---|
  | 升级后手势总结**不变**（旧配置原样读回） | ✅ | 设置页那一行：`当前：左滑收起导航 · 右滑呼出导航 · 上滑下一套画布 · 下滑上一套画布` |
  | 对话框里**7 个动作**、两个新动作在列 | ✅ | 点开「双指左滑」Spinner，dump 出 7 项：`无 / 呼出导航 / 收起导航 / 切上一套画布 / 切下一套画布 / 切上一个 tab / 切下一个 tab` |
  | 新动作**默认是「无」**（升级不改变手感） | ✅ | 四个槽位 dump 出来仍是 `收起导航 / 呼出导航 / 切下一套画布 / 切上一套画布` |
  | 改一个为「切下一个 tab」→ **落盘** | ✅ | `run-as cat files/config/settings.json` → `"gestureLeft": "tab_next"` |
  | **重启后仍在** | ✅ | `am force-stop` → 重开 → 设置页那一行变成 `当前：左滑下一个 tab · 右滑呼出导航 · 上滑下一套画布 · 下滑上一套画布` |
  | 用户配置**只动了这一处** | ✅ | 与动手前备份逐键对比：`新增键 0 / 丢失键 0 / 变了: gestureLeft 'nav_hide' -> 'tab_next'`（其余 6 个文件 SHA256 不变） |
  | 分段轮换的界面（勾选框 + 进度行） | ✅ | `cbSniffRotate` `checked=true enabled=true`；`spSniffDuration` 与 `etSniffFilter` 同时变 `enabled=false`（置灰）；状态行文案变成 `分段轮换扫描：8 段 × 10 秒 = 约 80 秒。自动逐段下发 ATCM700 + ATCF000…ATCF700，汇总成「整车 ID 清单」。⚠️ 29 位 ID 不在掩码覆盖范围内，本模式看不到。` |
  | 无崩溃 / 无 ANR / 无 E 级日志 | ✅ | `logcat -b crash` 为空（`last-crash.log` 停在 **10-07**，早于本轮改动）；`ANR in com.icar.obd` **0** 条；当日应用日志 363 行、`[E]` **0** 条 |

- ⚠️ **没有验到的**（见下「遗留问题」）：双指手势**本身**（adb 发不出多点触控）、
  **分段轮换的真机数据路径**（平板没连着适配器）。

### 遗留问题

- ⚠️ **双指手势本身 adb 验不了**（`adb input swipe` 只能发单指）→
  "划一下到底会不会切 tab"**需手指实测**。本轮验到的是
  "设置页能看到 7 个动作 + 新两项默认「无」+ 改完落盘 + 重启仍在"，
  以及"动作执行"这一侧的**单测 + 代码审查**。
- ⚠️ **分段轮换的真机数据路径没验成** —— 平板 `Bonded devices` 里
  **有** `EC:5B:73:0C:84:D6 [BR/EDR] Mazda`（比前几版的"完全没配对"好一点），
  但适配器当前 `STATE_DISCONNECTED`（车不在旁边 / 没上电）→
  `CanSniffer.start()` 卡在 `ObdController.isConnected()`，
  点「开始探测」只会弹一个 Toast、应用日志里没有 `CAN 探测开始`。
  **只到单测层面 + 界面层面**，段轮换/换段日志/整车清单**都没跑过**。
  **不要把这一版当成"已验证"**。上车后的判据见下。
- ⚠️ **29 位 ID 扫不到**（掩码 `ATCM700` 只覆盖 11 位 ID 空间）—— 方案边界，不是 bug。

#### 上车后怎么验 S5（判据，别漏）

1. 连接页完成初始化（`READY`）→ CAN 探测页 → 勾「分段轮换」→ 开始探测。
2. **界面**：状态行下面出现进度行，每 ~0.5 秒刷新一次，文案形如
   `轮换中：第 3/8 段 0x200~0x2FF · 本段还剩 6.4 秒 · 整轮还剩 51 秒 · 已收 42 个 ID`；
   段号必须**依次** 1→8，最后一段跑完后变成 `轮换完成：第 8/8 段 0x700~0x7FF · 共 8 段 · 已收 N 个 ID`。
3. **日志**（应用日志页或 `run-as cat files/log/obd-<日期>.log`），一轮里应当各有 **8 条**：
   - `轮换换段 | 第 N/8 段 0x…~0x… 命令=ATCM700+ATCFN00 距本轮开始=…ms`
   - `轮换段结束 | 第 N/8 段 0x…~0x… 帧=X ID=Y`
   最后一条 `轮换合并 | 段数=8 合计帧=… 整车ID=… 各段[1:…帧/…ID 2:… …]`。
4. **判据（这三条任一不成立就是有问题）**：
   - `各段[...]` 里 **8 段的帧数不能都是 0**（全 0 = 过滤器没生效或车没在广播）；
   - 各段 ID 数**不该都相同且很大**（那说明 `ATCF` 没起作用、每段都在收全总线）；
   - `整车ID` 应当 **≥ 各段里最大的那个 ID 数**，且小于各段之和（同一 ID 会在多段出现）。
5. **无 ANR**：`adb logcat -d -b events | grep am_anr` 为空。
6. ⚠️ 轮换结束后**必须**等收尾走完（它含一次 `ATZ` 重新初始化，几秒钟）——
   否则后续 AT 命令会超时（`探测收尾重新初始化` 那条日志出现即为收尾完成）。

---

---

---

---

---

---

---

---

---

---

---

---

---

---

## v1.20.9 · 2026-10-09 · **设计包（`.icarzip`）App 侧导入** + 双指手势可自定义 + 修「音效已开」弹窗

> 三件事：**把"表盘只剩空卡片"那条链彻底堵上**（工具侧 v2.79.0 已能导出设计包，
> 缺的一直是 App 侧解开它）；**双指手势从写死两个方向变成 4 个方向各选一个动作**；
> 以及一个用户点名的小毛病 —— 在别处改过音效后滑到设置页会弹一次「音效已开」。

### 新增

- **设计包（`.icarzip`）的 App 侧导入**（`data/DesignPack.kt` 新文件 + `ui/dash/CanvasSettingsFragment.importPack`）——
  **这是"画布不显示我做好的内容、显示是空的"那个病缺的最后一环**。
  - **自动识别，不加第二个按钮**：读文件头 4 字节（`DesignPack.isZipHead`），
    zip 走包导入、其余当设计文件 JSON 读。多一个按钮就多一条"点错了"的路，
    而"我手上这个文件是什么格式"**文件头就能回答**。
  - 解压到 `files/design/<时间戳>/`，用 `java.util.zip.ZipInputStream`，**零新依赖**。
    包内路径 = 设计里写的相对路径 → 解压后目录结构与引用**天然一致**，
    所以 `designBaseDir` 指到解压目录即可，**不需要任何路径映射**。
  - **按 manifest 逐条校验**：格式版本（`icar.pack/1`）、每个素材的**字节数 + CRC32**。
    对不上就**整个包拒收**并逐条列出"哪个文件、差多少、期望多少"（CRC 用**十六进制**报，
    十进制看不出来对不对）。理由：这份包的意义就是"素材齐了"，
    只导进去一半**恰恰会重现"表盘只剩空卡片"**那个症状，而那时用户已经离原因很远了。
  - **路径穿越防护**：条目名含 `..` 或绝对路径（含 `C:` 与反斜杠写法）→ **整包拒收**，
    并把已解压的内容删掉（**不留半个目录**）。除了字符串归一化，还核一遍 `canonicalPath`
    是否仍在目标目录内。
  - `manifest.missing`（工具导出时就读不到字节的那些）**放行但逐条列成警告** ——
    它们是**已知**的缺口，不是解压出的错。
  - ⚠️ **`designBaseDir` 等用户点「导入」才写**（`applyDesign` 的 `baseDirOverride`）：
    一解开就写的话，"我只是看了一眼那个包"会把当前这套画布的素材基目录换掉，
    而基目录一变，**当前**盘面的相对路径素材立刻就解析不到了。
  - 旧的单文件 `.json` 导入路径**一个字没动**（回归项），SAF 选择器加上
    `application/zip` 并保留 `*/*`（`.icarzip` 没有公认 MIME，按类型过滤会让用户
    **看不到自己刚导出的那个包**）。
- **双指手势可自定义**（`data/GestureActions.kt` 新文件）：
  **4 个方向（左/右/上/下）× 5 个动作**（无 / 呼出导航 / 收起导航 / 切上·下一套画布），
  存 `Store.settings.gestureLeft/Right/Up/Down`。
  - **默认值 = 升级前的手感**：右滑呼出导航、左滑收起导航（v1.20.4 的既有行为）；
    **上滑 = 下一套画布、下滑 = 上一套画布**（本次新增，比"再去点导航栏"顺手得多）。
  - **动作刻意只给"导航类 + 翻页类"** —— 不给「进入编辑态 / 全屏切换 / 跳页」。
    双指手势**没有视觉落点、没有确认框、手指落点也不精确**，
    这三件事误触的代价（改盘面 / 藏导航 / 离开仪表盘）与"呼出导航"完全不对等。
  - **双击兜底不进这张表、不可关** —— 它是"卡在仪表盘页出不去"的保险
    （双指手势在真机上灵不灵，只能靠用户的手指验）。
  - **设置页只编辑那张表，执行只有一处**（`MainActivity.runGesture`）。
    两处各写一套执行逻辑的后果不是"多几行"，而是"设置页显示的映射"与
    "真的执行的动作"慢慢分叉。
  - **方向判定是纯函数**（`GestureActions.slotOf`，有单测）：先比主轴（`|dx|` vs `|dy|`）
    再比阈值（48dp）。反过来判会把"斜着划"一律当成横滑 —— 两根手指不可能完全同步，
    斜划在真机上非常常见。**这一条在真机上没法验**（`adb input` 只能发单指），
    所以单测是它唯一的守门人。
  - **手势仍走 `dispatchTouchEvent` 旁听、不消费**（照旧 `return super.dispatchTouchEvent(ev)`）。
  - **「切画布」先判当前页**：只在仪表盘页有意义（在 PID/日志页上切会改配置却看不到变化，
    所以明说一句而不是静默）；`DashFragment.stepCanvas` 还会判"pager 是不是停在设置页"。
  - 设置页加了一行「手势」+ 一行 `当前：右滑呼出导航 · 上滑下一套画布 · 其余无` 的总结
    （`GestureActions.summary`，纯函数有单测）。
- **手势冲突矩阵写进 [`08-UI控件清单.md`](08-UI控件清单.md) §十**（四类触摸消费者谁管哪一段、
  四条不许破的约定、加新动作要同时改哪几处）。原先这些知识散在 `MainActivity` 的注释里。

### 修复

- **🔴 「音效已开」弹窗**（用户点名）：**病根不是那句 Toast，而是"程序化恢复控件状态
  会触发用户操作的副作用"** —— `refresh()` 里 `swSound.isChecked = …` 会走一遍
  `OnCheckedChangeListener`，于是在别处（连接页）改过音效之后，
  **一滑到设置页就弹一次**。
  - 修法：`CanvasSettingsFragment` 加 `binding` 标志，`refresh()` 整段回填包在
    `try/finally` 里，监听器**先判 `binding` 就返回**。
    ⚠️ `if (isChecked != value)` 那种写法**挡不住** —— 值确实不同，
    而那正是需要恢复的时候。用标志位而不是"临时摘监听器"：摘/挂之间一旦抛异常，
    监听器就永久丢了（表现是"这个开关从此点不动"）。
  - **删掉那句 Toast**（开/关都删）—— 开关自己的位置就是反馈。
  - 同类排查（都**没问题**，各自的写法本来就对）：`ConnectFragment.bindSwitches`
    先设 `isChecked` 再挂监听；`PidAdapter` / `RuleAdapter` 复用时先
    `setOnCheckedChangeListener(null)` 再赋值；`showPollDialog` / `showGridDialog` /
    `showGestureDialog` 的 Spinner 只 `setSelection` **不挂监听**；
    `KnowledgeFragment` 用 `ChipGroup.setOnCheckedStateChangeListener` 而不是给 chip 挂。
- **`DesignFile.parseBackground` 对相对路径的假警报**：原先无条件
  `File(path).isFile` 判"背景在本机不存在"——而相对路径（`assets/背景.png`）
  要拼上 `designBaseDir` 才谈得上存不存在，在这里判的是**进程当前目录**，
  永远为 false，于是每一份带背景的 v2 设计都凭空多一条警告。
  **假警报的代价是用户学会无视整个警告列表**，而这一版恰恰要靠这个列表说清"缺了哪个素材"。
  现在只对**绝对路径**做这项检查（`ThemeStudioSampleTest` 那条"恰好一条警告"依赖的正是绝对路径）。

### 验证方式

- `tools/run-tests.ps1` → **`TOTAL=773 FAILED=0`**（基线 737 → **+36**：
  `DesignPackTest` 18 条 / `GestureActionsTest` 16 条 / `BackgroundSizeTest` +2 条）+ **构建守卫通过**。
- `:app:assembleDebug` BUILD SUCCESSFUL（versionCode **78** / versionName **1.20.9**）。
- **装机实测**（小米平板 5 / `7e7d7bb4`，横屏 2560×1600；**坐标一律先 `uiautomator dump` 再点，不凭记忆复用**）：

| # | 项 | 实测到哪一步（证据都是 dump / `dumpsys` / `run-as` 取回来的） |
|---|---|---|
| 1 | **「音效已开」弹窗**（本次修的） | 先在「连接」页把音效**改回开**（`settings.json` `"sound": true`，即"在别处改过音效"），再冷启动 → 仪表盘 → 左滑到设置页（`swSound` 是**新建的、初始未勾选**的开关，正是旧代码会触发副作用的那一次赋值）：**`dumpsys window windows` 连续采样 22 次，`ty=TOAST` 命中 0** ✅ |
| 2 | 上面那个 0 是"真没弹"还是"检测坏了" | **正控**：同一个检测方法，在设置页点「手势」→「确定」（新代码这里**有**一句总结 Toast）→ **17 次采样命中 7 次**，窗口行 `mAttrs={… ty=TOAST fmt=TRANSLUCENT` ✅ —— 检测方法有效，第 1 项的 0 是真的 0 |
| 3 | 设置页「手势」入口 + 当前映射总结 | `btnGestures`=`手势`、`tvGestureSummary`=`当前：左滑收起导航 · 右滑呼出导航 · 上滑下一套画布 · 下滑上一套画布`（= 设计要求的默认值）✅ |
| 4 | 手势对话框 | 4 个 Spinner 与默认值逐条对上：`双指左滑=收起导航` / `双指右滑=呼出导航` / `双指上滑=切下一套画布` / `双指下滑=切上一套画布`；说明行写明"旁听不抢单指""切画布只在仪表盘页生效""双击不可改" ✅ |
| 5 | 改一个映射 → 落盘 → 重启仍在 | 把「双指上滑」改成**无** → 确定 → 总结变成 `当前：左滑收起导航 · 右滑呼出导航 · 下滑上一套画布 · 其余无`；`run-as cat settings.json`：`gestureUp="none"`，**其余三个键没被动**；日志 `双指手势设置 \| changed=true 当前：…`；`am force-stop` + 重启后总结**仍是"其余无"** ✅ |
| 6 | **双击兜底仍能呼出导航** | 双击画布 → `uiautomator dump` 里出现 `navView [0,0][198,1564]`（收起时这个节点**根本不在**无障碍树里，因为它被平移到屏幕外）＋日志 `双击：呼出导航 \| page=dash` ✅ |
| 7 | **设计包导入**（本次的重点） | 用**工具自己的** `js/zip.js` + `js/pack.js` 生成 `pack-test.icarzip`（`stage/v1209-pack/make-pack.js`；`ZipKit.verifyZip` 自检 PASS：5 条全 store + UTF-8 位）→ push 到 `/sdcard/Download/`（设备侧 md5 与本地一致）→ 从「导入画布」选中它：对话框标题自动变成 **「导入设计包」**、正文 `已解开设计包：3 个素材（解出 5 个文件），素材目录已就位` / `包内设计名：包导入测试`，**0 条警告**（= 逐条 CRC/字节数全对）✅ |
| 8 | 落盘指向解压目录 | `settings.json`：`designBaseDir="/data/user/0/com.icar.obd/files/design/1791477156814"`、`bgImage="<base>/assets/背景.png"`（相对路径已按基目录解析）、`lastImportName="pack-test.icarzip"` ✅ |
| 9 | 解压结构与包内路径一致 | `run-as ls -lR files/design/1791477156814`：`design.json 1753` / `manifest.json 1063` / `assets/指针.png 727` / `assets/背景.png 1395` / `assets/表盘/carbon.png 583` —— **中文目录名原样保留**，路径 = 设计里的相对路径（所以 `designBaseDir` 指过去就能用，**零路径映射**）✅ |
| 10 | **素材字节级正确** | 设备侧 `md5sum` 与本地源 PNG **逐条相同**：`指针.png 88cfc5c3…`=`needle.png`、`背景.png 1cb3b6b7…`=`bg.png`、`表盘/carbon.png e4ebf8ee…`=`dial.png` ✅ |
| 11 | **素材真的显示出来了**（本条的验收核心） | 素材是**纯红 / 纯绿 / 纯蓝**（App 自己的配色里没有这三种颜色），于是用截图逐像素统计（2560×1600 = **4,096,000 px**）：**导入前 纯红 0 / 纯绿 0 / 纯蓝 0** → **导入后 纯红 2,601,712（63.5%）/ 纯绿 933,109（22.8%）/ 纯蓝 107,210（2.6%）** ✅ —— 背景 + 两个图片节点**全部解码并画出来了**，"表盘只剩空卡片"这条链在真机上端到端通了 |
| 12 | 回归 / 无副作用 | 全程 `logcat -b crash` **空**、`ANR in` **0** 条、应用日志 `[E]` **0** 条；用户的两套画布（「你好」8 表 /「画布 2」6 表）内容**逐字段与动手前的备份一致** ✅ |

### 遗留

- ⚠️ **双指手势的 4 个方向本身没验成**（`adb input swipe` 只能发单指，多点触控发不出来）——
  "右滑是不是真的呼出导航"**只能靠用户的手指**，代码侧由 `GestureActionsTest` 的 16 条单测守着
  （方向判定是纯函数）。**这一条要请用户实机试一下。**
- ⚠️ **设计包的"拒收"路径真机没验**（只到 18 条单测）：我造了一个**只改数据、不改中央目录 CRC**
  的坏包（`stage/v1209-pack/corrupt-pack.js`）并 push 到平板，但**没来得及导入** ——
  当时人正在用平板（日志里能看到他自己翻到了「日志」页、切了画布），我停手了，避免误点。
  单测覆盖的正是这条链：CRC 不符 / 字节数不符 / 清单里有而包里没有 / 路径穿越 → **各自报错并指名道姓**。
- **设备上留了一个测试包** `/sdcard/Download/pack-test.icarzip`（6 KB，就是上面第 7 项那个）——
  它是**好的**、可以留着复现；坏包 `pack-badcrc.icarzip` 已删。
- **`activeCanvasId` 现在是「画布 2」，与动手前的「你好」不同** —— 这一条**不是我改的**：
  日志显示 00:21:49 有三次画布切换（画布 2 → 你好 → 画布 2），那正是**用户解锁平板的那几秒**，
  我那时没发过任何点击。**刻意没有改回去**（人自己滑的，改回去等于跟他抢）。
  想恢复的话在仪表盘上左滑一次即可。
- 收尾时已把测试痕迹清干净：临时画布「画布 3」删除、`designBaseDir` 复位为 `""`、
  `gestureUp` 复位为 `canvas_next`、`lastImport*` 复位为 `design-v1.json / 6 / 1791468050720`、
  测试解压目录删除；`settings.json` 与本地还原文件 **md5 一致**（`0a34820a593a69e6ba885e522407d5a4`）。
- 设计包**没有做体积上限**（zip 炸弹防护只做到路径穿越那一层）：素材是 PNG/JPEG，
  正常情况下一个包几 MB；如果以后真有人反馈"导入后存储爆了"，再加"单条 / 总计字节上限"。
  **现在刻意不加** —— 拍脑袋定的上限可能误拒用户的正常包，而那种失败比"存储占用高"更难查。
- 工具侧 v2.79.0 那条遗留（`rawFile` 不持久化 → 重开工具后导包会缺素材）**仍在**，
  它由 `manifest.missing` + 结果对话框的警告如实报出来，App 侧不吞。

---

## v1.20.8 · 2026-10-08 · P12 S3+S4：**能自己造监听型 PID** + **探测页解码显示（"看得懂"）**

> 执行规格：[`20-下一步-CAN信号库实现规格.md`](20-下一步-CAN信号库实现规格.md) §2-S3 / §2-S4。
> S1/S2 已在 v1.20.7 做完（**不要重做**）；S5 的帧率闸已在 v1.20.6 做完（`obd/FrameRateGate.kt`）。
> 目标还是用户那三个：**「抓得更多」「看得懂」「别再被过期/错值骗」** —— 这一轮补的是中间那个。

### 新增

- **`data/PidDraft.kt`（新文件）**：PID 编辑器「表单 → `PidDefinition`」的**纯逻辑 + 全部校验**。
  - **为什么必须抽出来**：S3 要判的东西全是"**填错了但从界面上看不出来**"的那类 ——
    `header` 写错一位 → 常驻监听一直在跑、这条永远没值（日志里只有各 ID 的收帧数）；
    `minDlc` 写小 → 短帧静默不出值（公式解到帧外会抛，`FrameMonitor` 吞掉）。
    判定写在 `Activity` 里的话，JVM 单测**一条都碰不到**。
  - `of()` 与 `build()` **严格往返**。⚠️ `of()` 把 `ttlMs` **原样**写出来（含 `"0"`）：
    0 在 JSON 里与"没这个字段"不可区分（默认值不写出去），当成空就会**改用户数据** ——
    编辑一次内置转向灯，用户什么都没改，行为却变了。
  - 数值字段解析失败**一律硬错误**，不再 `?: 0f` 静默兜底：老写法让用户把 `-40` 打成 `-4O`（字母 O）
    之后**看到 0 而不是报错**，那正是"被错值骗"的入口。
  - `suggestedMinDlc()` 按 `Formula.bitSequence` 的**真实位集**推算"这条信号至少要几个字节"，
    界面把它作为建议说出来。⚠️ **不能用线性的 `起始位/8+长度`**（Motorola 锯齿位序，规格 §7 陷阱 1）。
- **`data/SignalDecode.kt`（新文件）**：一帧 → 人看得懂的话（S4），**纯函数**。
  拿**已有监听型 PID 的 `formula`** 解帧 —— 一行数据模型都没加（这正是规格 §2-S4 说它便宜的原因）。
  三条规矩：**解不出来就说解不出来（`value=null` + `reason`，绝不编值）**；
  **候选（`enabled=false`）要标出来**；**不可信**（DLC 不足 / 命中无效原始值 / 解到帧外）显式说明。
  ⚠️ 判定**复用** `PidDefinition.dlcTooShort` / `hitsInvalidRaw` —— 与运行时 `FrameMonitor` 是
  **同一对函数**。自己再写一遍"帧长够不够"，就会出现"探测页说够、运行时不收"这种互相打脸。
- **PID 编辑器能造监听型条目了**（`ui/PidEditorActivity.kt` + `res/layout/activity_pid_editor.xml`）——
  **这是当前最大的空白**：在此之前用户连第三条监听 PID 都造不出来，只能"导出信号表 → Excel 填 → 导回来"。
  - 新增 `数据来源`（主动请求 / 监听广播帧）、`CAN ID`（= `header`）、以及 S2 的三个字段
    `无效原始值` / `最小帧长 DLC` / `显示超时 ms`。
  - **按来源变形**：监听型把 Mode / PID / 请求帧 / 轮询间隔 / 优先级 / 多 ECU **藏掉**
    （这些填了没人读），`显示超时` 反过来只对监听型显示（主动请求型每次轮询都是新值）。
    ⚠️ **隐藏 ≠ 清空**：只改 `visibility`，输入框里的字还在 → 编辑存量条目、来回切一次、再保存**不丢值**。
    ⚠️ 两个测试按钮对监听型**刻意不禁用**：点它们会走 `fail()` 说出"广播帧不能主动请求，
    到 CAN 探测页开常驻监听"。一个点不动的死按钮，用户就学不到这句话。
  - `header` 是**同一个字段两种含义**，标签跟着来源变：`poll` = `AT SH` 的目标模块头（`7E0`，
    留空 = 广播 `7DF`）；`monitor` = 广播帧的 CAN ID（`09A`）。不换标签的话，用户会把 CAN ID
    填进"模块头"里，然后得到一条永远不命中的监听条目。
  - 公式栏加 `bitsAt(18,1,0,0)` 模板按钮 + 一行说明：
    **`bits(A,起始位,长度)` 与 `bitsAt(起始位,长度,字节序,符号)` 不是一回事**
    （前者只能取单字节内的位）。用错的表现是"解出别的信号的值，看起来却很正常"。
- **CAN 探测页解码显示**（`ui/CanSnifferActivity.kt`）：每行 hex 下面直接给物理值，
  `0x09A → 左转向灯 1`；状态行加**结果汇总**（这一页多少个 ID 绑定了监听型 PID）。
  - **未绑定 PID 的 ID 只显示原始 hex**（不猜值、不加"（无解码）"那种含糊话）；
  - **候选压暗 + 标「候选」**（它没经过验证，不能和已确认的信号长得一样）；
  - **不可信用 danger 色**（这不是样式，是"别拿它当真值"）；
  - 顺带把**观察到的取值集合**也解一遍（聚合器本来就去重存了 ≤8 个）——
    只看"最后一帧"会重犯 `CanFrame.Aggregate.values` 那个已知坑
    （周期信号很容易正好停在暗相位：实车 09A 左转/右转两次的 `last` 都是 `00`，分不出左右）；
  - 每行加「最后收到 N 秒前」（规格 §2-S4 要求的那一项：广播停发时这是唯一能看出来的地方）；
  - 解码结果**一并写进「探测记录」**：界面上的值刷过去就没了，这是上车事后核对"解对了没有"的唯一物证。
- **`Formula.bitsAtArgs(expr)`**：取出 `bitsAt(...)` 那四个字面量参数。
  `rawBits()`（S2 比 `invalidRaw`）与 `PidDraft.suggestedMinDlc()`（S3 建议帧长）**共用**它 ——
  抄成两份的后果不是"多几行"，而是**编辑器算出的建议帧长与实际解码用的位段不一致**。
  `FormulaTest` 有一条用例专门钉住"两边认的是同一个形态"。
- **`PidDefinition.DEFAULT_MONITOR_TTL_MS = 2000`**：新建监听型信号的默认显示超时，
  **唯一权威** —— 信号表导入与手工录入都引用它。字段 `ttlMs` 自己的默认值仍是 `0`（存量零迁移），
  两者**不是一回事**：一条新加的广播信号不判超时，就等于"停发之后仪表还挂着最后一个数字"。

### 调整

- `ui/PidEditorActivity` 的 `collect()` → **`evaluate()`**：测试 / 采样 / 保存三个按钮**共用一份校验**。
  以前每个按钮各写一遍 `if (p.pid.isBlank())`，于是"保存"与"测试"两条路慢慢分叉（一个 Toast、
  一个 `fail`，措辞也不一样）。`save()` **不再拒绝监听型**（那正是本轮要修的空白）。
- `PidFragment` 列表里监听型条目现在会显示 `MON 09A · bitsAt(18,1,0,0)` —— 形状与内置两条转向灯一致。

### 验证方式

- **单测 737 全过**（694 → 737，本轮 +43：`PidDraftTest` 27 条、`SignalDecodeTest` 14 条、`FormulaTest` +2 条 bitsAtArgs）
  + 构建守卫通过（11 个 .ps1 编码正常 / 破折号成对 / 122 个控件都有分类）+ `assembleDebug` 通过。
- **装机（小米平板 5，`7e7d7bb4`）—— S3 端到端全过**，证据逐条可复现：
  1. 「PID」→「+ 新增 PID」→ 数据来源切「监听广播帧」：**Mode/PID/请求帧整行消失**、
     `显示超时` 那一列出现、标签变成「CAN ID（广播帧的报文 ID）」、hint 变 `09A`、
     `bitsAt(18,1,0,0)` 模板按钮与说明出现（`uiautomator dump` 逐节点核对）。
  2. **校验失败看得见**：名称与 CAN ID 都空着点保存 → 结果行出现
     `保存: 校验未通过（2 项）· 名称 不能为空 · 监听型必须填 CAN ID（如 09A）—— 没有它这条永远不命中`，
     且 `scrollRoot` **自动滚到了结果行**（dump 的可见区从"信号校验与新鲜度"开始）。
  3. **手工建一条监听型 PID**：名称 `TestMonitor09A`、CAN ID `09A`、
     公式由模板按钮填成 `bitsAt(18,1,0,0)`、`显示超时` **留空** → 保存。
  4. **落盘字段逐个核对**（`run-as cat files/config/pids.json`）：
     `header=09A` / `source=monitor` / `mode=MON` / `pid=09A` / `formula=bitsAt(18,1,0,0)` /
     `ttlMs=2000`（**留空按唯一权威的默认值**，且 `minDlc`、`invalidRaw`、`customRequest` **都没被写出来** = 默认值不落盘）。
  5. **列表里出现**：分组 `▾ 自定义 (1)` → `TestMonitor09A` / `MON 09A · bitsAt(18,1,0,0) · 0~100`。
  6. **重启后仍在**：`am force-stop` + 重新启动 → 滚到底部，同一条目原样在。
  7. **编辑往返无副作用**：点开那条 → 表单正确回填（数据来源=监听广播帧、CAN ID=09A、
     公式=`bitsAt(18,1,0,0)`）→ 不改任何东西直接保存 → `pids.json` 的 **md5 前后完全相同**
     （`e116644937083d710cbb78df518ab4c5`）—— 钉住"隐藏的字段不会被清掉、默认值不会被重算"。
  8. 全程 **crash buffer 为空、`am_anr` 计数 0**；用户配置 `dash.json` / `rules.json` 与动手前的备份
     **SHA256 逐字节一致**，`settings.json` 只因导航把 `activeCanvasId` 挪到了第 2 套画布，
     **已用备份还原并核对哈希一致**。
- ⚠️ **S4 的真机解码场景没造出来**（与上一轮同一个原因，如实记录）：
  `dumpsys bluetooth_manager` 的 `Bonded devices:` **为空**（平板没配对任何 OBD 适配器），
  于是 `CanSniffer.start()` / `FrameMonitor.start()` 都卡在"设备未就绪"那道闸上 ——
  实测点「开始探测」只弹出一个 Toast 窗口（logcat 有 `Window{... u0 Toast}` 与 `wms.showSurfaceRobustly`），
  应用日志里**没有** `CAN 探测开始` 那一行，状态行仍是"未开始"。
  所以 S4 **只到 JVM 单测层面**（`SignalDecodeTest` 12 条把"解对 / 候选 / 三种不可信"全钉住），
  **真机解码显示没有验过**，下一趟上车补验。

### 遗留问题

- **S4 的真机路径未验**（见上）。上车后的判据：开着常驻监听（或单次探测）时，
  探测页 `0x09A` 那一行下面应当出现 `→ 左转向灯 1`，拨动转向灯变成 `0`；未绑定的 ID 仍然只有 hex。
  「探测记录」里会有 `=== 解码（监听型 PID）===` 一段，那是事后核对的物证。
- **S5（分段轮换扫描）仍未做**。它的帧率闸在 v1.20.6 已经做完（`obd/FrameRateGate.kt` + 14 条单测），
  **不要重做**。
- **平板上的测试条目 `TestMonitor09A`（分组「自定义」，启用）留在设备上了** ——
  它是本轮验收的物证。不需要的话在「PID」页点它 → 删除（30 秒）。
- **`header` 对主动请求型（`AT SH`）在界面上第一次可用**，但**没有实车验证过**（没适配器）。
  改动它之前先看 `PidDefinition.header` 的注释：`AT SH` 是**粘性**的，本项目在请求之间会自动切回广播。
- **中文名没法用 adb 输入**（`input text` 对非 ASCII 抛 `NullPointerException: length of null array`），
  所以装机验收用的名称是 ASCII 的 `TestMonitor09A`；中文名走的是同一条 `setText` 路径，
  且 v1.20.7 的信号表导入（中文 `信号名`）已经端到端验过。

---

## v1.20.7 · 2026-10-08 · P12 S1+S2：**信号表导入/导出** + **运行时三语义（让值不骗人）**

> 执行规格：[`20-下一步-CAN信号库实现规格.md`](20-下一步-CAN信号库实现规格.md)。
> **本轮只做 S1、S2**（S3 录入界面 / S4 探测页解码显示 / S5 轮换扫描 留下一轮）。
> 目标还是用户那三个：**「抓得更多」「看得懂」「别再被过期/错值骗」** —— 这一轮做的是后两个的一半。

### 新增

- **`data/SignalTableCsv.kt`（新文件）**：25 列「信号表」的**唯一**生成/解析实现，**纯函数、可 JVM 单测**。
  - 模板：**每个观察到的 CAN ID 一行**，预填 `报文ID(hex)`/`报文ID(dec)`/`DLC`/**观察到的取值集合**，其余留空。
    第 25 列是模板的核心价值 —— 它把 `turn-signal-09A.md` 里那个人工判据
    （"操作开关 → 看取值集合变了哪一位"）**印在表里**，人不用自己翻 hex。
  - 导入：**按列名**匹配（人在 Excel 里插列/调序不会让导入错位 —— 错位的后果是"值解错了但看起来正常"）；
    硬错误整行拒绝、软警告照收但**汇总显示**；按 `(报文ID, 信号名)` 确定性推 PID id → **重复导入是覆盖不是翻倍**。
  - **BOM 只在这里定义一次**（`BOM` / `withBom`）：三处写 CSV 的地方都引用它 —— 本项目恰恰因为
    `CsvRecorder` 漏了 BOM 让 Excel 里的中文表头一直是乱码。
- **公式语言加通用位段函数 `bitsAt(起始位,长度,字节序,符号)`**（`data/Formula.kt`，规格 §3.5）：
  字节序 `0=Intel(LE) / 1=Motorola(BE)`，符号 `0=unsigned / 1=signed`。
  求值器手里**有整帧**，所以它自己按位序遍历 —— 于是**任何一行信号表都能生成公式**，不存在"表达不了"的行。
  同时把位序逻辑抽成 `Formula.bitSequence()`：**判"解到帧外"与"位重叠"都用它**，
  ⚠️ **不能用线性的 `起始位+长度`**（Motorola 是锯齿位序；实测在宝马参数表上误报过 2 条越界，都是误报）。
  另加 `Formula.rawBits()`：取 `bitsAt(...)` 那一段的**原始值**，给 `invalidRaw` 用（见下）。
  ⚠️ `bits(v,start,len)` 与 `bitsAt(...)` 名字太像 —— **类注释里写了对照表**，别用错。
- **CAN 探测页**：两个观察表导出改**中文表头 + BOM + `报文ID(dec)` 冗余列**
  （`can-observe-aggregate.csv` / `can-observe-raw.csv`），新增「**导出信号表模板**」（`can-signal-template.csv`）
  与「**导入信号表**」（SAF 选文件 → 校验 → 物化成 `PidDefinition(source=monitor)` → 写 `Store`）。
  入口刻意放在探测页：探测完就在那儿。
- **`PidDefinition` 加 3 个字段**（规格 §3.2）：`invalidRaw` / `minDlc` / `ttlMs`。
  **三个默认值都等于旧行为 → 存量 `pids.json` 零迁移**（默认值一律不写进 JSON）。
- **`PidValue.ttlMs`** + `VehicleBus` 取值入口的**唯一**新鲜度判定：`now - ts > ttlMs` → 返回 `ok=false` 的副本。

### 修复

- **CSV 不带 BOM → Windows Excel 按 ANSI 打开、中文表头乱码**（规格 §7 陷阱 3）：
  `CsvRecorder` 首次写表头前先写 `\uFEFF`。行车记录 CSV 的表头是 **PID 的中文名**，
  乱码不是"难看"，是**列名认不出来**。
- 观察表 CSV 的 `报文ID(dec)` 冗余列：`报文ID(hex)` 有 `9A` / `09A` 两种写法，两个都印出来，人抄哪列都不会错。

### 调整

- `Formula.check()` 的假数据从 **26 字节 → 64 字节**（CAN FD 上限）。
  26 只够变量 `A..Z`，会让起始位靠后的**合法** `bitsAt` 公式被静态校验误判成"解到帧外"。
- `Store` 加 `upsertPids(list)`：导入一份信号表可能有上百行，循环调 `upsertPid` 会**写盘上百次**
  （而导入在**主线程**的 SAF 回调里跑）—— 改成一次写完。
- `CanFrame.Aggregate` 记 **`maxDlc`**（最长帧）：模板的 `DLC` 列要预填"能放下这条信号的那种帧"，
  取最后一帧会让 DLC 随机偏小 → 导入时被"解到帧外"误拒。

### S2 的三个语义（让值不再骗人）

| 语义 | 实现 | 为什么这么设计 |
|---|---|---|
| **DLC 守卫** | `FrameMonitor.feedLine`：帧长 < `minDlc` → **不解析** + 记一条 `信号跳过 \| 原因=DLC不足 需要=N 实际=M` | 同一个 ID 的 DLC 并不固定（会有 4 字节和 8 字节两种帧），运行时守卫比"假设这个 ID 永远是 8 字节"可靠 |
| **无效原始值** | 解析出原始值后先比 `invalidRaw` → 命中则 `ok=false` | `0xFF` 按 `A-40` 算出来是 **215℃** —— 仪表照画、规则照触发、CSV 照记。这正是"被错值骗" |
| **新鲜度** | `PidValue.ttlMs` + `VehicleBus` 取值入口判超时 → `ok=false` 的副本 | 广播停发时**没人来清掉最后一个值**，仪表会一直挂着"最后一次收到的那个数字"，看起来跟实时一样 |

**为什么"变成 `ok=false`"就够了（已核实，下游零改动）**：`VehicleBus.value()` 与 `DashRenderer`
**都是 `ok` 才给值** → 仪表自动显示 `--`、规则不误触发（`RuleEngine` 用 `snapshot()`/`value()`）、
CSV 记空（`ObdController` 用 `snapshot()`）。所以三个入口（`get`/`value`/`snapshot`）**必须都过同一关**，
漏一个就留下一条"看得见旧值"的路。

两条判定（`dlcTooShort` / `hitsInvalidRaw`）**抽成 `data/PidModels.kt` 里的纯函数**，而不是埋在 `FrameMonitor` 里：
那个 object 在 JVM 里一碰就抛 `Stub!`（`Handler(Looper.getMainLooper())` 是饿汉初始化），写在里面就**一条都测不到**
（S5 的 `FrameRateGate` 出于同一个理由被抽出来）。

### 验证方式

- `tools/run-tests.ps1` → **`TOTAL=694 FAILED=0`** + 构建守卫通过（617 → 694，**+77**；其中 **76 条是本轮新增**，
  另 1 条来自工作区里一个**未被 git 跟踪**的既有测试文件 `data/DesignDraftFromImageTest.kt` —— 它不是本轮的产物，
  也不引用本轮任何新代码，列在这里只是为了把总数对上）：
  `SignalTableCsvTest` 40 条（25 列往返 / 硬错误逐条 / 软警告逐条 / 位重叠 / Motorola 真实位集 / CSV 引号与 CRLF）、
  `FormulaTest` 新增 16 条（Intel·Motorola × 对齐·跨字节 × signed·unsigned + `bitSequence` + `rawBits`）、
  `PidModelsTest` 新增 9 条（3 字段 JSON 往返 + **旧 JSON 缺字段取默认值** + 两条纯判定）、
  `VehicleBusTtlTest` 9 条（ttl 超时 → `ok=false`，`get`/`value`/`snapshot` 三个入口各一条）、
  `CanFrameTest` 补 BOM / 中文表头 / `maxDlc`。
- `:app:assembleDebug` BUILD SUCCESSFUL（**7.24 MB** / 单 ABI `arm64-v8a`）。
- **装机实测**（小米平板 5 / `7e7d7bb4`，横屏 2560×1600，`versionName=1.20.7 versionCode=76`，
  坐标全部来自 `uiautomator dump`，**没有复用记忆里的坐标**）：

| # | 项 | 实测到哪一步 |
|---|---|---|
| 1 | 探测页新按钮 | `uiautomator dump` 读到「导出观察表」「导出原始帧」「导出信号表模板」「导入信号表」四个按钮及其 bounds ✅ |
| 2 | 无数据时的导出守卫 | 点「导出信号表模板」→ `dumpsys window` 出现 `Toast` 窗口，截图 OCR 读到 `还没有数据可导出`；`/sdcard/Android/data/com.icar.obd/files/export/` **没有被创建**（确实一个字节都没写）✅ |
| 3 | **导入信号表（正常路径）** | 手写一份带 BOM 的 25 列 CSV（含一条带逗号的 `值表` 字段）push 到「下载」→ SAF 选中 → 对话框：`文件：signal-ok.csv 数据行 2 · 收下 2 · 硬错误 0 · 软警告 2`（两条软警告正是「单位为空」「证据为空」）✅ |
| 4 | **落盘字段逐个核对** | `run-as cat files/config/pids.json` 读到 `mon_09A_LeftTurn`：`header=09A` `source=monitor` `mode=MON` `formula=bitsAt(18,1,0,0)` `minDlc=3` `ttlMs=2000` `enabled=true` `group=TurnSignals` `note=信号表\|报文名=…\|值表=0:关,1:开\|…`；`mon_2C7_OilTemp`：`formula=bitsAt(7,8,1,0) - 40` `invalidRaw=255` `minDlc=1` `enabled=false`（候选）✅ |
| 5 | PID 列表 | 滚动后读到两个新分组：`TurnSignals (1) → LeftTurn · MON 09A · bitsAt(18,1,0,0) · 0~1`、`监听型(信号表) (1) → OilTemp · MON 2C7 · bitsAt(7,8,1,0) - 40 · -40~215 ℃` ✅ |
| 6 | **导入信号表（坏行）** | 另一份 CSV（1 行合法 + 3 行硬错误）→ 对话框 `数据行 4 · 收下 1 · 硬错误 3 · 软警告 0`，三条硬错误逐行报出：`字节序 不认识：「middle-endian」` / `长度(bit) 必须在 1..32（收到 33）` / `信号解到帧外：起始位=18 长度=1（0）真实位集最高到第 3 字节，而 DLC=2` —— **坏行没有拖垮好行**（收下 1）✅ |
| 7 | 应用日志 | `[22:41:04][UI][I] 信号表导入 \| 文件=signal-ok.csv 数据行=2 收下=2 硬错误=0 软警告=2`、`[22:42:56][UI][I] 信号表导入 \| 文件=signal-bad.csv 数据行=4 收下=1 硬错误=3 软警告=0`、以及 `轮询列表已刷新 count=25`（**监听型 PID 不进轮询列表**，正确）✅ |
| 8 | 回归 | `logcat -d -b crash` **空**、`ANR in` **0**；重启后仪表盘正常渲染 ✅ |
| 9 | **用户配置没被测试改坏** | 与动手前的备份逐字节比 SHA256：`settings.json` / `dash.json` / `rules.json` **全部一致**；测试导入的 3 条 PID 已删（`pids.json` 恢复成"不存在"，与动手前一致）；push 到「下载」的两个 CSV 已删 ✅ |

### 遗留

- ⚠️⚠️ **两个观察表 CSV 与模板 CSV 在平板上没能真正产出来。** 平板**没有配对任何蓝牙设备**
  （`dumpsys bluetooth_manager` 的 `Bonded devices` 为空），而 `CanSniffer.start()` 要求已连接 →
  探测跑不起来 → `aggregates()` 为空 → 导出按钮被「还没有数据可导出」挡住（第 2 条实测就是这个）。
  所以「导出文件第 1 个字节是 `EF BB BF`」这条**只在 JVM 层验到**：
  用**同一份生产代码**（`aggregateCsv()` / `rawCsv()` / `template()`）+ 同一个 `File.writeText` 落成文件后，
  PowerShell 读到三个文件的头三字节都是 `EF BB BF`，中文表头与模板预填列也都对
  （模板：`0x09A,154,,8,…` + 取值集合）。**下一趟上车必须补做设备侧的那一次**。
- ⚠️ **S2 的三个语义真机一个都没造出来**（同一个原因）。设备上的直接证据是
  `[22:45:37][OBD][W] 设备未就绪，无法开启常驻监听` —— `FrameMonitor.start()` 要求已连接。
  所以 `raw=FF → 仪表 --`、`停 2 秒 → --`、`短帧 → 日志有 DLC不足` 这三条
  **只到单测层面**（`dlcTooShort` / `hitsInvalidRaw` / `VehicleBusTtlTest`），**下一趟上车补验**。
  「连接」页的**模拟信号造不出这个场景**：`SignalSimulator` 直接写 `ok=true` 且 `ttlMs=0`，
  也不经过 `FrameMonitor`（没有 invalidRaw / DLC 判定）—— 这不是懒，是它本来就不走那条路。
- **规格 §3.4 的「起始位 ≤0 是硬错误」按意图实现了**：起始位 **0**（帧首字节最低位）是合法信号，
  照字面实现会把合法行全部拒掉。所以实现是「起始位 **<0** 才是硬错误」，`长度` 仍然 1..32，
  并且 `SignalTableCsvTest` 有一条用例专门钉住这个偏差 —— 免得下一个人"照规格改回去"。
- **`最小/最大` 空白时按编码范围兜底**（`0..2^len-1`，signed 是 `-2^(len-1)..2^(len-1)-1`）。
  规格把这两列标成必填，但 §2-S1 的验收步骤只让人填"起始位/长度/字节序/符号/因子" ——
  不给兜底的话那条验收路径走不通。**它们只当显示量程，做掩码只用 `长度(bit)`**（规格 §7 陷阱 2）。
- **`可信度` 空白按「候选」处理并给软警告**（规格的软警告清单里没有这一条，是本轮补的）：
  默认"启用"会把没验证的值显示在仪表上，而那正是"被骗"的来源。
- **`toggleMonitor()` 的按钮文案是个预先存在的小毛病**（不是本轮引入、也没改）：
  点「开启常驻监听」时若 `FrameMonitor.start()` 因未连接而拒绝，按钮文案仍会被改成「停止常驻监听」。
  实测第 9 条里就复现了。要修的话应该改成"以 `onStateChanged` 为准"，属下一轮。
- **`tools/run-tests.ps1` 在 Kotlin 编译失败时会打印上一次的 `TOTAL=`**（读的是 `build/test-results` 里
  **陈旧**的 XML）并继续跑构建守卫 —— 这一轮我自己就被它骗过一次（先看到 `TOTAL=617 FAILED=0` + 守卫通过，
  是 `exit code 1` 才让我回头看编译错误）。**本轮没改它**（写入范围只有 `app/`），
  但建议下一轮给它加一句"gradle 失败就直接退出"。
- 设备上留了这次导入测试产生的日志行（`信号表导入 | 文件=signal-*.csv`）——
  它们是真的发生过，不是假数据；`pids.json` 已经删掉，PID 列表回到动手前的状态。

---

## v1.20.6 · 2026-10-08 · P10 一批：**看得见的失败** + 监听帧率闸 + 导入记录

> 主题是同一件事：**把"看起来没反应"变成"明确告诉你发生了什么"**。
> P10 表格里前 4 条都亲眼见过症状，这次全做了（外加用户点名要的导入记录）。

### 新增

- **常驻监听警示条**（P10-3）：`ui/view/MonitorWarnBar.kt` —— 监听期间顶部常驻
  `监听中 · 轮询已暂停（转速/水温冻结）`，**不用翻页就能看到**。
  挂在 `android.R.id.content` 上（浮层、不占布局）—— 在 `activity_main.xml` 里加一行
  会让 `pageContainer` 变矮 → 画布尺寸变化 → 表盘重排 + 闪一下（v1.20.4 的教训）。
  判定与文案只有一处（`FrameMonitor.running`），CAN 探测页的状态行共用同一句。
- **「最近一次导入」记录**（用户点名要的）：画布设置页显示
  `最近导入：未命名设计-v1.json · 5 块表 · 10-08 21:30`，落在
  `Store.settings.lastImportName/lastImportGauges/lastImportAt`（进 `settingsToJson` /
  `applySettingsJson`，所以**重启后还在、备份也带上**）。摘要格式化是 `Settings.lastImportSummary()`
  —— 纯函数，有 4 条单测。导入成功时 Toast 也带上文件名。
- **`obd/FrameRateGate.kt`**：帧率闸的**纯逻辑**（三级：正常 / 按 ID 预筛 / 整块丢弃 + 迟滞）。
  抽出来是因为 `FrameMonitor` 那个 object 在 JVM 里一碰就抛 `Stub!`
  （`Handler(Looper.getMainLooper())` 是饿汉初始化），判定不抽出来就**测不到**。
- **`ui/SafFile.kt`**：SAF 文件显示名的**唯一**实现（三级回退）。规则编辑器选音频原来
  自己写了一遍，两处各写必然分叉。

### 修复

- **P10-2 校验失败只改一行小字**：PID 编辑器与规则编辑器现在**弹 Toast + 结果行染警示色 +
  自动滚到可见**（三样一起，各有分工：Toast 保证"不管滚到哪都看得见"）。
  规则编辑器还补了一条原来没有的校验 —— **条件没配全时 `testRuleOnce` 会返回"不成立"**，
  用户会去怀疑车/信号，而真正的原因是那一行的数据源根本没选。
- **P10-4 `ATH1` 三次都失败仍照跑**：现在 `ATH1` / `ATS1` 连试 3 次都不是 `OK` 就
  **判定这趟无效**，状态行与 Toast 直接说「**准备失败，请重跑一次**」，并把轮询还回去。
  为什么这两条是致命的：没有 `ATH1` 就没有 CAN ID、没有 `ATS1` 整帧切不出 token ——
  两者任一失效**这趟必然 0 帧**，继续跑只会给出一份让人猜的空结果。
  （`ATL1` 只影响粘行概率，失败仍然继续。）
- **P10-5 监听分片回调走主线程（热路径）**：信号跨多个 ID 段时 `filterPlan` 退化成
  "不加过滤器" → 实车 **344 帧/秒全在主线程切行**（本项目已因此 ANR 过一次，v1.18.4）。
  三道闸：>150 行/秒**自动按监听 ID 做零分配预筛**（不相关的帧连解析都不做）、
  >240 行/秒**整块丢弃**（连切行都不做），并弹一次
  「信号跨多个 ID 段，请把监听拆成两次」。顺带把切行的两处浪费改掉：
  用游标记住扫到哪（原来每取一行都从下标 0 重扫）、行攒到最后一次性 `delete`
  （原来每行都搬一次整个缓冲区）。

### 验证方式

- `tools/run-tests.ps1` → **`TOTAL=617 FAILED=0`** + 构建守卫通过
  （新增 18 条：`FrameRateGateTest` 14 条 / `DashCanvasTest` 4 条）
- `:app:assembleDebug` BUILD SUCCESSFUL（6.87 MB / 单 ABI `arm64-v8a`）
- **装机实测**（小米平板 5 / `7e7d7bb4`，横屏 2560×1600，`versionName=1.20.6 versionCode=75`）：

| # | 项 | 实测到哪一步（**都是 uiautomator dump / dumpsys 拿的坐标与证据，不凭记忆**） |
|---|---|---|
| 1 | P10-2 PID 编辑器 | 新建 PID 留空 → 点「发送测试请求」→ `dumpsys window` 出现 `Window{… u0 Toast}`（`ty=TOAST` `gr=BOTTOM CENTER`）、`tvResult='解析结果: 请先填写 PID'`、日志 `PID 编辑器校验未通过 \| 请先填写 PID` ✅ |
| 2 | P10-2 规则编辑器 | 新增规则 → 删掉条件行 → 点「用当前实时数据试判一次」→ Toast 窗口出现、`tvTestResult='试判: 请至少配置一个有效条件（数据源那一栏是空的）'`、日志 `规则试判未通过` ✅（这条校验是本次**新加**的） |
| 3 | 「最近一次导入」 | 先新建一套**临时画布**（不动用户的 8 块表）→ 从「下载」里选一个 v1 设计文件导入 → `tvLastImport='最近导入：design-v1.json · 6 块表 · 10-08 22:00'`、日志 `已导入设计文件 \| canvas=画布 3 file=design-v1.json gauges=6`；**force-stop 重启后仍在**，`settings.json` 里三个键都在 ✅；随后删掉临时画布、把当前画布切回原来的「你好」 |
| 4 | 回归 | 仪表盘 / 连接 / PID / 规则 / 日志 / 知识库 六页各走一遍；`logcat -b crash` **空**、`ANR in` **0**；应用日志无 `[E]`。CAN 探测页点「开始探测」（无设备）→ Toast 窗口出现、状态行仍是「未开始…」文案（`refreshStatus` 没把正常分支改坏）✅ |
| 5 | **配置未被测试改坏** | 与动手前的备份逐字段对比：2 套画布、名字 / 类型 / 表数 / 主题 / 背景**全部一致**，`activeCanvasId` 回到原来的「你好」。**唯一差异是新增的 `lastImportName='design-v1.json'`**（那条记录本身，见下） |

### 遗留

- ⚠️⚠️ **P10-3 / P10-4 的完整路径这一趟没验成** —— 平板**没有配对任何蓝牙设备**
  （`dumpsys bluetooth_manager` 的 `Bonded devices` 为空，适配器是插在车 OBD 口上取电的），
  而 `FrameMonitor.start()` 与 `CanSniffer.start()` 都要求**已连接**。所以：
  - 「开启常驻监听后顶部出现警示条」只验到**不出现时不影响任何页面、每秒 ticker 不崩**；
  - 「`ATH1` 三次失败 → 准备失败，请重跑一次」只验到**编译与单测层面**，
    真机上的失败场景**没造出来**（要一台能连上但 `ATH1` 不应答的适配器）。
  两条都要**下一趟上车补验**，判据已写进 [`16-上车监控清单.md`](16-上车监控清单.md) §4.4。
- **P10-5 的帧率闸只做到"逻辑可单测 + 装机不回归"**，**没有在车上制造过 344 帧/秒**：
  预筛的零分配与三级判定有 14 条单测钉着（含"预筛不许漏掉解析后能命中的行"这条安全性质），
  但真机上的帧率数字只能等下一趟上车看 `监听通道 | … | 帧率闸：…` 那一行。
- **P10-6**（`verify-crosslang.js` 把 `mon_turn_left/right` 误报成"工具里多出 2 个 PID"）
> ✅ **已修（v1.20.6，工具侧）**：根因是 `parseKotlinTemplates` 里的前缀白名单 `^tpl_` —— v1.19.13 把实车确认的转向灯（`mon_turn_left`/`mon_turn_right`，`mode="MON"`）放进了**同一个 `MANUFACTURER_TEMPLATES` 列表**，却因为不叫 `tpl_` 被静默跳过，于是被算成"工具独有"。改成**按那个列表切片解析**后 PASS=104 FAIL=0，备注里不再出现 `mon_*`。
  **本次没做** —— 它在 `tools/` 下，而本轮的写入范围只有 `app/`。
- 常驻监听的 `ATH1` 准备失败**没有**像单次探测那样直接判定无效（它是常驻模式，
  没有"这一趟"可言）：仍会照常进入监听，但日志会记 `监听准备未生效`。
- 设备上留了一条**测试留下的导入记录**（`最近导入：design-v1.json · 6 块表 · 10-08 22:00`）——
  它是真的导入过，不是假数据；想清掉就随便再导一次别的设计文件（或把
  `settings.json` 里 `lastImportAt` 置 0）。

---

## v1.20.5 · 2026-10-08 · 🔴 **P0：手机（竖屏）一启动就崩** —— `BottomNavigationView` 硬上限 5 项

> 用户报「我在手机端是打不开的」。**是我 v1.20.3 引入的崩溃**，与 OTG 无关。

### 现场（手机上抓的）

```
20:59:04.079  Start proc 27019:com.icar.obd
20:59:04.211  E/AndroidRuntime: FATAL EXCEPTION: main
20:59:04.220  Force finishing activity com.icar.obd/.ui.MainActivity
20:59:04.243  Process com.icar.obd (pid 27019) has died
```

app 自己的日志里只有一行 `===== iCar OBD 启动 =====`，**130 毫秒后就死**。堆栈：

```
java.lang.RuntimeException: Unable to start activity ...MainActivity
  at ...MainActivity.onCreate(MainActivity.kt:58)          ← setContentView
Caused by: android.view.InflateException: Binary XML file line #52 in
           com.icar.obd:layout/activity_main: Error inflating class
           com.google.android.material.bottomnavigation.BottomNavigationView
Caused by: java.lang.IllegalArgumentException:
           Maximum number of items supported by BottomNavigationView is 5.
```

### 根因

`BottomNavigationView`（**竖屏**底部导航）的菜单项**硬上限是 5**。
v1.20.3 给导航栏加了第 6 个 tab（知识库）→ 竖屏布局里的 `app:menu` 在
**构造函数里**就 inflate 菜单 → 直接抛异常。

**为什么平板一直没事**：平板是**横屏**，用的是 `NavigationRailView`，
**没有**这个上限 —— 所以这个 bug **只在手机上暴露**，装机验证时漏了。
（教训：**竖屏必须单独验一遍**，不能只验平板。）

### 修法

已核实 **Material 1.12.0 根本没有 `setMaxItemCount`** —— 把
`material-1.12.0/jars/classes.jar` 里的 `NavigationBarView` / `NavigationBarMenu` /
`BottomNavigationView` 三个类**逐个按字节搜过**，只有 `getMaxItemCount`，没有 setter。
**这个 5 是写死的、没有公开改法。**

但 `getMaxItemCount()` **可重写**，而且 `BottomNavigationView` 的构造函数里是
**虚调用**它（`new NavigationBarMenu(context, getClass(), getMaxItemCount())`）——
Java 的虚调用会派发到子类重写，**在构造过程中就生效**。

所以新增本地子类 **`ui/view/NavBottomBar.kt`**（重写 `getMaxItemCount()` 返回 6），
竖屏布局改用它，`app:menu` 照旧。**10 行代码，不动 Material 版本。**

### 验证

- **手机（竖屏，小米 24122RKC7C / Android 16）**：`pidof` 有值、无 FATAL、
  `ResumedActivity = com.icar.obd/.ui.MainActivity` → **能打开了** ✅
- 平板（横屏）不受影响（它走 `NavigationRailView`）
- 单测全过、构建守卫通过

### 顺带排除的两个误解

1. 用户提到「OTG 已经连接上了」—— 实测手机 `dumpsys usb` 是 **`host_connected=false`**，
   即当时处于 **MTP 从设备模式**（正连在电脑上），**并没有进入 USB 主机模式**，
   所以 OTG 那边也还没生效。
2. **本 app 完全没有 USB / 串口 / OTG 代码**（只有 `BleTransport` 与 `SppTransport`，
   权限也只有蓝牙）—— 要支持 USB 版 ELM327 得单独做一条传输层。
   顺带记录：该手机内核**没有 `ch341` / `pl2303` 驱动**（有 `ftdi_sio` / `cdc_acm`），
   所以 CH340 类 USB 串口芯片在这台手机上本来也认不出来。

## v1.20.4 · 2026-10-06 · 导航栏改**悬浮**（不再挤画布）+ 去掉把手改**双指手势**

> 用户三条反馈。第 3 条（P0）查到了**决定性的结论**，见下。

### 导航栏改成悬浮层（不再挤画布）

用户原话："仪表台里面 tab 页面要以**悬浮窗**的形式去显现，**不然会把画布挤掉**"。

**根因是布局结构**：根容器是 `LinearLayout(horizontal) { navView, divider, pageContainer }`
—— 导航栏占 198px，**画布就少 198px**；而且仪表盘页把它"滑出去"时
`pageContainer` 会重新量一次 → 画布尺寸变化 → 表盘重排 + 闪一下。

**改法**：根容器换成 **`FrameLayout`**，`pageContainer` 永远整屏，导航栏带
`elevation` 浮在上层（横屏贴左、竖屏贴底）。展开/收起只动它自己的
`translationX/Y` + `alpha`，**画布一动不动**。

**实测**：导航栏显示时 `navView [0,0][198,1564]`，而
**`pageContainer` 仍是 `[0,0][2560,1564]`** ✓（改之前会变成 `[200,0]`）。

### 去掉左边缘把手，改**双指横滑** + 双击兜底

用户原话："半透明把手还是有点不好按、**总是触发系统的手势退出**、
要么采用个手势、**双指拖动的时候呼出来**"。

把手这个方案试了两版都不行：第一版贴在 x=4px（≈2dp）—— 正在**系统返回手势的热区**里；
挪到 32dp 后好按了一些，但仍然会误触系统手势。**用户的方案是对的**：

- **双指横滑**：右滑呼出、左滑收起。实现是重写 `MainActivity.dispatchTouchEvent`
  —— **旁听全部触摸但不消费**（照旧交给 `super`）。
  用透明 View 不行：要"看着"双指就得消费 DOWN，那样单指手势会被吃掉。
  双指的好处是**不与任何单指手势冲突**（系统边缘手势、ViewPager 横滑、拖表盘都是单指）。
- **把手整个停用**（不再创建）。
- **双击画布**兜底：因为**双指手势没法用 adb 验**（`adb input` 只能发单指），
  万一在真机上不灵，用户会**卡在仪表盘页出不来** —— 这是不能赌的。
  双击不与任何已有手势冲突（拖表盘是"按下-移动"、横滑是"按下-快滑"，都不产生"两次快速点按"）。

### 🔴 P0（第 3 条）· 结论：**文件是合法的，是"根本没导进去"**

用户报"画布还是不会显示控件"，并给了实际文件（`未命名设计-v1.json`，1132 字节）。

**先排除渲染**：那份文件是 `icar.ui/1`、**没有任何素材**、5 个 PID
（`std_0C/0D/05/42/11`）**全是内置的**、坐标都在 0..360 内 —— 逐条看都合法。
把它做成单测（`DesignFileUserCaseTest`）跑通，**钉住了三件事**：

```
parse → 0 个硬错误
5 块表全部解析 ✓
坐标没有被 ×360（x=0 y=45 w=180 h=180 原样）✓   ← unit 标记注入是对的
5 个 PID 在内置库里都查得到 ✓
```

**再看设备配置**（`files/config/settings.json`）：

```
[0] name=你好    type=2 gauges=8 designJson长度=0
[1] name=画布 2  type=2 gauges=8 designJson长度=0
```

**两套画布都还是 8 个表、`designJson` 全空** → **导入这一步根本没生效**。

所以问题**不在渲染、不在解析**，在**"导入操作"这一段**。下一步要分两种情况定位：

- 没看到确认框 → 是选文件环节（SAF 没选中 / 选完没回来）；
- 看到确认框也点了导入、却还是 8 个表 → 是**导入后被覆盖回去**了，
  优先查 `Store.load()` 里 `dash.json`（v1 遗留镜像）与 `settings.json` 的先后与写回。

⚠️ **日志尾部还停在 23:54**（`AppLog` 批量落盘没刷），所以那次的现场看不到 ——
这也是为什么下一版要把**导入结果做成一眼可见的记录**，而不是靠日志猜。

### 新增单测

`DesignFileUserCaseTest` —— **用用户实际给的失败文件当用例**。
以后再有人动 `DesignFile.parse` / `unit` 注入 / 内置 PID 库，这条会立刻报警。

### 验证方式

单测 **599 全过**、构建守卫通过、`:app:assembleDebug` 通过。
装机实测（小米平板 5 / `7e7d7bb4`）：画布整屏 ✓、把手已移除 ✓、双击呼出导航 ✓、
导航栏显示时画布仍整屏 ✓。
⚠️ **双指手势未验**（adb 发不出多点触控），需要手指实测。

---

## v1.20.3 · 2026-10-06 · **P0 真凶：`designBaseDir` 从没被赋值** + 导航/知识库/列表三处体验

> 用户一次性报了 7 件事。**其中 P0 我上一版诊断错了** —— 这次找到了真凶。

### 🔴 P0（真凶）· 设计文件里的**素材永远加载不到**

用户报的是「画布不显示我做好的内容、显示是空的」。上一版我以为是"点编辑会覆盖内容"，
修了那个（那也是真 bug），但**没修到点上** —— 用户复测："p0问题还没修复、还是不会显示"。

**真凶**（这次有两条硬证据）：

1. **`designBaseDir` 全项目没有任何地方赋值** —— 只有读（`NodeTreeRenderer.resolveAssetPath`）
   和持久化。而设计文件里的素材是**相对路径**（`assets/背景/carbon.png`）；
2. 导入走的是 SAF **单文件**（`OpenDocument` 选一个 `design.json`）—— **拿不到它旁边的 `assets/`**。

于是：相对路径原样传给 `DashboardBackground.load` → 必然读不到 → **所有素材加载失败** →
由**控件（素材图片）**拼出来的表盘只剩空卡片。
纯程序化绘制的表（圆表/数字/条形）不依赖素材，所以这个 bug 一直没暴露。

**修法（两步）：**

- **不再静默**：`NodeTreeRenderer` 加 `BuildReport`（跳过原因 + 素材缺失清单，有界 8 条），
  `DashRenderer` 每次渲染打一行 `设计渲染 | 节点=N 建出=N 跳过(未绑通道)=… 素材缺失=N`，
  失败时补明细；空态文案也从 v1 那句（"请先连接设备并在 PID 页启用通道" —— 对 v2 完全不对路）
  改成**说人话的原因**。
- **真修复**：导入设计后，若它引用相对路径素材，主动问一次
  「选择素材文件夹」→ `DesignAssets.copyTree()` 把整棵目录树复制进 `files/design/<时间戳>/`
  → 设 `designBaseDir` → 重新应用。与 `DashboardBackground.import` 处理背景图**同一套思路**
  （外部路径不保证长期存在）。背景的**相对路径**也一并解析（原来是原样存的，同样读不到）。

> ⚠️ **未在真机上验完**：需要一份**素材还在**的设计包才能验"选完文件夹后真的显示出来"。
> 用户原来那份测试设计的素材（`files/test-assets/*.png`）在 17:56 那次重装时已丢失。

### 其余六件（均已装机验证）

| # | 用户原话 | 根因 / 做法 | 实测 |
|---|---|---|---|
| 1 | 隐藏之后还有一小段底色 | 是 `layout-land` 里导航栏与页面之间那条 `<View width=1dp background=@color/divider>`（1dp=2.25px）。**藏了导航栏却没藏它** | 逐列统计：x=0/1 从 `RGB(42,53,71)` 变成 `8,10,14`（= 画布底色） |
| 2 | 把手不好按、总触发系统手势退出 | 第一版贴在 x=4px（≈2dp），正好在**系统返回手势热区**里。改成距边缘 **32dp**、宽 **18dp**、高 120dp，并换成带 `❯` 的 TextView（原来是个光秃秃的 View，看不出能点） | 把手 `[72,665][112,935]` |
| 3 | 知识库不要从日志进，做成 tab | 新增第 6 个导航项 `nav_knowledge` + `KnowledgeFragment`（`KnowledgeActivity` 删除、清单项移除）；日志页那个入口**撤掉**（一个功能不留两个入口） | 导航栏 6 项都在；知识库页 13 节 |
| 4 | 给知识库加标签、可按标签筛 | 8 个标签 chip（全部/基础/OBD/CAN/ELM327/探测/分析/术语），标签**按节索引映射**（不写进正文） | 点 CAN → `共 13 节 · 标签「CAN」· 当前显示 5 节` |
| 5 | PID 列表四类，加个收缩按钮 | `PidAdapter` 加 `collapsed` 集合 + 标题行可点；标题前加 `▾/▸` | `▾ 标准 OBD (25)` → 点击 → `▸`，下一组顶上 |
| 6 | （顺带）自动收起太快 | 把手展开后 5s → **8s**（5 秒在车上不够看清 6 个 tab） | — |

### ⚠️ 这一版踩到的两个"库的坑"（写下来免得重犯）

1. **`ChipGroup(singleSelection=true)` 会覆盖你给 chip 挂的监听。**
   `onViewAdded` 时它给每个 chip 装自己的 `OnCheckedChangeListener` —— **先挂的被顶掉**。
   症状极具迷惑性：点 CAN 之后 chip 的 `checked` **确实变成了 true**，但我的回调**一次都没进**，
   提示行还停在"共 13 节"。正确做法是用 `ChipGroup.setOnCheckedStateChangeListener`。
2. **`NodeTreeRenderer` 的 `companion object` 里本来就有一个"挂错位置的 KDoc + 收尾括号"** ——
   我按 KDoc 的位置去改 `build`，顺手删了那个括号，结果 `companion` 没关，
   整个类体提前结束（编译报一堆"Unresolved reference"）。已摆正并加注释。

### 验证方式

`tools/run-tests.ps1` **598 全过**、构建守卫通过、`:app:assembleDebug` 通过、
装机实测（小米平板 5 / `7e7d7bb4`）：上表 1~6 逐条用 `uiautomator dump` + 亮像素统计验过；
`logcat -b crash` 空。

### 遗留

- **P0 的"真修复"只差最后一步验证**：需要一份素材还在的设计包（见上）。
- **文档未同步**：`FILE_MAP` / `UI控件清单` / `迭代清单` 还没跟上 v1.20.3（新增
  `DesignAssets.kt`、`KnowledgeFragment.kt`、`fragment_knowledge.xml`、`ic_nav_book.xml`；
  删除 `KnowledgeActivity.kt`、`activity_knowledge.xml`）。
- **网页版主题工具**：见下一节（要不要迭代）。

---

## v1.20.2 · 2026-10-06 · **P0：内置布局的画布会静默销毁你的作品** + 仪表盘沉浸 + 知识库

> 用户一次提了 8 件事。其中一件是 **P0 级 bug**，而且**日志里留下了铁证**。

### 🔴 P0 · 「画布不显示我做好的内容」的真身

用户原话：「当我自定义主题后、内部有控件的情况下、画布不显示我做好的内容、显示是空的」。
设备日志（2026-10-06 23:52）里是这两行：

```
[23:52:03] 渲染画布 | canvas=默认 type=0 theme=0 count=8      ← 画布是「普通驾驶」
[23:52:06] 画布已转为自定义 | canvas=默认 原类型=普通驾驶 gauges=8
```

**三件事叠在一起：**

1. **描述在说谎**：设置页对内置布局的画布写 `11 个仪表` —— 而屏幕上显示的是**内置布局的 8 个**，
   用户自己那 11 块表是**存着但没显示**的。用户因此以为"我的内容不见了"。
2. **点「编辑」会静默销毁它**：旧实现只有「转为自定义并编辑 / 取消」两个按钮，
   确认后 `convertToCustom` 直接 `customGauges.clear()` + 填内置布局 ——
   用户攒的 11 块表就这么没了（`dash.json` 3730 → 2509 字节），只弹一句"已转为自定义布局"。
3. **没有任何提示**：既没说"你还有一份内容"，也没说"它被覆盖了"。

**修法（三处）：**

- 设置页的描述改成说实话：内置布局时写「内置「普通驾驶」布局 · 另存着 11 块自定义表（未显示）」。
- 操作菜单加一条**非破坏性**的出路：「改用我存着的 N 块表」——只把类型翻成自定义，一个字都不动。
- 点「编辑」时，**只要画布里存着表就必须让用户选**：
  「保留我的 N 块表」（默认）/「用内置布局覆盖」/「取消」。

> 这与 v1.17.7 是同一个病：**两份内容 + 说不清哪份是权威 + 静默覆盖**。

### 仪表盘沉浸模式（左侧 tab 自动隐藏 + 那条"白条"）

用户原话：「仪表盘里自动隐藏左边的 tab 栏目（想个好的方法去实现）或者直接以悬浮UI的方式去做
tab 栏目、通过手势去拖出拖入？」「画布下面的白条太厚了、很明显、搞小点、且带点透明的效果那种」

**"白条"到底是什么 —— 实测出来的，不是猜的**（逐行亮像素统计）：

```
截图 2560x1600，而 App 窗口只到 y=1564
y=1564..1599（36px）平均亮度 27，峰值 80.5   ← 系统导航栏
其余各行平均亮度 12（App 本体 #0A0D12）
```

所以那是**系统导航栏**，不是 App 的控件 —— **改不了它的大小**。能做的只有
①在仪表盘页收起它 ②或者透明化。选了 ①（画布多 36px），并保留
`BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE`（从边缘划一下它还会临时出现，不会把人锁住）。

**左侧 tab 栏**：不重新做一套悬浮导航（那就是**两份导航**，本项目因为"两份权威"栽过三次），
而是把现成的 `navView` **平移出去**（`translationX` + `alpha`，**不用 GONE** ——
GONE 会让页面容器重排、画布尺寸变化、表盘跟着重排并闪一下），
左边缘留一条 **6dp 半透明把手**：点一下或往右拖就滑回来，5 秒不操作自动收起。

**实测**：`dashPager` 从 `x=200` 变成 `x=2`（画布**多出 198px**）；
下方那条从亮度 27~80 变成 **11.2**（与 App 背景 12 相同 = 看不见了）。

### 其余六件

| # | 用户要求 | 做法 |
|---|---|---|
| 1 | 画布右下角不要编辑，编辑放到设置页的操作里 | 删掉 `btnEditCanvas`；操作菜单加「编辑这一套…」，点了先翻页再由页面自己进编辑态（宿主用 `pendingEditPos` 保证**在正确的页**上进编辑） |
| 2 | 设置页排版没居中 | **根因**：`MaxWidthNestedScrollView` 的限宽靠父容器认 `layout_gravity` 居中，而 `FragmentStateAdapter.addViewToContainer()` 给页面根视图套的是 `MATCH_PARENT/MATCH_PARENT`，**把 gravity 覆盖掉了**。修法：自己再套一层 FrameLayout 提供居中。实测从「左留白 248 / 右留白 790」变成 **519 / 519** |
| 3 | 新增画布下面加「导入画布 / 导出画布」一行 | 设置页加一行两个按钮，对接 `tools/theme-studio`。**同时从「画布外观」菜单里删掉这两项** —— 同一个动作留两个入口就是"两份权威"的轻量版 |
| 4 | 改名里面的 UI 错乱了 | **根因**：改名对话框**直接给 EditText 自己 `setPadding(20dp)`** 就丢给对话框 —— 文字被推进去 20dp，而下划线还是整宽。抽了 `textInputBody()`（容器给内边距、EditText 不加，并显式定义高度/输入类型），「新增画布」和「改名」共用 |
| 5 | 日志下面做知识库 | 新增 `KnowledgeActivity`（13 节：三条数据链路 / PID / CAN / AT 命令 / 怎么探测 PID / 怎么分析 CAN / 采样率 / 聚合三列怎么读 / 对比基准 / 为什么"没有值" / 公式语言 / 监听型 PID / 术语速查）。带关键词筛选。日志页底部一个入口 |
| 6 | （顺带）DBC / 宝马参数表那两件事落成文档 | 新增 [`15-CAN-信号库与逆向框架.md`](15-CAN-信号库与逆向框架.md)：MINI DBC 分析 + 宝马 E9x/E8x 拍平 CSV 格式体检（218 行，查出 6 行 `min>max`、48 行 `最大≠2^长度−1`、判越界不能用线性判据）+ 两种格式怎么选 + **探测导出↔信号表闭环**。另新增 [`20-下一步-CAN信号库实现规格.md`](20-下一步-CAN信号库实现规格.md)：**待定项已全定**，要动手直接照做 |

### 验证方式

| 项 | 结果 |
|---|---|
| `tools/run-tests.ps1` | **598 个用例全通过** |
| 构建守卫 | 通过 |
| `:app:assembleDebug` | 通过（`dist/iCarOBD-debug-v1.20.2-android.apk`） |
| **装机实测**（小米平板 5 / `7e7d7bb4`） | 逐条见下 |

装机实测到的现象（全部用 `uiautomator dump` + 亮像素统计量的）：

- `btnEditCanvas` **不在层级里**；操作菜单里有「编辑这一套…」与「改用我存着的 8 块表」
- P0 对话框三个选项都在：`保留我的 8 块表` / `用内置布局覆盖` / `取消`；点"保留"后进编辑态且表数不变
- 设置页居中：内容 `x=521..2041`，页面 `2..2560` → **左右留白各 519px**
- 沉浸：`navView` 不在层级里、`dashPager` 从 `x=200` → `x=2`、下方 36px 亮度 27~80 → **11.2**
- 把手 `[4,692][17,908]`（6dp × 96dp）；**点一下 tab 栏滑回来**（`navView [0,0][198,1564]`）
- 知识库：日志页底部入口 → 打开显示「共 13 节」+ 筛选框 + 各节标题
- `logcat -b crash` 为空

### 遗留

- **沉浸模式下系统导航栏仍占 36px**（只是变暗到看不见）。要真正吃掉这 36px 得改成
  edge-to-edge（`setDecorFitsSystemWindows(false)` + 各页处理 insets），影响面大，没做。
- 用户那套被覆盖的 **11 块表**还在 `stage/tablet-backup-20261006-2310/config/dash.json` 里，
  **没有自动恢复**（用户之后又改了配置，盲目恢复会覆盖新状态）。要恢复得先问。
- 知识库内容会随项目演进过期（比如"扫描器默认 150ms"改了）—— 它没有测试守着，
  属于**文档性质的代码**，改参数时记得顺手看一眼。

---

## v1.20.1 · 2026-10-06 · 画布名浮标的**位置可选**（四角 / 隐藏）

> 用户对上一条那三个判断的回复：
> ①「编辑态禁用横滑」②「一套画布 = 一屏」→ **都按原样保留**（本版没动）；
> ③ 画布名浮标问「可以自定义位置、或预设四个角？」→ 本版按**四角 + 隐藏**做。

### 新增

- `Settings.canvasNamePos`（**全局**偏好，取值 `DashCanvas.NAME_POS_*`）：
  左上 / 右上 / 左下 / 右下 / **隐藏**。
  入口：仪表盘最右页「设置」→ 全局 → 「画布名浮标」。
- 右下角会自动**让开「编辑」按钮**（多 44dp 下内边距）—— 不加这一下，两个字会叠在一起。

### 为什么是四角预设，不是自由拖拽

1. 车上这块屏**只会设一次**，四个角足够覆盖所有实际诉求；
2. 自由拖拽要和「横滑翻页」抢同一个横向手势 —— **为了挪两个字把翻页搞坏不划算**；
3. 自由坐标会落到「编辑」按钮底下或贴边，又得再加一套避让规则。

真需要任意位置时，正确做法是"**长按浮标进入移动态**"（那时不翻页），
而不是让它在正常浏览时就能拖。这条同时写进了 `DashCanvas.NAME_POS_*` 的注释与迭代清单 P11 ——
免得下一个人把它当成"没做完"再重做一遍。

### 装机验证时抓到的三个真问题（都已修）

**这三个都是"不装机就看不出来"的类型** —— 单测全绿、编译通过，但实际用起来是错的/查不动的。

#### 1. `relayout()` 在**首次渲染之前**就拿空规格渲染了一次

日志里出现：
```
[UI][W] 仪表盘无可渲染的表：PID 全部查不到 | spec=0 ids=
```

根因：`DashRenderer.lastSpec` 的初值是**空列表**，而容器的
`addOnLayoutChangeListener` 在**第一次布局**（`0,0,0,0 → 0,0,W,H`）就会触发 `relayout()` →
`render(lastSpec = 空)`。于是"还没有任何规格"被当成"规格是空的"，
打出一条**误导性的**警告，并把空态提示闪一下。

为什么多画布之后必须挡：**每一页都有自己的渲染器，而非当前页故意不渲染** ——
那些页面被布局时 100% 走到这里，日志里会堆一排查不出所以然的"PID 全部查不到"。
修法：加 `hasRendered` 标记，`relayout()` 在收到第一次规格之前直接返回。

#### 2. 转换日志**自己骗自己**：`原类型=自定义仪表`

`convertToCustom()` 里先 `Store.settings.dashType = CUSTOM` + `saveDash()`，
而 `saveDash()` 会经 `snapshotToActiveCanvas()` **把 `c.type` 就地同步成 CUSTOM** ——
之后才读 `c.type` 打日志，于是原本是「普通驾驶」也被写成「自定义仪表」，
日志里完全看不出它原来是什么。修法：改之前先把 `fromType` 抓下来。

#### 3. `setMessage` + 列表 = **列表被整个丢掉**（最严重的一个）

三个对话框（画布名浮标 / 轮询间隔 / 套用预设）都是"说明文字 + 选项列表"，
在设备上**只剩标题 + 说明 + 取消，一个选项都没有** —— 功能等于不可用。

实测判据（`uiautomator dump` 里 `android:id/text1` 的节点数）：

| 对话框 | message | 列表 | text1 节点 |
|---|---|---|---|
| 行操作菜单 | 无 | `setItems` | **4** ✅ |
| 画布名浮标位置 | 有 | `setSingleChoiceItems` | **0** ❌ |
| 轮询间隔 | 有 | `setSingleChoiceItems` | **0** ❌ |

即 `MaterialAlertDialogBuilder` 同时收到 message 与列表时会丢掉列表。
（全项目只有我这三处用了这个组合；老代码的列表对话框都用 `AlertDialog.Builder` 且不带 message，
所以这个坑以前没暴露过。）

修法：说明**进标题或进选项文字**，列表对话框一律不带 `setMessage`；
轮询间隔那个说明较长，改成**自定义 View（说明文字 + Spinner）** ——
与 `showGridDialog` 走同一条已验证的路子。

### 实现上的两个小决定

- **位置是全局的、不跟着画布走**：跟着走的话横滑时小字会在四个角之间乱跳。
  有 `浮标位置是全局的_切画布不变` 一条用例钉着。
- 用 `layout_gravity` + **padding** 而不是 margin：padding 在四个角上都等价于"离边多远"，
  一套值就够；margin 得为每个角各算一遍 start/end 组合。

### 验证方式

| 项 | 结果 |
|---|---|
| `tools/run-tests.ps1` | **598 个用例全通过**（`DashCanvasTest` 16 → 21：名字表契约 / 越界回落 / 设置往返 / 读取时夹取 / 全局性） |
| 构建守卫 | 通过（唯一警告是主题工具的 14 个存量 PID，与本版无关） |
| `:app:assembleDebug` | 通过，6.84 MB / 单 ABI arm64-v8a（`dist/iCarOBD-debug-v1.20.1-android.apk`） |
| **装机实测** | ✅ **已装**（小米平板 5 / `7e7d7bb4`，`adb install -r` 数据保留：`firstInstallTime` 未变）—— 下面是逐条现象 |

装机实测到的现象（都是 `uiautomator dump` 量出来的，不是"看着像"）：

| 判据 | 实测 |
|---|---|
| 升级不改画面 | `配置已迁移到多画布 \| 第 1 套「默认」type=0 gauges=11 design=无 theme=0`；设置页 `普通驾驶 · 11 个仪表 · 主题 霓虹赛道` —— 与升级前（`dashType=0` + `dash.json` 11 块表）逐项一致 |
| 顶栏那行没了 | 层级里只有 `dashPager`（`[200,0][2560,1564]`），`dashToggle`/`btnDashNormal`/`btnDashPreset`/`btnDashTheme` **一个都不在** |
| 冷启动停在上次那一套 | `仪表盘宿主已就绪 \| 画布=2 当前=画布 2 起点页=1` |
| 新增画布 | 设置页**仍在最右**、`当前：画布 2`（自动切过去）、新那套 8 块表；日志 `已新增画布 \| type=0 index=1/2` |
| 内置布局点「编辑」 | 弹「「画布 2」是内置布局 / 转为自定义并编辑」，文案与实际一致 |
| **编辑态禁用横滑** | 进编辑态后滑一下：`btnDone` 仍在、设置页 `llCanvasList` **没出现** —— 翻不动 |
| 编辑工具条 | 8 个按钮 + 提示行 `已选：车速 · 圆形指针表 · 50% × 40% · 坐标吸附到 1/24 网格（每格 15 单位）` |
| 删画布 | 剩 1 套、`当前：默认`，**原画布 11 块表未动** |
| 浮标四角 | 右下角时文字底边距「编辑」按钮顶 **6dp**（与其它三个角边距一致）；框与按钮重叠但按钮在上层，点得到 |
| 三个对话框 | 画布名浮标 5 个选项 / 轮询间隔（说明+Spinner）/ 画布外观 8 项 —— **都渲染出来了** |
| 无崩溃 | `logcat -b crash` 空、`files/last-crash.log` 不存在、应用日志里 crash/ANR 关键字 **0** 条 |
| `spec=0` 误报 | **0 条**（修复前每次布局都刷一条） |

### 遗留

- 装机时补两条判据：**音效开关当次生效**、**每套画布的主题/背景互不影响**（这两条这次没点到）。
- 真需要任意位置 → 按"长按浮标进入移动态"做，**不要**做成正常浏览时可拖拽。
- ⚠️ **教训（给下次做装机验证的人）**：点对话框按钮**必须先 `uiautomator dump` 拿坐标再点**，
  不要凭记忆复用上一个对话框的坐标 —— 不同对话框的按钮宽度不同（「转为自定义并编辑」
  比「取消」宽），这次就因此误点了确认、把用户原来的画布转成了自定义
  （已用升级前的备份完整恢复，见 `stage/tablet-backup-20261006-2310/`）。

---

## v1.20.0 · 2026-10-06 · **多套画布（方案 A）**：仪表盘改成整页横滑 `[画布0][画布1]…[设置]`

> 用户给的落地清单（6 项）+ 三条已经定好的决定：
> ① 横滑只滑画布（顶栏已删，所以现在是**整页滑**）；
> ② **编辑态禁用横滑**（拖拽表盘和横滑会打架）；
> ③ **设置页是最后一页**（滑到最右）。
> 另外确认了「画布数量自定义」= **能加/删画布**（有几套自己定），不是"填一个数字"。

### 新增

| 文件 | 干什么 |
|---|---|
| `data/DashCanvas.kt` | 一套画布：`id / name / type / gauges / designJson` **+ 主题 / 背景 / 页号** |
| `ui/dash/DashCanvasPagerAdapter.kt` | `[画布0][画布1]…[设置]`；**稳定 id 由画布 id 派生** |
| `ui/dash/DashCanvasPageFragment.kt` | 每套画布一页：渲染 + **就地编辑**（取代 `DashEditorActivity`） |
| `ui/dash/CanvasSettingsFragment.kt` | 最后一页：画布增/删/改名/排序 + 当前画布外观 + 轮询间隔 + 音效 |
| `res/layout/fragment_dash_canvas.xml`、`fragment_canvas_settings.xml`、`item_canvas.xml` | 上面两个 Fragment 的布局 |
| `test/.../DashCanvasTest.kt` | **16 条**：JSON 往返 / 旧配置迁移 / 增删切排序 / 备份往返 |

### 调整（会改变行为，逐条）

- **顶栏那一整行删掉**（`dashToggle` / `btnDashPreset` / `btnDashTheme`），换成 ViewPager2。
  v1.19.25 删掉 App 状态条之后，它是整页里**唯一的横条**，占的正是最贵的一行高度。
  原「布局（预设）/ 风格（主题·背景·设计文件·参考线）」的全部能力搬进最后一页「设置」——
  **没有丢任何入口**，尤其设计文件的导入/导出（那是"电脑上设计 → 设备上生效"闭环的唯一入口）。
- **「编辑」从开 Activity 改成就地编辑**。`ui/DashEditorActivity.kt` 与
  `res/layout/activity_dash_editor.xml` **删除**，`AndroidManifest.xml` 里的声明也去掉。
  为什么非改不可：旧版编辑在另一个 Activity 里，**"拖表盘 vs 横滑"这个冲突根本不会发生**，
  也就永远不会被处理；而一旦编辑进了 pager，它就必须被处理（这就是决定②）。
- **一套画布 = 一屏**：主题 / 背景图 / 多页面设计看到第几页**都跟着画布走**。
  留在全局的话，切过去会看到"性能页顶着日常页的暖色底图"这种半套效果 ——
  比没有多画布更费解。（轮询间隔 / 音效与画面无关，仍留在全局。）
- **新增画布自动切过去**：不切的话用户会以为"新增"没生效。
- **至少留一套画布**：删空之后横滑没有页、`customGauges` 没有归属，整页空白。
  上限 **8 套**（`DashCanvas.MAX_CANVASES`）—— 不是技术限制，是"滑很久才找到盘面"的可用性限制。
- **内置布局的画布（普通 / 性能）不能直接拖**（与旧版一致：旧版也只有「自定义」页签显示「编辑」）。
  区别是现在给**明确的转换入口**：点「编辑」会问一句「转为自定义并编辑」。
- 画布页多了一个**小字浮标**显示画布名。没有页码指示时"现在滑到第几套"完全无从判断 ——
  它是 overlay（不占布局高度）。**位置在 v1.20.1 做成可选**（四角 / 隐藏），
  所以"觉得多余"现在不用改代码，去设置页选「隐藏」即可。

### 三个必须记下来的坑（都在这版里踩到并修掉）

1. **`load()` 的顺序反了会重置用户设置**（最危险的一个）。
   `dash.json` 的网格迁移里会调 `saveDash()`，而 `saveDash()` 现在要把画布写进
   `settings.json` —— 旧的读取顺序（先 dash.json 后 settings.json）会拿**还没加载的默认
   settings** 覆写 `settings.json`，用户的轮询间隔、主题、画布全被冲成出厂值，
   **日志里一条都不提**。现在 `load()` 先读 settings 再读 dash，并有注释钉着。
2. **`ViewPager2` 分不清"用户滑的"和"我们调的"**。新增一套画布会把设置页从第 N 页挤到
   第 N+1 页，我们必须自己把 pager 挪过去；挪的过程中 `onPageSelected` 会报出中间页码
   （正好是一套画布）—— 照它切的话，用户只是加了套画布，当前画布却被换成了别人。
   现在凡是程序化翻页都先记 `awaitingPos`，期间一律不切画布（`DashFragment`）。
3. **XML 注释里不能出现 `--`**：`aapt2` 直接报
   `注释中不允许出现字符串 "--"`。我在注释里画了个 Markdown 表格（`|---|---|`），
   资源合并整个失败。改成项目符号列表。

### 设计取舍：`Settings` 里那几个字段现在的身份是"当前画布的实时副本"

`settings.dashType / gaugeTheme / designJson / bgImagePath / dashPageIndex` **保留**，
但由 `Store.snapshotToActiveCanvas()` / `loadActiveCanvas()` 在落盘与切画布时双向同步。

为什么不用"给每个调用点换成转发属性"：那会让**漏改一处就静默读到过期值**成为可能
（渲染、编辑器、主题编辑器加起来 100 多处）；副本方案里漏改只是"少存一次"，
下一次 `saveSettings()` 就补上了。`Store.activeCanvas()` 永不返回 null（空列表/悬空 id 自愈）。

### 迁移

首次读到没有 `canvases` 的 `settings.json` 时，把现有的
`dashType + customGauges + designJson + 主题 + 背景 + 页号` 包成**第一套画布**，名叫「默认」。
只**打包**、不改任何取值 —— 迁移完用户看到的东西必须和升级前一模一样。
`dash.json` 继续写（**旧格式镜像**），降级回 v1.19.x 时那份文件仍然读得到扁平表。

### 验证方式

| 项 | 结果 |
|---|---|
| `tools/run-tests.ps1` | **593 个用例全通过**（新增 16 条 `DashCanvasTest` + 1 条 `DashSpecTest`），0 失败 |
| 构建守卫 | **通过**（2 条警告：dist 里的旧 APK 名、主题工具的 14 个存量 PID —— 都与本版无关） |
| `:app:assembleDebug` | **通过**，APK 7.17 MB（`dist/iCarOBD-debug-v1.20.0-android.apk`） |
| 装机实测 | ❌ **未做** —— 本轮没有设备。发版清单第 3~7 条（装机、crash、ANR、横竖屏、日志体积）**待补** |

### 遗留问题

- **未装机验证**：横滑手势、就地编辑的拖拽手感、编辑态禁用横滑是否彻底，都必须上设备确认。
  最该试的三条：① 编辑时能不能滑走（不该能）；② 加/删画布后设置页还在不在最右；
  ③ 从旧版升级后盘面是否与升级前一致。
- 主题工具的跨语言一致性检查（发版清单第 14 条）**不需要动**：
  这版只加了新类 `DashCanvas`，没有改 `GaugeItem` / `DesignFile` 的字段。
- `dashEngine` 的 LVGL 分支仍然留着（每页一个 `LvglDashView`，`GONE` 时不建 Surface）——
  与旧版一样是"留个对比入口"，`applySettingsJson` 里强制归 0。

---

## v1.19.20 · 2026-10-06 · 仪表盘顶栏：修掉「普通/性能/自定义」那一行的**空间分配荒谬**

> 用户原话："普通/性能/自定义这一行**十分的不美观**"。
> 这次不是凭感觉改的 —— 先用 `uiautomator` 把**真实几何**量出来，问题非常具体。

### 量出来的事实（改前）

| 控件 | 宽度 | 问题 |
|---|---|---|
| 「普通」 | **709px** | 占整行 30%，而内容只有 2 个字 |
| 「性能」 | 709px | 同上 |
| 「自定义」 | 710px | 同上 |
| 分段控件整组 | **2124px** | 吃掉整行 |
| 「布局」 | **91px** | 2 个字挤在 91px 里，左右各只剩 12px |
| 「风格」 | 91px | 同上 |

### 根因

```xml
<MaterialButtonToggleGroup
    android:layout_width="0dp"
    android:layout_weight="1"      ← 吃掉全部剩余宽度
    ...>
    <MaterialButton layout_width="0dp" layout_weight="1" />   ← 组内再平分
```

**分段控件（segmented control）本来就该"贴着自己的内容"** ——
给它 `weight=1` 之后，每段 708px 去放两个字，**整段全是空白**，
"分段"的视觉语义完全没了；同时把右边三个真正的操作按钮挤成 91px。

### 改法

1. `dashToggle` 去掉 `weight=1`，改 `wrap_content`（贴内容）
2. 三个分段 `wrap_content` + `minWidth=64dp` + 左右 14dp padding
3. **加一个弹性空白 `View`（weight=1）** 把右侧操作推到行尾 ——
   要占位就用空白，**不要让控件自己撑成空白**
4. 三个操作按钮 padding 8dp → 12dp（不再挤）

### 验证（真机实测几何，判据是数字不是感觉）

| 控件 | 改前 | 改后 |
|---|---|---|
| 「普通」 | 709px | **144px** |
| 「性能」 | 709px | **144px** |
| 「自定义」 | 710px | **146px** |
| 分段控件整组 | 2124px | **430px** |
| 「布局」/「风格」 | 91px | **109px** |

分段控件缩到 **1/5**，操作按钮右对齐且不再挤。

> **这轮的方法值得记**：把"不美观"翻译成**可量的几何**（宽度/占比/间距），
> 才能定位到根因、也才能证明改好了。只凭感觉改，改完还是不知道好没好。

### ⚠️ 顺带发现一个**待确认**的问题：仪表区是纯色空白

三张截图（含**改布局之前**那张）的仪表区采样结果都是
**平均亮度和 = 最亮和 = 32** —— 即**整片同一个颜色，一个亮点都没有**；
而 `docs/screenshots/11-land-dash-perf.png`（已知正常）同区域是
**平均 122 / 最亮 765**。日志却写着 `渲染仪表盘 | type=1 theme=0 count=8`。

**已排除是我这次改动引起的**（改动前那张也是空白）。
**未定性**：可能是真没画出来，也可能是当前这台设备的某个状态。
**待用户用眼睛确认**（我看不到屏幕，`vision_*` 工具在本会话不可用）。

---
## v1.19.19 · 2026-10-06 · 退出模拟回到设置页 + 仪表盘全屏显示

### 1. 退出模拟 → **回到刚才那个规则设置页**

之前点「退出模拟」只是把人留在仪表盘上。但那时他多半**还想接着改那条规则**
（模拟本来就是"边看效果边调"）。现在退出会直接打开那条规则的编辑器。

实现上就是退出**前**先取 `simulatingRuleId()`，退出后再 `startActivity(RuleEditorActivity, EXTRA_ID=id)` ——
顺序不能反（退出之后 id 就清掉了）。

### 2. 全屏显示：**长按「仪表盘」导航按钮**进入/退出

**为什么用长按而不是加个按钮**：顶栏/导航栏是常驻的，为了"全屏"再加一个图标
会让本来就不宽裕的一行更挤；而长按是**零成本**的（不占位置，也不影响单击切页）。

**三样都要隐藏，少一样都不算全屏**：

1. 系统状态栏 / 导航栏（`WindowInsetsController.hide(systemBars())`）
2. App 自己的顶部状态条（`statusBar`）
3. App 的底部/侧边导航（`navView`）

另外两个细节：
- **进入时顺带切到仪表盘** —— 长按的是「仪表盘」按钮，若人当时在 PID 页，
  全屏后看到的却是 PID 页，会很困惑
- **返回键在全屏时先退出全屏**，而不是直接退出 App（用 `OnBackPressedCallback`）
- 允许**边缘滑出**临时系统栏（`BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE`）——
  否则用户在全屏里可能找不到怎么退出

### 验证

| 项 | 结果 |
|---|---|
| Kotlin 单测 | ✅ **576 全过** |
| 浏览器套件 / 守卫 | ✅ 848 断言 · 守卫通过 |
| APK | `dist/iCarOBD-debug-v1.19.19-android.apk`（versionCode 62） |
| 装机 | ✅ 已装到平板，`MainActivity` 在前台、**崩溃缓冲为空** |
| ⏳ **未验** | **长按是否真的进全屏** —— 我用 `input swipe 同点+1000ms` 模拟长按**没触发**（adb 模拟长按本来就不可靠）。**需要人真手指长按一下**；判据是日志出现 `进入全屏` |

> ⚠️ 这条我如实标成未验：代码路径（隐藏三处栏 + 返回键拦截）都是标准写法，
> 但**"长按真的挂上了没有"只能靠真按一次**。

---
## v1.19.18 · 2026-10-06 · 规则动作：音效可选**自定义音频文件** + 仪表变色可**自动恢复**

> 用户提了四块需求，这是**第一块**（最独立、可测的那块）。
> 另外三块（规则模拟测试 / 仪表盘全屏 / 顶栏重做）见文末「下一步」。

### 1. 播放音效：可以指定音频文件

以前 `sound` 动作的 `p1` 只能是内置音效名（`tick_left` / `tick_right` / `warn` / `beep`）。
现在**也可以是一个音频文件**：

- 动作行上多了个 **📁** 按钮（只在「播放音效」时出现，与 ♪ 一样按类型显隐）
- 点它走 SAF（`OpenDocument` + `audio/*`）选文件
- 选完按钮文案**变成文件名**，`p1` 存 `content://` URI

**三个实现上的要点**（都是"不做就会静默坏掉"的）：

| # | 要点 | 不做的后果 |
|---|---|---|
| 1 | **`takePersistableUriPermission`** | 重启 App 后 URI 没读权限 → 规则触发时**静默不响** |
| 2 | 判据 `RuleAction.isAudioFileSpec()` **只有一份** | 编辑器当成文件、播放器当成名字 → **现象上完全看不出** |
| 3 | 文件加载失败**不回退 beep** | 用户会以为"选的文件就是这声"，而真正的原因被顶替掉了 |

判据是**纯函数**且有用例钉着（`内置音效名不算音频文件` / `用户选的音频文件算音频文件`）。

### 2. 仪表变色：N 秒后自动恢复

`gauge` 动作的 `p3` 以前是"(不用)"，现在 = **N 秒后自动恢复**（空 = 一直保持）。

**为什么需要**：变色规则最常用的写法是"超温变红"，而"恢复正常后变回来"得**另配一条规则**去 reset ——
很容易忘了配，于是**仪表永远红着**，看起来像 App 坏了。

> 用 `p3` 而不是新加 `p4`：动作行只有三个输入框，**加了字段用户也填不了**。

### 3. `RuleAction` 加了 `p4`（第 4 个自由参数）

给"选了音频文件时的**显示名**"用 —— `p1` 存 URI 是给机器看的，
把 `content://media/.../1234` 甩在规则描述里没人看得懂。

有默认值 + `toJson` 里**空值不写出**，所以**存量 JSON 不需要迁移**。

### 4. 规则**模拟测试**（本次的重点）

规则编辑器底部新增 **「▶ 模拟测试（回仪表盘看效果）」**。点它：
保存规则 → 起模拟 → **自动回仪表盘** → 右下角出现悬浮条。

**模拟的语义：只改"条件判定"，别的一律不动。**

被模拟的规则条件**直接判成立**，而 `durationMs` / `cooldownMs` **照常生效**。
这不是偷懒 —— 那正是要看的东西：实车日志里那条"左转向灯音效"
**每 1.25 秒触发一次**（正是它的冷却），也就是**你能听到"咔嗒、咔嗒"的真实节奏**。
把时序也绕过去，等于把要验的东西验掉了。

**⚠️ 最容易做错的一处：模拟必须自带节拍。**

`RuleEngine.evaluate()` 平时是由**轮询周期**（`engine.onCycle`）驱动的，
而"没车时试一条规则"正是这个功能的主要用法 —— 那时**轮询根本没跑**。
只设一个 `simulateRuleId` 会**什么都不会发生**，而日志里也看不出问题。
所以 `ObdController` 在起模拟时**另起一个 200ms 的节拍**（实测日志里那行
`模拟节拍已启动 | 间隔=200ms（轮询可能没在跑）` 就是它）。

| 位置 | 内容 |
|---|---|
| `RuleEngine` | `simulateRuleId` / `simulationOn` / `startSimulation` / `setSimulationOn` / `stopSimulation`；`evaluate()` 里对模拟规则直接判成立 |
| `RuleEngine.reload()` | 被模拟的规则**即使 disabled 也纳入评估** —— "测试一条还没启用的规则"正是常见用法 |
| `ObdController` | 200ms 模拟节拍 + `pendingGotoDash` 旗标 |
| `MainActivity` | 悬浮条（**代码建，加在 `android.R.id.content`**，不动 `activity_main.xml`）；`onResume` 消费旗标并切到仪表盘 |
| `RuleEditorActivity` | 入口按钮；`save()` 拆出 `saveRule()`（**不 finish**）供模拟复用 |

**悬浮条挂在 `MainActivity` 而不是 `DashFragment`** —— 用户的原话是
"开启后可以**返回仪表盘**查看效果"，说明模拟要**跨页面存活**；挂在 Fragment 上一切页就没了。

三个动作：**开启查看** / **关闭查看**（临时退回正常判定做对比，会顺手清掉染色）/
**退出模拟**（清干净并停掉节拍）。

#### 实机验证（2026-10-06 · 小米平板 5）

```
[19:10:11.912] 开始规则模拟 | name=左转向灯音效
[19:10:11.913] 模拟节拍已启动 | 间隔=200ms（轮询可能没在跑）
[19:10:11.952] 切换页面 | dash                       ← 自动回仪表盘
[19:10:12.127] 规则触发 | name=左转向灯音效 actions=1
[19:10:13.377] 规则触发 | …（每 ~1.25 秒一次 = 冷却节奏）✓
[19:10:29.050] 退出规则模拟 | id=67c4b0cb-…
```

| 判据 | 结果 |
|---|---|
| 编辑器里 `📁` 与 `▶ 模拟测试` 都渲染出来 | ✅ dump 到两个控件 |
| 点模拟 → 自动回仪表盘 | ✅ `切换页面 \| dash` |
| 悬浮条出现 | ✅ `tvSimRule «模拟中 · 左转向灯音效»` + 开启/关闭/退出 |
| **规则真的按冷却节奏触发** | ✅ 每 ~1.25 秒一次 |
| 点退出 → 悬浮条消失 | ✅ 且日志有 `退出规则模拟` |

### 验证

| 项 | 结果 |
|---|---|
| Kotlin 单测 | ✅ **576 全过**（+6：判据 2 条、描述 2 条、JSON 往返 1 条、gauge p3 1 条） |
| 浏览器套件 | ✅ 848 断言全过 |
| 构建守卫 | ✅ 通过（1 条警告 = 已知的 14 个控件） |
| APK | `dist/iCarOBD-debug-v1.19.18-android.apk`（versionCode 61） |
| 装机 + 实机 | ✅ 已装到平板；模拟测试**三个按钮全部实机验证通过** |
| ⏳ 未验 | **选一个音频文件 → 规则触发能响**（需要人点一下系统文件选择器） |

### 下一步（本次未做）

| 块 | 内容 |
|---|---|
| **仪表盘全屏** | 长按仪表盘按钮进入全屏 |
| **顶栏重做** | 「普通/性能/自定义」那一行不美观 → 连同整个仪表盘 UI 一起优化 |

> 这两块都需要**看着屏幕迭代**（我这边只能靠像素网格间接判断），
> 建议在你方便看屏幕时做。

---
## v1.19.17 · 2026-10-06 · P10-1：「这台车不支持」的 PID 自动退出轮询

> 迭代清单 **P10 第 1 条**。症状：那 5 条 `std_0A` / `std_14` / `std_22` / `std_5C` / `std_5E`
> 每分钟都在打 `PID 连续失败进入冷却`，而 `轮询汇总 | 有值 20/25` 永远差 5 个。

### 判据的关键：**只有「ECU 明确说没有」才算**

优化目标是"连续失败 N 次就退出轮询"。**如果什么失败都算**，
一次链路抖动（超时 / 写入被拒）就能把**全部** PID 判成不支持 ——
**车没坏，App 先自己瞎了。**

所以新加的 `ObdProtocol.isUnsupportedEvidence(raw)` **只看原始响应**：

| 响应 | 算不算 | 为什么 |
|---|---|---|
| `NO DATA` | ✅ | ECU 收到了请求、**明确说**没有这个 PID |
| NRC `0x11/0x12/0x31/0x7E/0x7F` | ✅ | ECU **明确拒绝**（服务/子功能不支持、超出范围） |
| **空串（超时）** | ❌ | **我们没问到** —— 不是车说没有 |
| `CAN ERROR` / `BUS ERROR` / `UNABLE TO CONNECT` | ❌ | 总线/连接问题，与 PID 无关 |
| `STOPPED` / `ERROR` | ❌ | 适配器状态问题 |
| NRC `0x13`（报文长度错） | ❌ | **我们自己发了畸形帧**，是 App 的错 |

> ⚠️ 容易踩的点：`ElmSession.request` **超时返回空串**，而 `NO DATA` 是**有内容**的响应 ——
> 两者在 `parse` 里**都会塌缩成「无有效响应」**。所以**只能看原始响应，不能看错误串**。

### 改了什么

| 位置 | 内容 |
|---|---|
| `ObdProtocol.isUnsupportedEvidence()` | 纯函数判据（新增，可测） |
| `ObdProtocol.negativeCode()` | 取出 NRC **码** —— 按码判断，**不按中文名**（名字一改判断就静默失效） |
| `ObdEngine` | `unsupportedStreak` 计数；连续 **3** 次明确回绝 → 加入 `unsupportedPids`、**退出轮询**、记一行 W |
| `ObdEngine` 轮询 `due` 过滤 | 判定不支持的**直接不问**（不再白占总线、不再刷冷却行） |
| `ObdEngine` 汇总 | 分母**只算还在轮询的** → `有值 20/20`；尾注「另有 N 条本车不支持」 |
| `ObdEngine.reEnable()` / `ObdController.reEnablePid()` | **手动重启用** |
| `PidAdapter` | 判定不支持的行**标灰**（alpha 0.45）+ 备注「本车不支持，已退出轮询 —— **长按重新启用**」 |

**为什么判据要"连续"**：成功一次就清零 `unsupportedStreak` ——
长期累积会把"偶发几次 NO DATA 但一直有值"的 PID 误判掉。

**为什么必须留手动出口**：判定依据是 ECU 回绝，但车况会变（换适配器 / 换车 / 上次总线正忙）。
**判定错一次就不让用户改，等于把 App 写死。** 判定是**内存态**，重启 App 自然重测。

### 验证

| 项 | 结果 |
|---|---|
| Kotlin 单测 | ✅ **570 全过**（+7：6 条判据 + 1 条阈值区间） |
| 浏览器套件 | ✅ 848 断言全过 |
| 构建守卫 | ✅ 通过（1 条警告 = 已知的 14 个控件） |
| APK | `dist/iCarOBD-debug-v1.19.17-android.apk`（versionCode 60） |
| 装机 | ✅ 已装到平板（见下面"装机踩到的坑"） |
| 启动验证 | ✅ 无崩溃；`规则已加载 count=5` / `开机自动连接` / **`渲染仪表盘 type=2 count=11`** —— **回填的配置全部生效** |
| **车上判据** | ⏳ **待上车** —— `有值 20/25 → 20/20`、日志不再出现那 5 条冷却行。**这两条必须车边上验** |

### ⚠️ 装机踩到的坑：**debug 签名每台机器不一样**

```
INSTALL_FAILED_UPDATE_INCOMPATIBLE: Existing package com.icar.obd signatures do not match
```

平板上装的是**笔记本**构建的 v1.19.15，而本机构建的 APK 用的是**本机的**
`~/.android/debug.keystore` —— **debug 签名是每台机器一份，无法原地覆盖**。
项目没有自定义签名配置，所以这是必然。

**处置（无损，已做完）**：备份 App 数据 → 卸载 → 装新版 → 回填。

```powershell
# ① 备份（cmd 重定向是字节安全的；PowerShell 5.1 的 Out-File 没有 -Encoding Byte）
foreach ($f in 'settings.json','dash.json','rules.json') {
  cmd /c "`"$ADB`" -s 7e7d7bb4 exec-out run-as com.icar.obd cat files/config/$f > `"$dest\$f`""
}
# ② 卸载 + 装
& $ADB -s 7e7d7bb4 uninstall com.icar.obd
& $ADB -s 7e7d7bb4 install -r -d dist\iCarOBD-debug-v1.19.17-android.apk
# ③ 先启动一次（否则 files/config 还没建出来）
& $ADB -s 7e7d7bb4 shell am start -n com.icar.obd/.ui.MainActivity   # 等 8 秒
& $ADB -s 7e7d7bb4 shell am force-stop com.icar.obd
# ④ 回填：**用 base64 写进 App 自己的目录**
#    ⚠️ 别用「push 到 /sdcard 再 run-as cp」—— /sdcard 上是 root:everybody，
#    App 的 uid 读不到，报 Permission denied（实测踩了）
foreach ($f in 'settings.json','dash.json','rules.json') {
  $b64 = [Convert]::ToBase64String([IO.File]::ReadAllBytes("$dest\$f"))
  & $ADB -s 7e7d7bb4 shell "run-as com.icar.obd sh -c 'echo $b64 | base64 -d > files/config/$f'"
}
# ⑤ 重装后权限会被清空，必须补授权（否则卡在系统权限对话框上）
& $ADB -s 7e7d7bb4 shell pm grant com.icar.obd android.permission.BLUETOOTH_SCAN
& $ADB -s 7e7d7bb4 shell pm grant com.icar.obd android.permission.BLUETOOTH_CONNECT
& $ADB -s 7e7d7bb4 shell pm grant com.icar.obd android.permission.POST_NOTIFICATIONS
```

**回填判据**：三个文件字节数必须与备份**完全一致**（702 / 3527 / 2768），
且启动日志出现 `渲染仪表盘 | type=2 count=11`（那 11 个表就是用户自己的仪表盘）。

> ⚠️ 别把 `ACCESS_FINE_LOCATION` 授权失败当成问题 —— 清单里它带 `maxSdkVersion`，
> SDK 33 上**本来就不申请**（报 `has not requested permission` 是**对的**）。

### 遗留

- ⏳ **车上判据未验**（`20/20` + 无冷却行）—— 需要车
- **判定是内存态**：重启 App 会重新测那 5 条（约 15 次请求 + 若干行日志）。
  如果嫌重启后又要等一轮，可以改成持久化 —— 但那样"换了车"就发现不了，**暂不做**

---
## v1.19.16 · 2026-10-06 · 入口归位 + 去掉过时模板按钮 + 音效可试听

### 1. 「CAN 探测」入口挪到「PID」页，紧挨「PID 扫描器」

两个工具本来就是**同一件事的两条路**，放在两个页面里没有道理：

| 工具 | 怎么拿数据 | 能发现什么 |
|---|---|---|
| **PID 扫描器** | **主动问**（Mode + PID 请求/应答） | ECU **愿意回答**的东西 |
| **CAN 探测** | **被动听**（`ATMA` 监听广播帧） | 模块**自己喊**的东西（转向灯/车门/刹车…） |

现在「PID」页第一行是 **`+ 新增 PID` / `PID 扫描器` / `CAN 探测`**，一行看完。
「连接」页那个按钮和处理函数已删除（不是隐藏 —— 死按钮比没按钮更糟）。

### 2. 去掉「阿特兹模板」按钮

它做的是"复制 4 条**占位**模板（PID 号是猜的）成可编辑条目"。
这个功能已经被两件事取代：

- **转向灯**：占位模板 `tpl_left_turn`/`tpl_right_turn` 已换成**实车确认的监听型** `mon_turn_left`/`mon_turn_right`（v1.19.10）
- **其余信号**：正确的流程是「CAN 探测」跑两次 + 「对比基准」找位（v1.19.15），
  **不是**先复制一堆猜的号再一个个改

`seedTemplates()` 一并删除（留死代码比留死按钮更糟）。
`Store.importTemplatesAsCustom()` 保留但不再有入口。

### 3. 规则里的音效可以**试听**

动作行多了个 **♪** 按钮（只在「播放音效」时出现）：

- **不必先保存规则** —— 按当前的三个参数立刻播一次，改速率/音量后可以反复听
- 参数就是 v1.19.13 那三个：`p1` 音效名 / `p2` 速率 / `p3` 音量
- `AudioPlayer.play(..., force = true)` **绕过音效总开关** ——
  试听是用户明确按下的动作，因为"总开关关着"就静默不响，用户会以为按钮坏了

### 验证

| 项 | 结果 |
|---|---|
| Kotlin 单测 | **563 全过** |
| 构建守卫 | 通过（1 条警告，仍是那 15 个未绑定控件的已知缺口） |
| APK | `dist/iCarOBD-debug-v1.19.16-android.apk`（versionCode 59） |
| 装机 | ⚠️ **未装** —— 构建时平板离线（`adb devices` 为空），下次连上再装 |

---
## v1.19.15 · 2026-10-06 · 「对比基准」找位工具：把找信号从"人工差分"变成"点两下"

### 背景：下一个瓶颈不是"能不能收"，而是"每个信号都要人工找位"

转向灯走通了（`0x09A` bit2/bit3），但**那一位是我在电脑上手工差分找出来的** ——
每收一个新信号就要一个人工环节：跑两次探测、把日志拉回来、写一段脚本比对。
`0x09A` 那一次花了不少时间。**这个环节必须消失**，否则剩下那些信号一个个来会拖很久。

### 做了什么

- **`CanDiff`（新，纯逻辑 + 5 条回归测试）**：把一个 CAN ID 出现过的**所有不同取值**
  折算成**每一位**的状态 —— `CONST0` / `CONST1` / `VARIES`，再比两次探测的**状态**。

  ⚠️ **判据是"状态"，不是"两个值 XOR"**：单次采样会撞相位
  （转向灯 1.4 Hz，采到亮还是暗是掷硬币），XOR 会把相位差异当成信号。
  "某一位从恒定变成在变"才与相位无关。

- **「对比基准（找位）」按钮**：「CAN 探测」页。把**上一次探测**当基准，
  列出状态变化的位，每行一个「加为监听」按钮。
- **一键加为监听型 PID**：`★ 09A 第3字节 bit2：恒0 -> 在变` + 一次点击 ->
  `Store.upsertPid` 生成 `source="monitor"` / `header="09A"` / `formula="bit(C,2)"` 的条目
  —— 于是它**立刻**能用在下拉框、仪表和规则里。用固定 id，同一处再加是**覆盖**不是堆积。
- 收尾时**自动打印差分**（`CAN 差分位 | … 公式=bit(C,2)   <== 这次操作引起的`），
  所以即使不点按钮，日志里也有。
- 基准的提升只在 `start()` 里做；`reset()`（清空按钮）**不动**基准 ——
  否则在两次对照之间按了清空，基准就被换掉，"对比基准"直接失效。

### 修掉的那条**已被实验推翻的前提**

`docs/03-迭代清单.md` 原文写着：

> 13 个指示灯 → **厂家 Mode 22，号必须扫描器实测**

**这是错的。** 转向灯实测证明它是**广播帧的一个位**（`0x09A`），**不是 Mode 22 的 DID**：
Mode 22 扫了 `1100~11FF`（3 个应答）和 `DA00~DAFF`（50 个应答），**一个都没有转向灯**。
所以那 13 个指示灯大概率都在广播帧里，**用同一套工具（探测 + 对比基准）就能收**，
而且**不需要 `header`**（广播就能问到）。迭代清单已加更正说明。

### 验证

| 项 | 结果 |
|---|---|
| Kotlin 单测 | **563 全过**（新增 5 条 `CanDiffTest`，用实车 `0x09A` 原始字节） |
| 构建守卫 | 通过 |
| APK | `dist/iCarOBD-debug-v1.19.15-android.apk`（versionCode 58） |
| 已知局限 | 每个 ID 只留 8 个不同取值，稀疏变化的位可能被误判成恒定 —— 所以差分结果是**候选**，加为 PID 后在真实操作下确认 |

---
## v1.19.13 · 2026-10-06 · ✅ 转向灯响了；音效可调速率与音量

> 实车确认：**开启常驻监听 -> 拨转向灯 -> `tick_left` / `tick_right` 正常发声。**

### 从"能用"到"真的响"，中间还差两个 bug —— 都值得记

**① 按字符串比 CAN ID（v1.19.11）**

`Frame.idHex()` 用的是 `%X`：`0x09A` 出来是 `"9A"` 而不是 `"09A"`，
而配置里习惯写 `"09A"`。字符串直接比 -> **永远不命中**，且现象是
「帧一直在进、命中一直是 0」（实车：`帧=581 命中=0`）。
改成启动时就把 `header` 解析成**数值**缓存起来，逐帧比 `f.canId`。

**② 规则引擎在监听期间**根本没被驱动（v1.19.12）

规则是被**轮询周期**驱动的：`engine.onCycle` -> `ObdController.onEngineCycle()`
-> `RuleEngine.evaluate()`。而 **`ATMA` 期间轮询引擎是停的**，那个回调不触发 ——
于是 `VehicleBus` 里明明有值（`命中=114`），规则却**一次都没被评估过**，一点声音都没有。

修法：`ObdController.runCycleOnce()` 把「G 值推进 + 规则评估 + CSV 落盘」暴露出来，
`FrameMonitor` 每帧命中后调一次。

> **教训**：这是"**数据到了、但没人消费**"的一类 bug ——
> 光看数据侧（帧数、命中数、取值）**完全看不出来**。同时顺手加了
> `监听信号变化 | 左转向灯(mon_turn_left) = 1.0` 日志，
> **不再让用户靠"有没有听到声音"来判断**：日志自己会说话。

### 音效可调：速率 + 音量（v1.19.13）

`RuleAction` 本来就是 `type + p1/p2/p3` 的通用形状，所以**存量 JSON 不用迁移**：

| 参数 | 含义 | 范围 |
|---|---|---|
| `p1` | 音效名 | `tick_left` / `tick_right` / `warn` / `beep` |
| `p2` | **播放速率** | `0.5~2.0`（默认 1） |
| `p3` | **音量** | `0~1`（默认 1） |

- `AudioPlayer.play(name, volume, rate)`：原来 SoundPool 的 `rate` **写死 1f**，现在可传。
  ⚠️ `rate` 会**同时改变时长和音高** —— 调大是"更快更尖"的咔嗒声，
  转向灯那种继电器"嗒"声用 **1.4 左右**比 1.0 更像。
- 规则编辑器动作行新增**参数3**输入框，`sound` 类型的提示语改成
  「速率 0.5~2」/「音量 0~1」。
- **播放频率** = 规则里的 `冷却(ms)`，标签改成 **「冷却 / 播放间隔(ms)」** 点明它就是间隔
  （转向灯默认 450ms，接近实车节奏）。
- `RuleAction.describe()` **只在真的设了参数时**才显示它们 ——
  默认值拖在每条描述后面纯属噪音，而且 `播放音效 tick_left` 这条断言是既有契约
  （测试直接抓到了我第一版写法，逼出了更好的设计）。

### 验证

| 项 | 结果 |
|---|---|
| Kotlin 单测 | **558 全过** |
| 构建守卫 | 通过 |
| APK | `dist/iCarOBD-debug-v1.19.13-android.apk`（versionCode 56） |
| 实车 | ✅ **拨转向灯，`tick_left`/`tick_right` 正常发声** |

---
## v1.19.10 · 2026-10-06 · 监听通道：把广播帧变成虚拟 PID（转向灯终于能用）

### 做了什么

**「CAN 探测」页新增「开启常驻监听（转向灯）」** —— 它把**广播帧**变成虚拟 PID，
于是规则引擎、仪表、CSV **一行下游代码都没改**就能用上转向灯。

- `PidDefinition` 新增 `source`：`"poll"`（默认，主动请求）/ `"monitor"`（从广播帧取值）。
- `FrameMonitor`（新）：停轮询 -> 装 CAN 过滤器 -> 开 `ATMA` -> 逐帧按 `header`（= CAN ID）
  匹配 -> 用该条 PID 的 **`formula`** 求值（公式语言原样复用，所以 `bit(C,2)` 直接能写）
  -> `VehicleBus.put(...)`。UI 在「CAN 探测」页。
- 内置 PID `tpl_left_turn` / `tpl_right_turn`（原本是**占位模板**：mode 22 / pid 2201/2202，全错）
  **改成实车确认的监听型** `mon_turn_left` / `mon_turn_right`：`header = "09A"`、
  `formula = "bit(C,2)"` / `"bit(C,3)"`、默认启用。
  `Defaults` 里那两条默认规则**自动就绑对了** —— 项目早就把这两个占位和规则准备好了，
  注释里甚至写着"右转向一般在同一个字节的相邻位"，与实测完全一致。
- 别名（`DesignFile.PID_ALIASES` + `tools/theme-studio/js/schema.js` **两侧同步**）：
  `can.turn_left` / `can.turn_right`。因为**测试有一条「厂家模板刻意没有别名」**
  （`PID_ALIASES.values.none { it.startsWith("tpl_") }`），所以这两个 PID 必须**换 id**
  而不是给 `tpl_*` 起名 —— 这条测试逼出了正确的设计，记一功。

### 为什么是「模式切换」而不是「顺便多收一点」

ELM327 是**半双工**的：`ATMA` 监听期间没法收发请求。所以开着常驻监听时，
**转速/水温那些标准 PID 会冻结在最后一个值**（不是 bug，是硬件限制）。
停止监听时会自动 `initializeAndStart()`（`ATZ`）把过滤器清干净 —— 见 v1.19.8 的教训。

### 过滤器只放行 `0x09A`

`FrameMonitor` 优先用**单 ID** 的 `ATCRA`（`ids.size == 1` 时），而不是按段过滤：
只看 `0x09A` 时流里每秒约 2.5 帧；按段过滤（`ATCM700`+`ATCF000`）会放进整段 `0x0xx`
（约 344 帧/秒），那些帧全要在主线程上切行解析 —— 纯浪费，而且这项目历史上
已经被主线程堆积搞出过一次 ANR。

### 存量规则会失效 —— 所以加了自动迁移

`tpl_left_turn` -> `mon_turn_left` 只是改名，但 `rules.json` 是**落盘的**
（实车确认设备上存的正是 `"source": "tpl_left_turn"`）。不改名的话那两条规则会指向
一个**不存在的 id**，而 `RuleEngine` 拿不到值时是"条件不成立"——
**不报错、不提示**，表现为"转向灯拨了就是不响"，极难查。

`Store.loadRules()` 里加了一次性迁移（改过才回写盘），并在日志里留痕：
`规则迁移(转向灯) | 左转向灯音效: tpl_left_turn -> mon_turn_left`。

### 验证

| 项 | 结果 |
|---|---|
| Kotlin 单测 | **558 全过**（新增 3 条：`TurnSignalMonitorTest`，用**实车抓到的原始字节**锁住位定义） |
| 跨语言校验 | `verify-crosslang.js` **PASS=104 FAIL=0** |
| 构建守卫 | 通过 |
| APK | `dist/iCarOBD-debug-v1.19.10-android.apk`（versionCode 53） |
| 实车验收 | 开启常驻监听 + 拨转向灯 -> 规则应发出 tick 音效（待验） |

**已知（非阻断）**：`verify-crosslang.js` 会备注"工具里多出 2 个 PID（App 侧没有）：
mon_turn_left, mon_turn_right" —— 这是**该脚本解析器自身的局限**（它第 188 行就记录了
同类误报），App 侧 `BuiltInPids.kt` 里确实有这两条，PASS/FAIL 也不受影响。

---
## v1.19.8 · 2026-10-06 · 转向灯找到了：`0x09A` 的低两位

### 结论

**CAN ID `0x09A`，数据第 3 字节（`A B C…` 里的 `C`）：**

| 状态 | `0x09A` 数据 | 公式 |
|---|---|---|
| 都不亮 | `00 00 00 00 88 00 03 00` | —— |
| 左转 | `00 00 04 00 88 00 03 00` | `bit(C,2)` |
| 右转 | `00 00 08 00 88 00 03 00` | `bit(C,3)` |

完整证据链见 `stage/oncar-evidence/turn-signal-09A.md`。

### 为什么前面四组实验全都失败 —— 采样率

`0x09A` 只以**约 2.1 Hz** 广播。不过滤时克隆版总共只漏出约 77 帧/秒，
摊到约 80 个 ID 上就是**每个 ID 每秒 1 帧**，20 秒只采到 4~5 帧 —— 1.4 Hz 的闪烁被完全抹平。

加上 CAN 过滤器（`ATCM700+ATCF000`）把带宽让给它之后：

```
75/76:  0.7 帧/秒  ->  20 帧/秒
总帧数:  77/秒     ->  344/秒
```

`changed` 第一次能反映真实翻转：关灯 `changed=1`，开灯 `changed=13`（两次独立复现）。

**教训：判断"能不能看见一个信号"之前，先算 `适配器实际帧率 ÷ 目标 ID 广播频率`。**

### 工具上的三个关键补齐

- **CAN 接收过滤器**（`ATCRA` / `ATCM`+`ATCF`）：探测页新增「过滤器」输入框。
  掩码版一趟覆盖 256 个 ID，16 趟扫完整个 11 位 ID 空间。
- **取值集合**（`Aggregate.values`，有界 8 个）：聚合里的 `lastData` 只是**最后一帧**的值，
  周期信号很容易正好停在暗相位 —— 实车 `09A` 左转/右转两次的 `last` **都是 `00`**，
  光看 `last` 根本分不出左右。**这个字段是最后一块拼图。**
- **收尾必须重新初始化**：`ATAR`/`ATCM000`/`ATCF000` 三条**都回 `OK` 却清不掉过滤器**
  （AT 命令由适配器内部处理，而 `01 xx` 要等 CAN 应答，正好被挡住）。
  唯一确定有效的是 `ATZ` 全复位 —— 所以用过过滤器就自动 `initializeAndStart()` 一次。

### 顺带修掉的三个坑（都在收尾/准备阶段）

- **收尾的重新初始化是异步的** → 用户可以在它跑完前开始下一次探测，
  它的 `ATZ/ATE0…` 会和新探测的 `ATMA` 互相打架（实车：`frames=110`，正常应为 2728）。
  现在 `finish()` 有重入保护，且**收尾期间拒绝新探测**。
- **`finish()` 没有重入保护** → 到时自动停止 + 手动停止各跑一遍收尾（日志里两条「探测结束」）。
- **准备前没排空 ATMA 残余输出** → 第一条 AT 读到上一次的积压，
  表现为 `ATH1 -> STOPPED`，后果是**整趟探测作废**（`lines=3700 parsedFrames=0`）。
  现在准备前先 `\r` + 等 300ms，且 `ATH1`/`ATS1`/`ATL1` **各试 3 次、只认 `OK`**。

### ⚠️ 尚未解决：广播帧怎么进规则引擎

`0x09A` 是**广播帧**，不能像 PID 那样主动请求，只能靠 `ATMA` 被动监听；
而 **`ATMA` 期间适配器独占（半双工），无法同时轮询**。
所以要驱动「左转/右转滴答」两条规则，需要新能力：**「监听帧 → 虚拟 PID」+ 与轮询分时复用**。
已记入待办。

### 验证

| 项 | 结果 |
|---|---|
| Kotlin 单测 | **555 全过** |
| 构建 | `BUILD SUCCESSFUL` |
| APK | `dist/iCarOBD-debug-v1.19.8-android.apk`（versionCode 51） |
| 实车 | 左转 `04` / 右转 `08`，两次探测各只有 2 个不同取值 ✅ |

---
## v1.19.3 · 2026-10-06 · CAN 接收过滤器（探测终于能看清闪烁类信号）；以及一个"看起来像链路坏了"的坑

### 新增：CAN 探测支持 `ATCRA` 过滤器

ATMA 抓不到转向灯的**根因是采样率**（约 77 帧/秒 ÷ 约 80 个 ID = **每 ID 每秒 1 帧**），
而解决它的钥匙是 **CAN 接收过滤器**：过滤到少数 ID 之后，同样的带宽全给它们。

- 实车探针确认 **克隆版支持 `ATCRA`**：`ATCRA228` -> `OK`。
- 「CAN 探测」页新增 **过滤器** 输入框（`etSniffFilter`）。
  填 CAN ID（如 `228`）则在 `ATMA` 之前发 `ATCRA228`；**留空 = 不过滤**（原行为不变）。
- 每条 AT 的应答照旧记日志（`探测准备 | ATCRA228 -> OK`）。

### ⚠️ 坑：过滤器会**连带挡住正常 OBD 的应答**

正常 OBD 请求发给 `7DF`、应答回 `7E8`；而 `ATCRA228` 只放行 `228` ->
**应答全被过滤掉**，表现是「链路突然全是超时」，而**从界面上完全看不出原因**。

实车踩到的原始记录：

```
[14:35:52] 轮询汇总 | 有值 20/25 ...        <- 最后一次正常
[14:35:40] TX | ATCRA228                    <- 过滤器设上
[14:36:00] 超时无响应 | cmd=01 A6 timeout=600ms
[14:36:00] 超时无响应 | cmd=01 0D timeout=600ms
[14:36:01] 超时无响应 | cmd=01 42 timeout=600ms   <- 连续 11 条全部超时
```

对策（两层）：

1. `CanSniffer.finish()` 里**必须**发 `ATAR`（Automatic Receive，关掉接收过滤），
   并**记录应答**；应答不是 `OK` 时打 `E` 级日志，明确指向"重新初始化"这个兜底动作。
2. 兜底：初始化第一步是 `ATZ`，**会复位一切**（含 CAN 过滤器）——
   所以"到「连接」页重新初始化一次"永远是有效的恢复手段。

### 顺带更正一处过时的注释

`CanSnifferActivity` 的类注释原本写「转向灯、车门、刹车这类信号**只能**被动监听」。
2026-10-06 实车证明这句是错的：这些车身信号 **Mode 22 主动请求也能问到**
（广播 `22 DAxx` 一次就问到 50 个 DID），而且**主动请求的采样率由我们自己定**。
注释已按事实改写。

### 验证

| 项 | 结果 |
|---|---|
| Kotlin 单测 | **555 全过** |
| 构建 | `BUILD SUCCESSFUL` |
| APK | `dist/iCarOBD-debug-v1.19.3-android.apk`（versionCode 46） |
| 探针 | `ATCRA228 -> OK`（过滤器可用） |
| 待验 | 过滤器 + 按 ID 段观察，能否抓到转向灯（尚未成功） |

---

## v1.19.2 · 2026-10-06 · 开机自动连接 + 自动初始化；并给「ATMA 找转向灯」画上句号

### 新增：上车流程压成「打开 App」

- 新增持久化标志 `Settings.everGotData` —— **只在第一次真的解析出数值时**置位
  （`ObdController.init` 里挂 `VehicleBus.addValueListener`）。
  光看 `lastDeviceAddress` 不够：那个字段在「点了连接但连不上 / 连上了读不到数据」时
  也会被写进去，下次开机会对着连不通的适配器白试一遍。
- `App.onCreate` -> `ObdController.autoStartIfPossible()`：四个条件全满足才发起
  （`everGotData` && `autoReconnect` && 有地址 && 非用户主动断开），
  外加两道防重入（已在自动连 / 已连上）。
- 连上（READY）-> `autoScope` 里自动跑一次 `initializeAndStart()`。
  因为 **ELM327 的 AT 设置掉电即失**（拔适配器、车断电就回出厂态），每次上车基本都得重新初始化。
- **冷启动连不上不会进重连循环**：`scheduleReconnectIfNeeded` 要求 `wasReady`，
  而冷启动失败时它还是 false。
- 调用点包了 `runCatching`：全新安装时 `BLUETOOTH_CONNECT` 可能还没授予。

### `ATMA` 被动探测：能力边界测出来了（结论：此路不通）

想用被动监听找**转向灯**（标准 OBD 里没有它）。做了四组对照实验，全部无效：

| 实验 | 结果 |
|---|---|
| 转向灯 关 / 左转 | 两次的 **81 个 ID 一个不差**，`changed` 差异 <=3（帧数缩放的正常波动） |
| 刹车 松 / 踩 | 第一次 `166` 看着像（`30 10`->`31 88`），**复测没复现**（`70`/`62` 同样在抖） |
| 刹车 复测 | 34 个 ID 数值都变，但**全是模拟量抖动**，没有一处干净的二元翻转 |
| 「只在一次出现」的 ID | 5 个 -> 13 个，**不一致** = 随机欠采样的特征（且第一次那 5 个在别的会话里也出现过） |

**根因是采样率**：三次干净探测都是 **约 77 帧/秒**，而总线上有 **约 80 个 ID**
-> **每个 ID 每秒只采到 1 帧**。真实 HS-CAN（500 kbit/s、负载几十 %）是每秒几千帧。
满屏 `<DATA ERROR` 就是克隆版在丢帧。**在这个密度下，1.4 Hz 的闪烁根本无法还原。**
（又一次印证 v1.18.1 那条：「适配器是 v1.4 水平的克隆」。）

**所以转向灯不走 ATMA。** 正道是 `03-迭代清单.md` 里本来就为 14 个指示灯规划的那条：
**厂家 Mode 22 经网关**。它缺的能力是**扫描器的「模块头」**
（`header` 只加在了 PID 上，没加在扫描器上）—— 已记入待办。

### 顺带修掉的（v1.18.8 ~ v1.19.1）

- **`ATS1` 必须补发**：初始化序列里有 `ATS0`（关空格），而 `ATMA` 输出是
  空格分隔的 `7E8 06 41 0C 1A F8`。关着空格时 `parseLine` 切不出 token
  -> `lines=2598 parsedFrames=0`：**总线数据一直在流，只是被解析器扔了**。
  另加 `ATL1`（开换行）与 `ATH0/ATS0/ATL0` 的收尾还原。
- **AT 应答记日志**：`探测准备 | ATH1 -> OK`。三次探测的 AT 序列曾经逐字相同却结果不同，
  没有这行就无法区分「适配器没接受」与「接受了但输出被冲烂」。
- **`CAN ID(changed)` 排序**：闪烁类信号 count 不高但 changed 高，按 count 排会被埋掉。
- `AGG_LOG_MAX` 40 -> 130（全量 ID）；`RAW_LOG_MAX` 12 条原始行（有界，防洪水）。

### 验证

| 项 | 结果 |
|---|---|
| Kotlin 单测 | **555 全过** |
| 构建 | `BUILD SUCCESSFUL` |
| APK | `dist/iCarOBD-debug-v1.19.2-android.apk`（versionCode 45） |
| 实车复验 | 需要**再成功连一次并收到数据**（写下 `everGotData`），此后重启 App 应自动连上并自动初始化 |

### 教训（写给下一个接手的人）

- **随机出现不等于因果。** 我两次把「只在某一次会话里冒头的 ID」当成信号
  （`4EC`/`591`/`5A0` 那些网络管理帧），都在查了全日志之后被推翻。
  **判据必须是「可复现」，不是「这一次有」。**
- **采样率是前提，不是细节。** 77 帧/秒 / 80 个 ID 这个数字，决定了"闪烁类信号测不出来" ——
  在动手写解析之前先算这个比值，能省掉一整天。

---

## v1.18.7 · 2026-10-06 · 🔴🔴 **支持位图枚举少加 1 —— "位图漏报"的真身**

`PidScanner` 解位图时写的是 `out.add(block + i)`。但 `01 00` 响应的**最高位代表 PID `01`**，
正确是 **`block + 1 + i`**。**整条链每个块都少加 1**，于是扫描器去问的是
"每个被声明支持的**前一个** PID"：

| 位图位 | 应用算的 i | 应用去问 | 真正的 PID |
|---|---|---|---|
| `A8` b7,b5,b3 | 16,18,20 | `01 10` `01 12` `01 14` | `01 11` `01 13` `01 15` |
| `13` b4,b1,b0 | 27,30,31 | `01 1B` `01 1E` `01 1F` | `01 1C` `01 1F` `01 20` |
| `14`（A0 块） | 3,5 | `01 A3` `01 A5` | **`01 A4` `01 A6`** |

实车对照（2026-10-06 阿特兹）：扫描窗口里扫描器实际发出的正是
`01 00` `01 12` `01 1B` `01 1E` —— 与"少加 1"的预测**逐字吻合**。

### 两个后果，都很能骗人

- **车厂声明了的 PID 没被问**（`11`/`13`/`15`/`1C`）-> 看起来像"这台车不支持"
- **去问的那个 PID 碰巧也能答**（`10`/`12`/`1B`）-> 看起来像"位图在漏报"

> ⚠️ **撤回 v1.18.4 里"支持位图漏报 `11`/`21`/`A6`"那条结论 —— 它是错的。**
> 位图没漏，是枚举偏了一位。`21` 同理（0x20 块声明了 `21`，应用去问 `20`）。
> 更要紧的是：**车厂其实声明了 `A4`（挡位）与 `A6`（总里程）**，只是应用去问了
> `A3`/`A5` —— 这才是"挡位一直能找到、却从来没被问过"的真正原因，
> 也解释了 `A5` 为什么回 `NO DATA`（它本来就没人声明要支持，是被错位问到的）。

### 修法

把解位图抽成**纯函数** `PidScanner.decodeSupportBitmap(block, data)`，修正为
`block + 1 + i`，并加两条用**实车真实字节**的回归测试：

- `01 00` 的并集 `FE 3F A8 13` -> 断言最高位映射到 `01`，且**不能**映射出 `00`
- `01 A0` 的并集 `14 00 00 00` -> 断言解出 **`A4` 与 `A6`**

> 写完就跑挂一条：我断言 `0x10`"没被声明"，其实 `0x3F` 的 `b0` 正好是 PID `0x10`。
> **是测试抓到了我，不是代码错** —— 这正是加它的意义。

### 验证

| 项 | 结果 |
|---|---|
| Kotlin 单测 | **555 全过**（+2） |
| 构建 | `BUILD SUCCESSFUL` |
| APK | `dist/iCarOBD-debug-v1.18.7-android.apk`（versionCode 40） |
| 实车复验 | ⬜ 待复验：`supported` / `total` 的**数字不变**（置位数相同，只是整体 +1），但**命中清单会变**，且应出现 **`A4` 与 `A6`** |

---
## v1.18.6 · 2026-10-06 · Mode 字段不补零 → 发出畸形帧（用户填错了却毫无提示）

实车同一天踩了两次，都是"Mode 只填了 1 位十六进制"：

```
12:04  PID 测试 | req=2 A4   raw=7F2A7F        ok=false
12:37  PID 测试 | req=1 A4   raw=NO DATA       ok=false
       PID 测试 | req=01 A4  raw=41A403000DE1  ok=true   <- 填 01 才对
```

### 根因

`PidDefinition.normalize()` 只做 `trim` + 压空白 + 大写，**不补零**：

```kotlin
fun normalize(s: String) = s.trim().replace(Regex("\\s+"), " ").uppercase()
```

Mode 填 `1`，发出去就是 `1 A4` —— ELM327 把 `1A4` 当**三个 nibble**，帧是畸形的，
ECU 回 `NO DATA` 或否定响应。**属于"用户填错了却没有任何提示"的那类错。**

### 修法（刻意收窄，避免改坏别处）

- **只补长度为 1 的 token**：`1` -> `01`、`4` -> `04`
- **只有整串都是十六进制时才动** —— `ATI` / `ATSH7E0` 这类 AT 命令不能被碰
- `7E0`（长度 3）**不动**：补成 `07E0` 会把 CAN 头毁掉

`requestString()` 与 `customRequest` 都走这条路，所以**旧配置里已存的没补零的串
也会被就地纠正**。

### 验证

| 项 | 结果 |
|---|---|
| Kotlin 单测 | **553 全过**（+3：补零 / 不碰 AT 与三位地址 / requestString 也享受补零） |
| 构建 | `BUILD SUCCESSFUL` |
| APK | `dist/iCarOBD-debug-v1.18.6-android.apk`（versionCode 39） |

### 顺带

- 测试名里不能有 ASCII 句点（JVM 方法名非法），`（v1.18.6）` 这种写法编译期就报
  `Name contains illegal characters` —— 版本号写进注释，别写进测试名。

---
## v1.18.5 · 2026-10-06 · 🔴 **支持位图链被"另一个模块的应答"提前掐断 —— 扫描结果取决于谁先回**

上游：同一天两次扫描给出**完全不同的"这台车支持什么"**。

| 扫描 | 读到的位图块 | `supported` | 命中 |
|---|---|---|---|
| 11:56 | `00` `20` `40` **`60`** **`80`** **`A0`** | **57** | 31 |
| 12:34 | `00` `20` `40`（`60`/`80`/`A0` 全没读） | **16** | 12 |

### 根因：两个模块的 nextBit 相反，而到达顺序会变

这台车对每个位图块回**两份应答**（两个模块），它们对「还有下一块」
（`byte3` 的 `bit0`）判断**相反**：

```
01 40 -> 41 40 FE D0 8C 81   <- 模块1：0x81，bit0=1，「还有」
         41 40 C0 80 00 00   <- 模块2：0x00，bit0=0，「没有了」
```

而这两份的**先后顺序在两次运行之间会变**：

```
11:56  01 40 -> FE D0 8C 81 先到 -> 继续 -> supported=57（含 A1~C0）
12:34  01 40 -> C0 80 00 00 先到 -> 断在 0x40 -> supported=16
```

`querySupportedPids` 原来只取**第一份**应答（`extractData(..., ecuIndex = 0)`），
再拿它的 `bit0` 决定要不要继续 —— **于是"这台车支持什么"取决于哪个模块先回。**

12:34 那次 `0x61`~`0xC0` 整段不可见，而**挡位 `A4`、总里程 `A6` 就在那一段**。
**v1.18.0 把 `maxBlock` 从 `0x60` 提到 `0xC0` 只治了"上限"，没治这个提前退出。**

### 修法（`PidScanner.querySupportedPids`）

- 每一块**遍历所有模块的应答取并集**（`extractData(..., ecuIndex = 0,1,2,3)`，
  取不到即止；只用每份的**前 4 字节**，别把下一份的字节算进来）
- **不再用 `nextBit` 提前退出**：`mode 01` 全链只有 7 个请求
  （`00/20/40/60/80/A0/C0`），只在"这一块一个应答都没有"时才停
- 新增 D 级日志 `位图块 | block=.. ecu=.. PIDs=..`，下次实车能直接看出每块收了几家应答

**确定性 > 省两三个请求。**

### 验证

| 项 | 结果 |
|---|---|
| Kotlin 单测 | **550 全过**（本机真实执行） |
| 构建 | `BUILD SUCCESSFUL` |
| APK | `dist/iCarOBD-debug-v1.18.5-android.apk`（versionCode 38） |
| 实车复验 | ⬜ 待复验：连跑两次扫描，`supported` 应**稳定且两次都覆盖到 `A0` 块** |

### 遗留

- **`extractData` 的多模块分支（路径 C）在 BLE 下是死代码**：它按"多行"判断多模块，
  但 `BleTransport.onRawBytes` 把 `\r`/`\n` 都换成了空格，多模块应答被**拍平成一行**。
  实际走的是单行路径 + `ecuIndex` 位移。这条没改（`ecuIndex` 恰好够用），但要知道。

---

## v1.18.4 · 2026-10-06 · 🔴 **日志页切走再切回来会 ANR（被系统杀）—— `hide()` 不触发 `onPause()`**

同一次实车（v1.18.3 跑通之后），用户切到「日志」页看日志，**App 被系统杀了**。

### 不是崩溃，是 ANR

```
12:06:13 am_anr : [com.icar.obd, Input dispatching timed out
   (MainActivity is not responding. Waited 5001ms for MotionEvent(action=DOWN))]
12:06:22 am_kill: [com.icar.obd, user request after error]
12:06:22 Zygote  : Process 13935 exited due to signal 9 (Killed)
```

crash buffer 里**没有 Java 异常**，`files/last-crash.log` 也**没有**（说明不是被捕获的异常），
是主线程卡死 5 秒导致输入分发超时，随后被 SIGKILL。

### 根因：GONE 的 RecyclerView 会无限堆积 adapter 通知

页面切换时间线（同一次会话的应用日志）：

| 时刻 | 事件 |
|---|---|
| 11:57:03.888 | `切换页面 \| log` —— 第一次打开（只看了 **3.4 秒**） |
| 11:57:07.287 | `切换页面 \| dash` —— 切走 |
| （隐藏 **8 分 59 秒**） | 监听器仍在收日志（~47 条/秒），而日志页不跑 layout |
| 12:06:07.070 | `切换页面 \| log` —— 再切回来 |
| 12:06:07.665 | 第一条 `超时无响应 \| cmd=01 49 timeout=600ms` |
| 12:06:13.009 | **ANR** |
| 12:06:22 | SIGKILL |

链条：

1. `MainActivity.switchTo` 用 **`hide()`/`show()`**（不是 `replace()`）—— 为了切页不重建、仪表盘不闪。
2. 但 **`hide()` 不触发 `onPause()`**（被隐藏的 Fragment 仍是 RESUMED）。
3. 所以 `LogFragment.onPause()` 里的 `unsubscribe` **永远不执行**，监听器在隐藏后仍然挂着。
4. 隐藏时 RecyclerView 的 View 是 **GONE** → 不跑 layout → 每次
   `notifyItemInserted` / `notifyItemRemoved` 都堆进 `AdapterHelper` 的待处理队列，**永不被消费**。
5. 47 条/秒 × 539 秒 ≈ **2.5 万个待处理 op**。
6. 切回来时第一次 layout 一次性回放全部 op → 主线程卡死 5 秒 → ANR。

**这也解释了为什么第一次打开（11:57）正常、第二次（12:06）必死** —— 堆积需要时间。

### 旁证：把「主线程被卡死」和「协议超时」分开

ANR 期间日志里有 26 条 `超时无响应 | cmd=01 .. timeout=600ms`，
但**每条命令的 RX 都到了**（`TX 01 49` → +46ms `RX 414927` → +603ms 才报超时）。
因为 `onRx` 是经 `main.post` 回调的：**主线程被卡死 → 回调不执行 → 协议层误报超时**。
所以这 26 条超时是 ANR 的**症状**，不是链路问题 —— 本次会话前半段 `超时无响应 = 0`。

### 修法（`LogFragment`）

- 监听器里加 `if (isHidden) return@addListener` —— 隐藏期间**不碰** RecyclerView。
- 新增 `onHiddenChanged(hidden)`：隐藏时停掉 `uiTick`；**切回来时用一次 `submitAll`**
  （整表替换，只发一次 `notifyDataSetChanged`）把落后的缓冲补齐，
  而不是把积累的两万多个 op 一次性喂给 RecyclerView。

> ⚠️ **同类风险不止这一页**：任何「RecyclerView + 在 `onResume` 里注册监听器」的页面，
> 只要会被 `hide()` 切走，就有同样的堆积路径。日志页只是**刷新率最高**（~47 条/秒）
> 所以第一个炸。新增这类页面时请一并实现 `onHiddenChanged`。

### 验证

| 项 | 结果 |
|---|---|
| Kotlin 单测 | **550 全过** |
| 构建 | `BUILD SUCCESSFUL` |
| APK | `dist/iCarOBD-debug-v1.18.4-android.apk`（versionCode 37） |
| 实车复验 | ⬜ 待复验：打开日志页 → 切走 10 分钟 → 再切回来，应当不卡 |

### 遗留

- `初始化完成 | ok=false` 是**不稳定**判据：同一次实车 11:46 报 `ok=false`、
  11:55 报 `ok=true`（同车同适配器）。判据里有竞争，不是恒错。**未修**。
- ⚠️ **本条已作废 —— 见 v1.18.7：位图没有漏报，是位图枚举少加了 1。**
- ~~支持位图**漏报**~~：`11`（节气门）/ `21`（故障灯后里程）/ `A6`（总里程）实测有值，
  但都不在车厂声明的位图里。**扫描器按位图收敛会系统性漏掉它们** ——
  `16-上车监控清单.md` §6「勾选支持位图」那条建议需要改。
- **`A4` 挡位已实测完成** —— 见下面「追加实车结论」。

### 追加实车结论：`01 A4` 到底能拿到什么（同日 · 无代码改动）

v1.18.0 的调研写的是：`A4`(164) = Transmission Actual Gear，4 字节，`(256C+D)/1000`，
**字节 B 是枚举的挡位状态**，值到挡位的映射"待停车场实测"。**实测做完了 —— 一半对，一半错。**

114 个样本、P/R/N/D 各反复测，**只有 3 种帧，零抖动**：

| 挡位 | 原始帧 | A | B | C | D | 样本数 |
|---|---|---|---|---|---|---|
| **P / N** | `41A403000DE1` | 03 | **00** | 0D | E1 | 85 |
| **R** | `41A403100DE0` | 03 | **10** | 0D | E0 | 14 |
| **D** | `41A403100DE1` | 03 | **10** | 0D | E1 | 15 |

**四条结论：**

1. **`A4` 存在、且完全确定性** —— 零抖动，可以当数据源用。
   （顺带：**它也不在车厂声明的支持位图里** —— 今天第二次撞到"位图漏报能用的 PID"。）
2. **"字节 B 是枚举挡位"这条是错的。** B 只有 `00` / `10` 两个取值，
   它是**1 bit 的「在挡 / 不在挡」标志** —— **P 和 N 的帧一模一样**，B 根本分不出它们。
3. **齿比 `(256C+D)/1000` 在静止时是死的**：P/N/D 全是 **3.553**、R 是 **3.552**。
   真实"实际齿比"不可能在 P、N、D 之间几乎不变 —— 所以它在这个状态下不携带挡位信息。
4. 实际能拿到的是**三态**：

   | 判据 | 含义 |
   |---|---|
   | `B=00` | **P 或 N** |
   | `B=10` 且 `D 字节=E0` | **R** |
   | `B=10` 且 `D 字节=E1` | **D** |

   可直接填的公式（产出 0/1/2）：**`bit(B,4)*2+bit(D,0)-1`** → `0=P/N`、`1=R`、`2=D`。

> ⚠️ 字节 `A=03`、字节 `C=0D` 在四个样本里全一样，是**常量**（大概率是"支持位 / 格式"字段）。

**拿不到 1~6 挡。** 要拿到必须让车动起来 —— 看齿比随升挡下降
（新建 PID：Mode `01` / PID `A4` / 公式 `(C*256+D)/1000`，开 CSV 记录 1Hz，慢速开一段）。

**显示成文字还没接上**：`valueLabels` 挂在 **`GaugeItem`（仪表显示项）** 上，
**不在 `PidDefinition` 上** —— 所以数字 0/1/2 能显示，要变成 `P/N · R · D`
得走主题工具往设计文件的节点里写映射表（P9 方向 A 的原设计如此）。

---
## v1.18.3 · 2026-10-06 · 🔴🔴 **实车打通！并修掉一个"链路修好之后才会出现"的崩溃**

> **这是项目第一次在车上持续读到真实数据。** 同时确认了 v1.18.1 的 GATT 竞态修复**有效**。

### 实车结果（2026-10-06 11:55 · 阿特兹怠速 · 小米平板 5）

| 判据 | 结果 |
|---|---|
| `CCCD 写入完成 \| status=0` | ✅ **出现** —— v1.18.1 修的 GATT 竞态确认修好 |
| `写入被拒` | ✅ **0 条**（v1.17.x 同一位置 191 条、写失败累计 4514） |
| `协议已锁定 \| ATDPN=A6` | ✅ ISO 15765 CAN 11bit/500k |
| `轮询汇总` | ✅ **有值 20/25**，连续 **121 秒**零崩溃 |
| 真实数值 | 转速 745~752rpm · 水温 90~91℃ · 电压 13.6V · 负荷 31.8% · 进气温度 46℃ · **总里程 67046km** · 故障灯 MIL=0 |

### 修了什么：`rxBuf` 跨线程数据竞争（FATAL）

链路修好之后 **16 秒**就崩：

```
java.lang.ArrayIndexOutOfBoundsException: Array index out of range: -24
  at java.lang.AbstractStringBuilder.setLength
  at BleTransport.flushRx(BleTransport.kt:603)
  at ElmSession.request(ElmSession.kt:51)
  at ObdEngine.loop(ObdEngine.kt:238)
```

`rxBuf`（`StringBuilder`）被**两个线程**同时改：
BLE 回调线程（`onRawBytes`，`append`/`delete`）与轮询协程（`flushRx`，`setLength`）。
并发下内部 `count` 被改坏成负数 → `setLength(0)` 抛异常 → 进程 FATAL。

**这个 bug 之前不可能出现 —— 以前一个字节都收不到，根本没东西往缓冲里写。**
是"链路修好"把它暴露出来的。**协议层一问一答 ≠ 字节层单线程。**

修法：4 个访问点共用一把 `rxLock`（`onRawBytes` 整段切帧 / `flushRx` / 断开时清空）；
锁内只做内存操作，日志与回调**收集完出锁再发**。

### 顺带：本机工具链（新笔记本）

- JDK `C:\Android\jdk21`（Temurin 21.0.12.1）· SDK `C:\Android\Sdk`
  （platform-tools 37.0.1 · platform-35 · build-tools 35.0.0 · NDK 29.0.14206865 · CMake 3.31.6）
- ⚠️ **`GRADLE_USER_HOME` 必须在纯 ASCII 路径**（本机 = `C:\Android\gradle-home`）。
  默认的 `C:\Users\大青虫\.gradle` 会让 Gradle 用 argfile 传 classpath
  （`@C:\Users\大青虫\.gradle\.tmp\gradle-worker-classpath*.txt`），
  JVM 启动器按 ANSI 码页解码那个路径 → 路径坏掉 → `ClassNotFoundException: GradleWorkerMain`
  → **所有单测跑不起来**（`Process 'Gradle Test Executor N' finished with non-zero exit value 1`）。
  **与项目已知的"中文路径"坑同源，但根因在 Gradle home，不在工程路径。**
- `services.gradle.org` 在本机不可达 → Gradle 8.14.3 预放进 `GRADLE_USER_HOME\wrapper\dists\`。

### 验证

| 项 | 结果 |
|---|---|
| Kotlin 单测 | **550 全过**（本机**真实执行**，核对过 XML 时间戳） |
| 构建守卫 | 通过（1 条警告，仍是那 14 个控件 PID） |
| APK | `dist/iCarOBD-debug-v1.18.3-android.apk`（versionCode 36） |
| 上车稳定性 | 连续轮询 **121 秒**零崩溃 |

### 遗留

- **`初始化完成 | ok=false` 是假阴性** —— 数据明明是通的。`proto=ELM327 v2.3/A0` 也串了位，
  像是 ATI / ATDPN 的响应配错了位置。v1.17.6 的「ok=false 也轮询」救了这次，**但判据要修**。
- 扫描器全链枚举（`00~C0`）尚未跑；**`A4` 挡位还没有结论**（`A6` 总里程已确认为 67046km）。

---
## v1.18.2 · 2026-10-06 · 加 `AT SH` 模块寻址 —— 厂家数据的前提

从 `vitaliykropko/carscaner`（**Mazda 6 GH** 的 PWA）学到的一件事：它用
**`AT SH <头>`** 指定模块（`7E0` 发动机），而我们**永远走 `7DF` 广播**。
马自达那个 ND3 项目挖 Mode 22 时用的也是 `7E0`/`760`/`730`/`7E1` 这些头 ——
**没有它，厂家数据根本够不到。**

### 加了什么

| 位置 | 内容 |
|---|---|
| `PidDefinition.header` | CAN 目标模块头，空 = 默认广播 `7DF`。JSON 只在非空时写出（旧文件行为不变） |
| `ObdProtocol.headerSwitch(current, wanted)` | **纯函数**：需要切时返回 `ATSH7E0\r`，不需要返回 null |
| `ObdEngine` | 记账当前头，每条 PID 前按需切换；`start()` 复位记账 |

### ⚠️ 关键点：`AT SH` 是**粘性**的，切回和切过去一样重要

设了 `760`（ABS/DSC）之后**后续所有请求都发往那个模块**。所以标准 PID 之前
**必须显式切回广播** —— 否则标准 PID 会被发到 ABS 模块去。

**而那种错从数值上完全看不出**（只是"这条 PID 读到了别的模块的值"）——
正是本项目最怕的那一类。所以这条专门有用例钉着
（`切回广播必须显式发命令`），而不是靠写代码的人记得。

### 验证

| 项 | 结果 |
|---|---|
| Kotlin 单测 | **550 全过**（+3：默认头不切 / 切到厂家模块 / **切回广播**） |
| 构建守卫 | 通过（1 条警告，仍是那 14 个控件 PID） |
| APK | `dist/iCarOBD-debug-v1.18.2-android.apk`（versionCode 35） |

### 遗留

- **还没有任何内置 PID 用到 `header`** —— 能力先备好，等拿到具体的马自达
  Mode 22 地址（如机油温 `22 13 10` @ `7E0`）再填
- **`AT SH` 在克隆版上的行为未实测**（我们的适配器自报 v2.3、真实能力 v1.4，
  见 v1.18.1 的 ELM327 资料研究）—— 上车时顺带看一眼日志里 `ATSH` 的响应

---
## v1.18.1 · 2026-10-06 · 🔴🔴 **"这么多版本都不行"的根因：一个 GATT 竞态**

用户问：**"推演下自己的逻辑结果、已经这么多版本都不行"**。
推了，而且**推到了一个我一直没看的层**。

### 推演过程：把 9 个版本摊开看

| 版本 | 碰了车链路吗 | 验过吗 |
|---|---|---|
| v1.17.1 删 `ATCAF0` | ✅ 是 | ❌ **没有** |
| v1.17.2 NRC / ok 判据 | 诊断 | ❌ |
| v1.17.3 协议锁定 / 日志 | 诊断 | ❌ |
| v1.17.4~5 平均油耗/续航/故障灯 | ❌ 无关 | — |
| v1.17.6 `ok=false` 也轮询 | ✅ 是 | ❌ 而且**引入了日志风暴** |
| v1.17.7 仪表盘不显示 | ❌ 无关 | ✅ 验过 |
| v1.17.8 扫描器导出 | ❌ 无关 | ✅ 验过 |
| v1.17.9 修我自己造的日志风暴 | 间接 | 部分 |
| v1.18.0 总里程 / 位图链 | ✅ 是 | ❌ **没有** |

**结论：9 个版本里只有 2 个碰了"能不能读到车"这件事，而且两个都没验过。**
其余是诊断、功能、以及**修我自己造出来的回归**。**有动作，没有收敛。**
而之所以没验过 —— 因为**我改的恰好是唯一验不了的东西**（没车、适配器也不在手边）。

### 然后去看了一个我一直没看的层：**BLE 的连接建立**

对比两份日志（**同一个适配器、同一个特征**）：

```
10-03 成功那次：  已写 CCCD → MTU 协商 → CCCD 写入完成 | status=0    ← 回调回来了
10-06 失败那次：  已写 CCCD → MTU 协商 → （没有「CCCD 写入完成」）   ← 永远没回来
```

**回调丢了。** 而 Android 的硬约束是：**同一连接同时只允许一个未完成的 GATT 操作**。
回调不来 → 栈上永远挂着那个描述符写 → **之后每一次 `writeCharacteristic()` 都返回 false**。

**于是 902 条"写入被拒"、900 条"超时无响应"、一条数据都没有** —— 全对上了。

### 根因在我们自己的代码里（一个 12ms 的竞态）

```kotlin
L193: runCatching { g.requestMtu(512) }   // GATT 操作 ①
L194: enableNotify(g)                      // 里面 writeDescriptor(cccd) → 操作 ②
```

**两个操作背靠背发，中间不等任何回调。** 第二个被丢弃、第一个的回调也可能丢。

**而且那个"兜底"是死代码**：

```kotlin
main.postDelayed({
    if (state == State.DISCOVERING) { ... }   // ← onMtuChanged 已把 state 推成 READY
}, 1200)
```

`onMtuChanged` 12ms 后就回来了、把 state 推成 READY ——
于是这个兜底**永远不触发**，App 照样宣布"已就绪"，然后开始疯狂写入。

> **这就解释了"时好时坏、改了很多版都不行"**：它是一个**竞态**。
> 10-03 那次运气好没撞上（日志里 `CCCD 写入完成` 是**有**的）→ 真数据流出来了。
> 而**我们一直在改协议层**（ATCAF0、NRC、ok 判据、位图链…），
> **凶手根本不在那一层。**

### 三处修复

| # | 修复 | 说明 |
|---|---|---|
| 1 | **串行化 GATT 操作** | 先 `requestMtu`，**在 `onMtuChanged` 里**才 `enableNotify`。两个操作不再重叠 |
| 2 | **让兜底真的会触发** | 判据从 `state == DISCOVERING` 改成显式的 `cccdPending` —— 后者不会被 MTU 回调提前改掉 |
| 3 | **回调丢了就重连，不要假装就绪** | 2 秒等不到 `onDescriptorWrite` → 判定"GATT 栈已卡死" → 记 E 日志 + **主动断开**（走既有自动重连）。重连过一次还失败就如实标"CCCD 未确认"，不假装正常 |

另外 `notifyStarted` 保证"开通知"这个操作**只发一次**（`onMtuChanged` 与兜底都会调它，
两个都发就又撞车了）；`onServicesDiscovered` 里复位三个标志（重连要能重来）。

### 这次的验证信号是**确定的**

上车（或适配器在手边）后看日志：

- ✅ **必须有** `CCCD 写入完成 | status=0`
- ✅ 之后**不应再有**成片的 `写入被拒` / `BLE 写入持续失败`
- ❌ 如果看到 `CCCD 回调丢失 —— GATT 栈已卡死`，说明还有别的东西在抢 GATT 操作

**这一条比之前所有"验证"都硬** —— 它不依赖主观判断，一行日志就能定论。

### 验证

| 项 | 结果 |
|---|---|
| Kotlin 单测 | **547 全过** |
| 构建守卫 | 通过 |
| APK | `dist/iCarOBD-debug-v1.18.1-android.apk`（versionCode 34）**已装到平板** |
| **真机复验** | ⚠️ **待做** —— 适配器不在附近（扫描扫不到、重连 `status=255`） |

### 教训（写给下一个接手的人）

1. **"改了很多版还是不行"通常意味着：凶手不在你一直在改的那一层。**
   我把 9 个版本摊开才看见——**2 个碰了真问题、0 个验过**。
2. **竞态的典型表现就是"时好时坏"**，而"时好时坏"最容易被误读成"某个命令/某个参数不对"，
   于是不停地改参数。**看到"有时能行"就该怀疑时序，而不是怀疑取值。**
3. **一个 `if` 判据用错变量，能让兜底静默变成死代码**（`state == DISCOVERING` 那条）。
   兜底代码**必须能被测试触发**，否则它只是让人安心的注释。

---
## v1.18.0 · 2026-10-06 · 外部资料研究：**挡位/总里程是标准 PID，不用等车**

用户给了 4 个参考（ELMduino、Wikipedia OBD-II PIDs、一个马自达 ND3 逆向项目、carscaner），
让我观摩并顺便找找别的。**收获很大，而且直接改了我们一个错误假设。**

### 🔴 最重要的一条：**我们犯了一个已被别人明确记录过的错**

马自达那个项目（[drewid74/2024-nd3-mazda-obdii](https://github.com/drewid74/2024-nd3-mazda-obdii)，
把读数与真实里程表对过）在「Dead Ends」一节里写：

> A Mode 22 NACK means *that module address is dead*, **not** that the signal is unavailable.
> … Gear position was previously (incorrectly) treated as unreachable **on exactly this reasoning
> — it was in `01 A4` the whole time.**
>
> **Always probe `01 00 → 01 20 → 01 40 → 01 60 → 01 80 → 01 A0 → 01 C0`**
> and enumerate what the car actually advertises **before** concluding anything is out of scope.

**我们犯的是同一个错**：把「挡位 / 总里程」归进"要厂家 Mode 22、要等车"那一堆。
它们其实**一直在标准空间里**。而且那个项目挖到底，Mode 22 只找到 **2 个**真正有用的信号
（机油温 `22 13 10`、刹车位置 `22 2B 0D`）—— **其余全在标准空间**。

### 落地一：`01 A6` 总里程（守卫 15 → 14）

| 来源 | 内容 |
|---|---|
| [Wikipedia OBD-II PIDs](https://en.wikipedia.org/wiki/OBD-II_PIDs) | `A6`（十进制 166）Odometer，4 字节，0~429,496,729.5 km，`(2²⁴A+2¹⁶B+2⁸C+D)/10` |
| 马自达项目 | 同一公式，且**与真实里程表对过**（原话 "drift matched real"） |

两处独立来源一致 → 已加 `std_A6`，别名 `obd.odo`，控件 `g_odo` 直接可用。
**这正是我 v1.17.6 说"查证不到、不敢加"的那条** —— 现在有权威来源了。

### 落地二：扫描器的位图链**停在 01 60，永远发现不了 A4/A6**

我们的扫描器**已经在走位图链**了（这一点原来做得对），但：

```kotlin
val maxBlock = if (mode == "09") 0x40 else 0x60   // ← 只到 0160
```

于是 **A1~C0 段永远枚举不到** —— 而挡位 `A4`、总里程 `A6` 就在那一层。
连带 `ScannerActivity` 的 Mode 01 默认范围也是 `00~60`，候选还要过一道 `from..to` 过滤，
**两处都得放宽**才有效。现在：`maxBlock → 0xC0`、默认范围 `00~C0`，
并抽成 `PidScanner.maxSupportBlock(mode)` + 回归守卫。

### 其他确认到的（不改代码，但值得记）

| 项 | 结论 |
|---|---|
| **响应前缀** | 马自达项目的「Response-Prefix Fix」说：**正响应 SID = 请求 SID + 0x40，别硬编码 `62`** —— **我们本来就是这么写的**（`matchData` 里 `(mode + 0x40)`）✓ |
| **`01 14` 氧传感器** | 该项目实测：ND3 上 **`0114` 根本不在支持位图里**，B1S1 是**宽域**传感器（走 `01 34` 的 lambda+电流）。我们 `std_14` 的说明原写"0.1~0.9V 来回跳是正常的" —— **对马自达是错的**，已改正 |
| **`01 65`** | 是**推荐挡位（换挡提示）**，**不是当前挡位**。别拿它当挡位用 |
| **`01 A4` 挡位** | Wikipedia：`A4`（164）Transmission Actual Gear，4 字节，单位 ratio，`(256C+D)/1000`，`[A1]==Supported`。马自达 README 补充**字节 B 是枚举的挡位状态**，但**值到挡位的映射"还需要在停车场慢速实测"** |
| 死路（别重复试） | EPS `0x730`、DSC `760/22 21 XX`（横摆/横向G）、`760/22 06 XX`（轮速）—— 都实测无响应 |

### ⚠️ `01 A4` 挡位**我没加**，原因说清楚

- **公式是标准且确认的**（ratio），但那个 ratio 是"齿比"（1.594/2.035/…），**当挡位显示没有意义**
- **要显示 P/R/N/1..6 需要字节 B 的枚举映射**，而它的唯一来源是一行
  **ND2 时代的 TCM 地址**（`22 1E 12`，项目自己标注 `deprecated` 且"不适用于 ND3"）：
  `16=1;32=2;48=3;64=4;80=5;96=6;50=N;60=R;70=P`
- 马自达项目对 `01 A4` 字节 B 的标注是 **`partial`**："value-to-gear mapping still needs
  a parking-lot creep test WHILE MOVING"

**拿一个"来源不适用 + 作者自己标未验证"的映射写进 PID 库，就是猜。** 按红线不猜。
**但它现在有了明确的下一步**（见迭代清单 P1-2）：
用 `map(B,70,0,60,1,50,2,16,3,32,4,48,5,64,6,80,7,96,8)` 把编码转成 0~8 序号，
配 `valueLabels = ["P","R","N","1","2","3","4","5","6"]`（**`g_gear` 模板里本来就写着这串**）——
**然后上车慢速实测确认映射**。我们 v1.17.0 做的 `valueLabels` 正好就是为它准备的。

### 验证

| 项 | 结果 |
|---|---|
| Kotlin 单测 | **547 全过**（+1：位图链必须到 `01 C0`） |
| 跨语言 | **104 项全过**（别名两侧 35 条一致） |
| 构建守卫 | 通过（**14** 条警告，比改前少 1 条 —— `g_odo` 修好了） |
| APK | `dist/iCarOBD-debug-v1.18.0-android.apk`（versionCode 33） |

### 遗留

- **`01 A4` 挡位的枚举映射待实测**（见上，方法已经明确）
- **`01 A6` 在阿特兹上是否支持待实测** —— 不支持时读到 NO DATA 进冷却，不会出错。
  上车先用扫描器跑一次 **`01 00 → 01 C0` 全链枚举**，一次就知道这台车到底支持什么
- **剩下 13 个指示灯**：按马自达项目的经验，**先在标准空间找**（`01 A0~C0` 段我们原来根本没枚举过），
  找不到再谈 Mode 22

---
## v1.17.9 · 2026-10-06 · 🔴 日志被写失败刷爆（**这是我 v1.17.6 引入的回归**）

用户问「我看你一直日志写入什么」—— 查了，**问得对**。

### 日志实际长什么样（2026-10-06，约 1 小时，**没接车**）

```
obd-20261006.log   343 KB / 3861 行
级别: W 1691  E 909  V 904  I 184  D 173      ← 警告+错误占 67%
```

按消息拆开：

| 条数 | 级别 | 消息 |
|---|---|---|
| **902** | E | `BLE 写入持续失败，已放弃本次数据` |
| **900** | W | `超时无响应` |
| **555** | W | `PID 连续失败进入冷却` |
| **191** | W | `写入被拒，切换写类型重试` |

**一条有效数据都没有。**

### 两个原因，一个是我的

**① 我 v1.17.6 改的 `ok=false 也启动轮询`** —— 本意是"不让假阴性把整条路堵死"，
但那只在**链路真的通**的前提下成立。传输层还在、**写不进去**时，它会一直空转：

```
[00:39:22] 状态变更 | READY 已就绪        ← GATT 连上了
[00:39:30] 初始化未通过（0100 无有效响应） | probe=      ← probe 是空的
[00:39:30] 初始化未通过，但仍启动轮询      ← 我的改动
[00:40:24] 轮询启动 | interval=120ms
[00:40:24] 写入被拒 | 写失败累计=96 …      ← 每条 PID 烧 5 次写重试 + 一个超时
```

**② `BLE 写入持续失败` 那条 E 没有节流** ——
`写入被拒`（W）**本来就有** 5 秒节流（所以只有 191 条），
但同一处的 E 是**裸 `AppLog.e`**，902 条全是它刷的。

> ⚠️ **`AppLog` 自带的重复抑制在这里帮不上忙**：extra 里有「写失败累计=N」，
> 每次都不同 → 去重键不同 → 抑制不了。**节流只能在调用点做。**
> 这是 v1.3.0 那场 57MB 事故的同一个机制。

### 两处修复

| # | 修复 | 位置 |
|---|---|---|
| 1 | **那条 E 纳入同一把节流闸**（W/E 共用一个 `lastWriteFailLog`） | `BleTransport` |
| 2 | **链路自检**：连续 **60** 次请求一次都没成功 → **停掉轮询**并说明原因 | `ObdEngine` |

第 2 条是"停掉比空转好"：日志干净了，用户也能从
`连续 60 次请求无一成功，已停止轮询` 这条**直接明白链路有问题**，
而不是对着一屏 `无有效响应` 猜。阈值 60 次 ≈ 十几秒 ——
够长到不误杀"刚连上还在协商"，够短到挡得住风暴；有用例钉着它的合理区间。

### ⚠️ 没查清的那一半：**为什么写入被拒**

证据摆在这里，但**我给不出结论**：

| 事实 | 出处 |
|---|---|
| **通知是通的** —— 适配器主动推了 `ELM327 v2.3` | `[00:39:22.995] RX \| ELM327 v2.3` |
| **写入从第一次就被拒**（`写失败累计=1`），两种写类型都试过 | `[00:39:30.195]` |
| **同一个适配器、同一个特征，在车上会话里写入是成功的**（真数据流出来了） | 见 v1.17.1 的实车日志 |
| 之后重连失败 `status=255`，再扫描**扫不到设备** | `[01:00:30]`、`[01:14:43]` |

所以**不是 UUID 配错**（2AF1 写过成功）。更像是**适配器侧的状态问题**
（未上电 / 半断的 GATT / 被别的中心占用）。

> **关于联网查文档**：按用户建议查了 Vgate iCar Pro 2S 的 BLE 资料，
> **没找到权威的 UUID 表**（搜到的都是论坛帖、非英语手册 PDF）。
> 而**设备自己吐的 GATT 表就是权威的**：
> `18F0` 下 `2AF0`=Notify+Indicate / `2AF1`=Write+WriteNoResponse ——
> 代码现在与它一致，且这个组合在车上会话里**被验证过能通**。
> 结论：**这一条不需要再查文档，需要的是把适配器插回车上再看。**

### 验证

| 项 | 结果 |
|---|---|
| Kotlin 单测 | **546 全过**（+1：链路自检阈值的合理区间） |
| 构建守卫 | 通过（1 条警告，仍是那 15 个控件 PID） |
| APK | `dist/iCarOBD-debug-v1.17.9-android.apk`（versionCode 32） |
| 实机 | 装到平板上；**新版启动后 7 分钟只新增 15 行日志、0 条写失败日志**（旧版约 47 行/分钟）；无崩溃无 ANR |
| **自检自停的实测** | ⚠️ **没验成** —— 适配器已不在附近（扫描扫不到、重连 `status=255`），而「初始化」按钮在非 READY 时是**灰的**（`btnInit.isEnabled = state == READY`），**无法构造"链路半死仍在轮询"的场景**。见遗留 |

### 遗留

- ⚠️ **链路自检的"自停"没有在真机上验过** —— 它需要"传输层 READY 但写不进去"的状态，
  而那个状态现在复现不了。**下次上车/适配器在手边时补验**：
  连上后点「初始化」，看是否在十几秒后出现
  `连续 60 次请求无一成功，已停止轮询`，且日志不再增长
- **写入被拒的根因**仍未知（见上）—— 需要适配器在车上时复看

---
## v1.17.8 · 2026-10-06 · PID 扫描器：加「导出结果」+ 澄清两件已有能力

用户问：「PID 扫描结果日志可以导出吗、还有实时扫描功能」。

### 先答：两件**其实都已经有**，但第一件不好用

| 问 | 答 |
|---|---|
| **实时扫描** | ✅ **一直就有**。`PidScanner.scan(cfg) { done, total, hit -> }` 是**逐条请求**回调：进度条、`进度 N/M`、命中**边扫边进列表**、日志逐行追加。间隔默认 150ms（限流），400 条约 60 秒 |
| **扫描结果能导出吗** | ⚠️ **能，但只能绕道**。命中**本来就写进了 App 日志**（模块 `SCAN`，含 `req/raw/data/min/max`），而「日志」页有「导出」—— 但那条路导的是**整份日志**（含所有模块、可能 2MB），想拿"这次扫描的结果"得自己翻 |

### 新增：扫描页的「导出结果」按钮

一份**自包含的文本报告**：扫描参数 + 命中明细 + 界面日志。

```
iCar OBD · PID 扫描结果
时间: 2026-10-06 00:31:12
模式: 22
范围: 1100 ~ 11FF
参数: 间隔=150ms 超时=1500ms 重试=1 上限=400 学习采样=0 支持位图=true
命中: 2 条

── 命中明细 ──
[1] Mode 22 PID 1100
    请求: 221100
    数据: 1A F8
    建议公式: ((A*256)+B)/4  （预览值 1726.0，仅供参考）
    学习量程: 0.8 ~ 4.2
    原始: 62 11 00 1A F8
...
── 界面日志（N 条）──
```

- **纯文本而不是 JSON**：目标是给人看 / 给下一个智能体读，命中就十几条，
  一眼看完比机器友好更重要（真要解析，字段顺序是固定的）
- **按钮在无命中时置灰** —— "导出个空文件"没有意义；命中一条就点亮（不必等整轮扫完）
- 报告拼装抽成**纯函数** `PidScanner.report(cfg, hits, logs, timestamp)`
  —— 格式最容易"看起来对"，而它是**交给别人读**的，缺字段就是白导一次

### 验证

| 项 | 结果 |
|---|---|
| Kotlin 单测 | **545 全过**（+9：报告格式 / 空结果 / 无配置 / 超长截断 / 模式宽度 / 编号顺序） |
| 构建守卫 | 通过（1 条警告，仍是那 15 个控件 PID） |
| APK | `dist/iCarOBD-debug-v1.17.8-android.apk`（versionCode 31，6.76 MB） |
| 实机 | 装到平板上，从 PID 页进扫描器：`开始扫描`/`停止`/`导出结果` 三个按钮都在，导出按钮正确置灰；**无崩溃** |

> 顺带一个踩坑记录：`adb shell am start -n com.icar.obd/.ui.ScannerActivity`
> **会被系统拒绝**（`Permission Denial: not exported`）——
> `ScannerActivity` 没导出，这是**对的**（内部页面不该被外部拉起）。
> 验证这类页面只能**从应用里走**（PID 页 →「PID 扫描器」），不能图省事直接 am start。

### 遗留

- 扫描结果**没有结构化格式**（JSON/CSV）。现在是人读的文本；
  如果以后要"扫描结果直接批量导入 PID 库"，那时再加 JSON 导出更合适

---
## v1.17.7 · 2026-10-06 · 🔴 修「普通/性能/自定义都不显示表盘」（用户实机报告）

### 用户报的现象

> 「仪表盘上普通性能自定义都不显示表盘」

实测（小米平板 5 / v1.17.6）：三种页签切来切去，屏幕上**始终是同一份 2 个节点的设计**，
套用 8 表预设也没有任何变化。

### 根因：**一份上一轮设备测试残留的 v2 设计文件压住了一切**

设备上 `settings.json` 里躺着这么一份 `designJson`（1471 字符）：

```json
{"schema":"icar.ui/2",
 "meta":{"name":"设备实测-多页面子部件","author":"auto","description":"v1.12.0 验证"},
 ...素材全指向 /data/data/com.icar.obd/files/test-assets/*.png}
```

而 `render()` 里它是**无条件优先**的：

```kotlin
val design = if (dj.isNotBlank()) DesignFile.parse(dj)?.design else null
if (design != null) { /* v2 节点树 */ } else { renderer?.render(spec, theme) /* v1 扁平表 */ }
```

于是：
- **「普通 / 性能」被劫持** —— 它们是内置布局，却也被这份设计文件顶掉
- **「应用预设」白做** —— 预设写的是 `Store.customGauges`（v1 扁平表），而 v2 永远优先

> 有意思的是 `applyPreset` 的注释里写着"顺手切到自定义页签，
> 停在普通/性能上会看不到任何变化，容易被当成没生效" ——
> **作者已经意识到这一类问题了**，只是没想到 v2 设计文件也在「自定义」这一层、而且优先级更高。

### 三处修复

| # | 修复 | 说明 |
|---|---|---|
| 1 | **`designJson` 只在「自定义」页签生效** | 语义应该是：普通/性能 = 内置布局；自定义 = 设计文件（有）或 `customGauges`（无） |
| 2 | **`applyPreset` 同时清掉设计文件** | 两者是「自定义」层的**两个来源，互斥** —— 同时存在必然有一个白写。清掉时记日志 + toast 告知 |
| 3 | **新增「清除导入的设计文件」入口** | 原来导进去**没有任何办法撤销**（只能再导一份覆盖），而它会一直压住预设 |

规则抽成了纯函数 `DashSpec.useDesignFile(type, designJson)` 并加了单测 ——
`render()` 在 Fragment 里测不了，而**"哪一层优先"恰恰是最该钉住的部分**。

### 顺带修：一个会静默失效的索引写法

「选择页面」原来用 `labels.size - 1` 反推索引（注释写"比硬编码索引稳"）。
但那假设了**它是唯一的条件尾项** —— 我这次在它后面加了一项，`labels.size - 1`
就会**抢走新项的索引**，而那一支在单页设计时什么都不做，表现为**"点了没反应"**。

改成显式索引 `pageIdx = themes.size + extras.size`（单页时为 -1，永不匹配）。

### 实测验证（装到平板上，逐个点）

| 页签 | 改前 | 改后 | 像素佐证 |
|---|---|---|---|
| 普通 | `渲染仪表盘(v2) \| nodes=2` | **`渲染仪表盘 \| type=0 count=8`** ✅ | 整屏仪表盘（有色像素 0.46%，改前 0.11%） |
| 性能 | 同上（被劫持） | **`type=1 count=8`** ✅ | — |
| 自定义 | `nodes=2`（残留测试设计） | **`type=2 count=8`**（清除后回到预设的 8 表）✅ | — |

**「清除导入的设计文件」也实测点了**：`已清除设计文件 | 回到 customGauges（count=8）`，
`designJson` 长度 1471 → **0**，无崩溃、无 ANR。

> 设备上那份残留设计已清除（**备份在 `stage/settings-backup-before-clear.json`**）。

### 验证

| 项 | 结果 |
|---|---|
| Kotlin 单测 | **536 全过**（+4：优先级规则） |
| 构建守卫 | 通过（1 条警告，仍是那 15 个控件 PID） |
| APK | `dist/iCarOBD-debug-v1.17.7-android.apk`（versionCode 30，6.74 MB） |
| 实机 | 三个页签逐个点过；清除入口点过；**无崩溃、无 ANR** |

### 遗留

- **残留测试数据没有被清理机制**：那份 `test-assets/` 目录和 `designJson` 是
  上一轮设备测试留下的，装新版 APK 不会清掉它。**以后在设备上做验证要记得收尾**
  （或者给个"恢复出厂布局"的动作）
- 总里程（`g_odo`）仍待查证 `01 A6`

---
## v1.17.6 · 2026-10-05 · 修一个**我自己上一版引入**的风险 + 一个被守卫抓到的编码坑

### 1. `ok=false` 现在也启动轮询（修 v1.17.2 的副作用）

v1.17.2 把 `ok` 的判据**加严**成"`0100` 真的解析出 4 字节位图"（原来只判"没看见错误关键字"）。
判据本身是对的，但它有一个**我当时没想到的副作用**：

```kotlin
if (r.ok) startPolling() else AppLog.e(...)   // ← ok=false 就完全不轮询
```

判据加严 → **假阴性概率变高** → 而假阴性会从"日志里报个错"放大成
**"明明能通却什么都不做"**。实车会话 B 恰恰就是 `ok=false` 却有真实数据。

现在改成**照常轮询**：真不通时由**总线负载保护**自动降频，
30 秒后的「轮询汇总」会明说「有值 0/N」—— **比静默不动更容易看出问题**。

> **教训：收紧一个判据时，要同时检查它的失败分支会做什么。**
> 我只改了判据，没看它下游接的是什么 —— 而下游是"什么都不做"。

### 2. ⚠️ 被守卫抓到的一个坑：**编辑工具会抹掉 `.ps1` 的 BOM**

改 `tools/run-all.ps1` 的超时之后，构建守卫当场报红：

```
❌ 8 个 .ps1 文件编码都正常        ← 这一条失败了
```

原因是**编辑工具把文件开头的 UTF-8 BOM 抹掉了**（首字节从 `EF BB BF` 变成 `<`）。
而 [`01-接手大纲.md`](01-接手大纲.md) §4.1 早就写着这条红线：
**无 BOM 的 `.ps1` 会被 Windows PowerShell 5.1 按 ANSI(GBK) 解码，
中文注释变乱码并吃掉行尾，把下一行代码并进注释里** ——
报错是 `Unexpected token '}'`，看起来像语法错，实际是编码问题（v1.10.1 实测栽过一次）。

**已恢复 BOM，守卫转绿。** 顺便说明：**这条守卫的价值不在"防我写错代码"，
而在"防工具悄悄改掉我没打算改的东西"。**

### 3. `tools/run-all.ps1` 超时收紧

420 / 600 → **240 / 240**。实测 Kotlin ~16s（冷启 37s）、浏览器 ~60s；
原值是"Gradle 会卡死"那个时代的产物，真卡住时白等 10 分钟。

### 没做的一件事（说明原因）

**总里程（`g_odo`）没加。** 线索是它可能对应标准 PID `01 A6`（SAE J1979 的 A1~C0 段）——
但**我查证不到可靠来源**（搜到的都是 PDF 摘要，不足以下结论）。
按红线「**厂家 PID 的号不要猜**」，**查不准就不加**，只记在这里等确认。

> 这和"要等车"不同：**它是"信息不足"**。信息不足时该做的是**标注未知**，
> 而不是先填一个看起来合理的值 —— 那会变成下一个 `ATCAF0`。

### 验证

| 项 | 结果 |
|---|---|
| Kotlin 单测 | **532 全过** |
| 构建守卫 | 通过（1 条警告，仍是那 15 个控件 PID；**编码检查已恢复绿**） |
| APK | `dist/iCarOBD-debug-v1.17.6-android.apk`（versionCode 29，6.74 MB） |
| 实车复验 | ⚠️ 待做（P0-5） |

---
## v1.17.5 · 2026-10-05 · 续航里程：那 16 处里**最后一个不用等车的**

> v1.17.4 发现"要等车"这个整体结论是错的（平均油耗 / 故障灯 MIL 都不用等）。
> 这一版把**同类误判的最后一个**也做掉了。

### 续航里程（`calc_range`）

```
续航 = 油量% × 油箱容量 ÷ 平均油耗(L/100km) × 100
```

三个输入**全都不需要厂家 PID**：油量是标准 `012F`、平均油耗是 v1.17.4 刚做的派生、
油箱容量是**用户设置**。

### 新增设置：油箱容量（L）

「连接」页 →「运行选项」→ **油箱容量（L）**。默认 50，**填 0 = 关闭续航**。

> **为什么必须问用户**：OBD 读不到油箱容量 —— 阿特兹 2.0/2.5 是 62L，紧凑车 40~50L。
> 猜一个数字会让续航**看起来像真的但差很多**，而用户是拿它规划加油的。

输入用 `doAfterTextChanged` 而不是焦点变化：改完直接按返回键时焦点事件不一定来，值会丢。
**清空输入框时不会把 0 存进去**（那会静默把续航关掉）。

### 三个前提缺一不可，缺了就显示 `--`

| 缺什么 | 什么时候会缺 |
|---|---|
| 油量 `012F` | 部分车不支持这个 PID |
| 平均油耗 | 还没跑够 0.5km（v1.17.4 的刻意设计） |
| 油箱容量 | 用户还没填（或填了 0） |

**不猜**是刻意的：续航是"照着它去加油"的数字，宁可显示 `--`。
上限夹到 1200km（满油 + 高速也就这个量级，再大就是配置填错了）。

### 效果

| 项 | 改前 | 改后 |
|---|---|---|
| 构建守卫警告（绑不存在的 PID） | 16 | **15** |
| 累计修好的控件 | 2 | **3**（平均油耗 / 故障灯 / 续航里程） |

### 验证

| 项 | 结果 |
|---|---|
| Kotlin 单测 | **532 全过**（+4：续航计算 / 三个前提各缺一次 / 上限夹取） |
| 跨语言 | **104 项全过**（别名两侧 **34** 条逐条一致） |
| 构建守卫 | 通过（**15** 条警告） |
| APK | `dist/iCarOBD-debug-v1.17.5-android.apk`（versionCode 28，6.74 MB） |

### 剩下 15 个：这次是**真的**要等车

13 个厂家 Mode 22 指示灯 + 总里程（`01 A6`，不是所有车支持）+ 挡位（枚举，且无标准 PID）。

> 📌 **复盘**：连着两版都在做同一件事 —— **把"要等车"这个结论一条条拆开验**。
> 18 → 15 里，有 3 个是**被整体归类误伤的**。
> **下次再写"这批都要等车"之前，先抽查一条。**

---
## v1.17.4 · 2026-10-05 · 两处**不用等车**的 P9 缺口：平均油耗 + 故障灯 MIL

> P9（非数值 PID 模型）的"模型"那一半在 v1.17.0 就做完了，
> 剩下的是"给 18 个控件找数据源"，一直以为**全都要等车**。
> 这一版发现**其中两个根本不用等** —— 要么是标准 PID，要么纯本项目就能算。

### 1. 平均油耗（`calc_avg_l100`）—— 纯派生，不依赖任何厂家 PID

```
平均油耗 = 累计用油 ÷ 累计里程 × 100
```

- **累计用油**：`calc_lh`（L/h）对时间积分 → L。而 `calc_lh` 要么来自标准 PID `015E`，
  要么由 MAF（`0110`）推算 —— **两条路都不需要厂家地址**
- **累计里程**：`calc_km`（车速积分），本来就有

放在 `Derived.integrateDistance()` 而不是 `computeAll()`：它需要 `dt` 才能把 L/h 积成 L，
而 `computeAll` 算的是瞬时量。同一个 `dt` 也让**里程与油量的时间基准一致** ——
两边用不同的 dt，平均油耗会慢慢漂。

**两个刻意的取舍**：

- **里程 < 0.5km 时不出值**：0.2km 上用了 0.05L 会算出 25L/100km 这种噪声，
  一上路就显示"25 个油"比先显示 `--` 更糟
- **怠速时平均油耗上升是正确行为**（烧油不走路），有用例专门钉着，
  免得以后有人把它当 bug"修掉"

### 2. 故障灯 MIL（`std_01`）—— **标准 PID，不用扫描器实测**

Mode 01 PID 01 的字节 A：bit7 = 故障灯亮/灭，低 7 位 = 故障码条数。
公式直接写 `bit(A,7)`（公式引擎本来就有 `bit()` 函数）。

> **它是布尔，不是连续量** —— 而这正是 P9 方向 A 里**不需要映射表**的那一类：
> `min=0, max=1, warnHigh=0.5` 就够，值 1 会走成 critical，
> **指示灯的既有三态图直接可用，零新代码**。
> 这一条正好把 [`12-主题设计大纲.md`](12-主题设计大纲.md) §2.110 里
> "布尔不需要 valueLabels"的说法**在真代码里验证了一遍**。

### 效果

| 项 | 改前 | 改后 |
|---|---|---|
| 构建守卫警告（绑不存在的 PID） | 18 | **16** |
| 真正能用起来的控件 | — | `g_avgfuel` 平均油耗、`lamp_engine` 发动机灯 |

### 验证

| 项 | 结果 |
|---|---|
| Kotlin 单测 | **528 全过**（+9：里程积分 / 单位换算 / 短里程不出值 / 怠速行为 / MIL 位提取 / 两个 PID 定义） |
| 跨语言 | `verify-crosslang.js` **104 项全过**（别名两侧 **32** 条逐条一致） |
| 构建守卫 | 通过（**16** 条警告，比改前少 2 条） |
| APK | `dist/iCarOBD-debug-v1.17.4-android.apk`（versionCode 27，6.74 MB） |

### 剩下的 16 个：**确实要等车**

| 类别 | 数量 | 为什么必须等车 |
|---|---|---|
| 指示灯 | 13 | ABS / ESP / 胎压 / 气囊 / 安全带 / 车门 / 玻璃水 / 保养 / 车道 / 碰撞 / 制动液 / 刹车片 —— 都是**厂家 Mode 22**，号必须扫描器实测 |
| 数值类 | 3 | 续航里程（需要油箱容量配置）、总里程（`01 A6` 不是所有车都支持）、挡位（枚举，且无标准 PID） |

> ⚠️ **"绑对了"和"能读到值"是两件事**：`std_01` 与 `calc_avg_l100` 现在**绑对了**，
> 但**能不能拿到数值仍然要在车上验证** —— MIL 要车真有故障码才亮，
> 平均油耗要真的跑起来才准。**模型通了 ≠ 数据到了。**

---
## v1.17.3 · 2026-10-05 · 协议搜索竞态 + 让成功路径可见（**但不刷屏**）

> 继续清 v1.17.1 实车日志暴露的遗留。这一版把最后两条也收了。

### 1. 协议搜索竞态（实车 5 次 `STOPPED` 的来源）

`ATSP0`（自动）下，**第一次真实请求才会触发协议搜索**，搜索期间适配器回 `SEARCHING...`。
此时立刻开始轮询会**打断搜索**并拿到一串 `STOPPED` —— 实车日志正是如此
（`0100` 的响应里带 `SEARCHING...`，之后 5 次 `STOPPED`）。

**修法**：初始化末尾（自动协商时）**等协议锁定**再返回。
判据抽成纯函数 `ObdProtocol.protocolLocked()`：

| `ATDPN` | 含义 | 锁定？ |
|---|---|---|
| `A0` | 自动协商，**协议还没定下来** | ❌ |
| `A6` | 自动协商，已锁定到协议 6（ISO 15765 CAN 11/500） | ✅ |
| `6` | 用户显式指定了协议 6 | ✅ |

最多试 6 次 × 700ms ≈ 4.2 秒。**超时不报错、只警告** ——
协议没锁定时未必什么都拿不到（实车会话 B 就是在未锁定状态下偶然拿到数据的），
拦住不让轮询反而更糟。

> 为什么不用"响应里还有没有 `SEARCHING...`"当判据：那要**重发一条真实请求**，
> 而那正是会打断搜索的动作。`ATDPN` 是只读的。

### 2. 成功路径可见了 —— 但**刻意低频**

改之前：**失败会大声记，成功一个字都不记**。所以"到底有没有解析成数值"
从日志里看不出来（2026-10-05 排障时卡住的地方）。

新增两处，都是**有界**的：

| 日志 | 频率 | 上限 |
|---|---|---|
| `首次拿到数值 \| id=std_05 name=冷却液温度 value=92℃` | 每条 PID **只报一次** | ≈ PID 条数（约 20 行） |
| `轮询汇总 \| 有值 6/20 \| 车速=0km/h 冷却液温度=92℃ …` | 每 30 秒一行 | 120 行/小时 |

> ⚠️ **为什么必须低频**：轮询是 ~8Hz × 20 条，**每条都记会重演 v1.3.0 的事故**
> （实车 2 小时刷出 **113 万行 / 57.9MB**，把日志页一起拖崩）。
> `AppLog` 的四条自我保护挡的是**异常路径**刷屏 ——
> **正常路径的刷屏它挡不住**：每条读数都不一样，重复抑制用不上。
>
> 所以 `SUMMARY_MS` 故意**不是 private**，并有一条用例钉着"**不得低于 10 秒**"
> （`ObdEngineLoggingTest`）。下一个想"看得更勤"的人会先撞上它。

汇总行还是"数据到底通没通"最直接的判据：有值时 `有值 6/20 | …`，
一条都没有时给**警告级**的 `有值 0/20 —— 一条都没成功过`。

### 验证

| 项 | 结果 |
|---|---|
| Kotlin 单测 | **519 全过**（+5：协议锁定判据 4 条 + 不刷屏守卫 1 条） |
| 构建守卫 | 通过（1 条警告，仍是那 18 个控件 PID） |
| APK | `dist/iCarOBD-debug-v1.17.3-android.apk`（versionCode 26，6.74 MB） |
| 实车复验 | ⚠️ **待做**（P0-5） |

### 至此 v1.17.1 实车日志的遗留清单**清空**

| # | 问题 | 状态 |
|---|---|---|
| 1 | `初始化完成 ok=` 与实际可用性无关 | ✅ v1.17.2 |
| 2 | 否定响应 `7F <服务> <NRC>` 被吞成"无有效响应" | ✅ v1.17.2 |
| 3 | 协议搜索竞态（`SEARCHING...` 时立刻轮询 → `STOPPED`） | ✅ v1.17.3 |
| 4 | App 从不记录成功的数值 | ✅ v1.17.3 |

**剩下的只有上车复验。**

---
## v1.17.2 · 2026-10-05 · 让「数据不通」能被自己看出来（NRC 上报 + 探测加严）

> 承接 v1.17.1。那次能查出 `ATCAF0`，靠的是**日志里有完整 TX/RX** ——
> **不是靠 App 的报错**。这一版补的就是那个缺口。

### 1. 否定响应不再被吞掉（**最重要的一条**）

改之前：ECU **明确拒绝**（`7F <服务> <NRC>`）和「总线上没人回答」
**都被归成同一句 `无有效响应`**。2026-10-05 的实车日志里
**29 条否定响应全被吞掉** —— 其中就有根因的指纹 `7F 11 13`（NRC 0x13 报文长度错误）。

现在 `ObdProtocol.negativeReason()` 把它翻成人话：

```
ECU 拒绝 | 服务=0x11 NRC=0x13 报文长度或格式错误
```

**只报十六进制不够**，所以加了一张 ISO 14229 常用 NRC 表
（`0x13` 报文长度错误 / `0x78` 响应挂起 / `0x7F` 当前会话不支持该服务 …）。
查不到的码**如实标「未知 NRC」**，不编一个说明。

> ⚠️ 有个反直觉的细节值得记：请求 `01 11`，ECU 回的却是 `7F 11 13` ——
> **服务字节是 0x11 而不是 0x01**。因为当时开着 `ATCAF0`，发出的帧没有 PCI 字节，
> ECU 把第一个数据字节 `01` 当成了长度、把 `11` 当成了服务。
> **「服务号对不上」本身就是畸形请求的指纹**，所以这里**如实报 ECU 说的服务号**，不做纠正。

**判据（为什么不误报）**：`negativeReason` **只在 `extractData` 已经失败之后才调用** ——
此时串里的 `7F xx yy` 几乎只可能是否定响应。
`NO DATA` / `CAN ERROR` / `STOPPED` 里没有十六进制，扫不出东西，
仍然回落成 `无有效响应`；数据字节里**碰巧**有 `0x7F` 的肯定响应（如燃油液位 `41 2F 7F`）也有用例钉着不误报。

### 2. `初始化完成 ok=` 现在有确切含义，并补了一次**真实 PID 探测**

改之前：`ok = 响应里没有错误关键字`。于是实车会话 A 里
`0100` 回了 `SEARCHING... 064100981A800300`（没有错误关键字）→ **`ok=true`**，
**但之后每条 PID 都失败**。

改之后：

| 改动 | 说明 |
|---|---|
| `ok` 判据加严 | 要求 `0100` **真的解析出 4 字节位图**，不再是"没看见错误关键字" |
| 日志文案 | 改成 `ok=…（只代表 0100 有响应，不代表后续轮询可用）`，免得下一个人再被它带偏 |
| **新增探测 2** | 再试一个**轮询真正会用的** PID（`01 0C` 转速，OBD-II 强制支持） |

`0100` 通过而 `01 0C` 不通过时，打一条明确的警告：

```
[OBD][W] 探测通过但真实 PID 无响应 | 01 0C → NO DATA | 请求可能没被 ECU 接受（检查 ATCAF / 协议设置）
```

> **这一条如果早就有，那次实车故障不需要翻 TX/RX 就能定位。**

只报警告、**不改 `ok`**：某些车 / 某些状态下某个 PID 可能确实不回，
算成"初始化失败"会误伤（而且 `ok=false` 会让轮询根本不启动）。

### 验证

| 项 | 结果 |
|---|---|
| Kotlin 单测 | **514 全过**（+6：否定响应识别 / 未知 NRC / 不误报 / `parse` 接线） |
| 测试数据 | 断言用的是**实车日志里的原样字符串**（`037F111300000000` 等），不是编的 |
| 构建守卫 | 通过（1 条警告，仍是那 18 个控件 PID） |
| APK | `dist/iCarOBD-debug-v1.17.2-android.apk`（versionCode 25，6.74 MB） |
| 实车复验 | ⚠️ **待做**（与 v1.17.1 一起复验） |

### 仍留在遗留清单里的

- **协议搜索竞态**：`0100` 响应里带 `SEARCHING...` 时 App 立刻开始 120ms 轮询，
  适配器回 `STOPPED`（实车 5 次）。建议首次轮询前确认协议已锁定
- **App 从不记录成功的数值** —— `RULE` 整份日志只触发 1 行（启动时加载规则），
  所以"到底有没有解析成数值"从日志看不出来

---
## v1.17.1 · 2026-10-05 · 🔴 **实车首次跑通数据链路** + 修掉卡了很久的 `ATCAF0`

> **这是项目第一次真正从车上取到数据。**
> `接手大纲` §1 长期写着「数据链路从未真正跑通过 —— 还没从车上取到过一个字节」，
> **这句话可以改了**。

### 实车日志（`ver=1.15.0`，IOS-Vlink + ELM327 v2.3，SDK 36 设备）

用户提供的完整会话日志里，**两条会话的差别只有一处**：

| 会话 | `ATRV` | `01 11`（节气门）的响应 | 结果 |
|---|---|---|---|
| **A** 初始化跑完（含 `ATCAF0`） | 14.6V | `03 7F 11 13` → **NRC 0x13 报文长度错误** | **70 秒 100% 失败**；20 个 PID 全进 30 秒冷却；总线负载保护把轮询降频到 3.375x |
| **B** 初始化中途中断（`ATCAF0` 没发出去） | 14.5V | `41 11 28` → 节气门 **15.7%** | **立刻拿到真实数值** |

会话 B 的实际读数（**全部自洽，不是巧合**）：

| PID | 原始响应 | 解出的值 |
|---|---|---|
| `01 0D` 车速 | `41 0D 00` | **0 km/h** |
| `01 05` 冷却液 | `41 05 84` | **92 ℃** |
| `01 42` 电压 | `41 42 38 48` | **14.4 V** |
| `01 04` 负荷 | `41 04 3B` | **23.1 %** |
| `01 11` 节气门 | `41 11 28` | **15.7 %** |
| `01 0F` 进气温度 | `41 0F 62` | **58 ℃** |

> 电压 14.4V + 负荷 23% + 水温 92℃ + 节气门 15.7% —— 这是**热车怠速**的样子。
> 初始化本身也全绿：`ATZ/ATE0/ATL0/ATS0/ATH0/ATAT1/ATSP0` → `OK`，
> `ATDPN` → `A0`，`ATRV` → `14.6V`，`0100` → 真实的支持位图 `98 1A 80 03`。

### 根因：`ATCAF0`（`ObdProtocol.kt`）

`ATCAF0` 关掉 CAN 自动格式化后，ELM327 **发出的请求也不再补 PCI 字节** ——
`01 11` 这种正常请求在 ECU 看来是**畸形帧**，于是回 NRC 0x13
（incorrectMessageLengthOrInvalidFormat），或干脆 `NO DATA`。

会话 B 里 `ATCAF0` 没发出去（初始化中断），CAF 保持**出厂默认（开）**，
同一个请求就正常了 —— **变量只有一个，因果清楚**。
另有两条独立佐证：会话 A 的响应带 PCI 前缀（`064100981A800300`），
会话 B 的不带（`41 0D 00`）；且会话 B 的回显是**开着**的
（`01 0D 41 0D 00`），证明那次初始化连 `ATE0` 都没生效。

**修法**：删掉那一行。复位（`ATZ`）后 ELM327 默认就是 CAF1，
所以**不需要写 `ATCAF1`**（非 CAN 协议会回 `?`）。

**为什么当初会加**：注释写的是"保留原始字节，便于自定义 PID / ISO-TP 多帧重组"。
但 `matchData` 本来就是**扫描「响应模式 + PID」**，带不带 PCI 前缀都能认 ——
**解析器两种格式都兼容，CAF0 从一开始就不是必需的**。

### 顺带修：已知 UUID 表把写 / 通知写反了

日志每次连接都打一条：

```
[BLE][W] 已知 UUID 属性不符，改用属性配对 | svc=000018f0 notify=WnW write=NI
```

而实车 GATT 表是 `2AF0 = NI（通知）` / `2AF1 = WnW（写）`。
`BleTransport.KNOWN` 那条写成了（通知 2AF1，写 2AF0）—— **反的**。
属性配对兜住了（所以能连上），但表本身错了会让人以为"这适配器不标准"。
**文档同步更正**：`接手大纲` §4.3 里写的「写 2AF0 / 通知 2AF1」也是反的。

### 补充：同一份日志的**后半段**（20:47:48 起全是 `CAN ERROR`）

不是同一个 bug，别混起来：**用户在界面上把协议从「自动」改成了 `8`（CAN 11bit 250k）**，
而这台车是 **CAN 11bit 500k**（会话 B 的 `ATDPN` 已经自检出来了）。
波特率对不上 → 适配器回 `CAN ERROR`（178 条，占整份日志全部的 error 行）。

**教训（对排障有用）**：`CAN ERROR` 强关联"协议不对"；
而 NRC `7F xx 13` 是"帧本身畸形"。两者**指向完全不同的方向**，
日志里却都被归成同一个 `无有效响应`。

### ⚠️ 一个观测缺口：App **从不记录成功的数值**

`RULE` 模块整份日志只有 1 行（启动时 `规则已加载 | count=5`），**一次都没触发过** ——
这**与成功并不矛盾**（怠速下：车速 0、水温 92℃ < 105℃ 报警线、
电压 14.4V < 15.2V、负荷 23%，确实一条规则都不该触发）。

但它也说明：**"App 到底有没有把响应解析成数值"从日志里看不出来** ——
失败会大声记，成功一个字都不记。
按 `matchData` 的算法（扫描「响应模式 + PID」），`01 0D 41 0D 00` 里的
`41 0D 00` 是能被提取的，**但这是推断，不是观测**。
所以 **"仪表盘上真的显示了"仍然需要目视确认**。

### 验证

| 项 | 结果 |
|---|---|
| Kotlin 单测 | **508 全过**（+1：`初始化不得关闭 CAN 自动格式化` 回归守卫） |
| 构建守卫 | 通过（1 条警告，仍是那 18 个控件 PID） |
| APK | `dist/iCarOBD-debug-v1.17.1-android.apk`（versionCode 24，6.74 MB） |
| **实车复验** | ⚠️ **待做** —— 改的是"**发出去的请求**"，**只能在车上验证** |

### 遗留（日志里暴露、但本轮**没修**的）

1. **`初始化完成 ok=true/false` 与实际可用性无关** —— 会话 A `ok=true` 却 100% 失败，
   会话 B `ok=false` 却数据正常。**这个标志会误导排障**（我先被它带偏了一次）
2. **否定响应（`7F <svc> <pid> <nrc>`）被归成"无有效响应"** ——
   App 分不清"ECU 说不行"和"没人回答"。会话 A 里 **29 条否定响应全被吞掉**，
   否则 NRC 0x13 当场就能定位
3. **协议搜索竞态**：`0100` 的响应里带 `SEARCHING...` 时 App 立刻开始 120ms 轮询，
   适配器回 `STOPPED`（5 次）。建议首次轮询前确认协议已锁定
4. **`01 2F`（燃油液位）→ NRC 0x7F**（serviceNotSupportedInActiveSession）——
   这台车不支持，属正常；但它和"超时"混在同一个失败率里，会污染负载保护判定

### 下次优化建议

- **上车复验 v1.17.1**：重点看**头 10 秒**有没有数据（原来要等 70 秒）
- **把上面第 1、2 条修掉** —— 它们让"数据不通"**难以定位**：
  这次能查出来靠的是日志里有完整 TX/RX，**不是靠 App 的报错**
- 第 3 条：`SEARCHING...` 出现时等一轮再开始轮询

---
## v1.17.0 · 2026-10-05 · 非数值 PID 模型（方向 A）：数值 → 文字映射表

### 解决什么

主题工具里 **18 个控件绑着不存在的 PID**。根因不是"忘了配 PID"，
而是**模型缺一类数据**：现有 PID 是 `min~max` 的**连续数值**，
塞不进 `P/N/R/D`（枚举）、亮/灭（布尔）、`P0301`（文本）。

用户拍板**方向 A**：**值仍然是一个数，显示时查一张映射表**。

### 新增

| 位置 | 内容 |
|---|---|
| `data/ValueLabels.kt` | **纯模型**：`labelFor` / `isUsable` / `parse` / `toJson` + `MAX = 32` |
| `GaugeItem.valueLabels` | 仪表节点的映射表（空 = 不用映射） |
| `BaseGaugeView.format()` | **唯一入口**：先查映射表，没有才走数字格式化 |
| `BaseGaugeView.primaryFormat()` | 同上（多值表的读数走这条） |

### 为什么放在 `format()` 一处

圆表 / 条形表 / 数字表 / 折线表 / G力表 / 多值表**全都调这一个函数**。
放到这里而不是各视图各判一次 —— **6 处判定迟早分叉**。
本项目在"报警配色"上已经栽过一次（v1.10.1 把它收敛成 `alertColor()` 一处）。

### 语义（与工具侧 `valueLabelFor` 逐字一致）

| 情况 | 结果 |
|---|---|
| 空表 / 全空串 | 不用映射（读数按量程格式化） |
| 值是 NaN / null | `--` |
| `round(value)` 越界 | 夹到 `0..size-1` |

> ⚠️ **必须 `round` 而不是截断**：`4.999` 是"第 5 挡"，
> 截断会写成 4 —— 指针已经指在第 5 挡的位置，**两者都不报错**。
> `ValueLabelsTest` 有一条专门的用例钉着它。

### 兼容性

- **旧文件完全不变**：没有 `valueLabels` 字段 → 空表 → 数字格式化（老行为）
- **回写时不写空字段** —— 旧版本 App 打开新文件不会看到不认识的键

### 验证

| 项 | 结果 |
|---|---|
| Kotlin 单测 | **507 全过**（+12：`ValueLabelsTest`） |
| 浏览器套件 | 22 个套件 / **848 断言**全过 |
| 跨语言 | `verify-crosslang.js` **104 项全过**（+1：`MAX` 两侧一致） |
| 构建守卫 | 通过（1 条警告，仍是那 18 个 PID） |
| APK | `dist/iCarOBD-debug-v1.17.0-android.apk`（versionCode 23，6.74 MB） |
| 装机 | ⚠️ **未验证** —— 见「遗留」 |

### 遗留

- 🔴 **v1.17.0 未装机验证**：构建/归档完成时目标平板 `7e7d7bb4` 已从 adb 断开
  （当时挂的是另一台设备 `2G0YC1ZF9V0J48`，**没有装到它上面** ——
  验证设备是小米平板 5，不擅自往未知设备装）。下次接上平板后补：
  `adb -s 7e7d7bb4 install -r -d dist/iCarOBD-debug-v1.17.0-android.apk` + 查崩溃
- **文本型数据（故障码）不支持** —— 需要方向 B
- **`value` 部件级映射不支持** —— 只有仪表节点级
- **18 个控件仍绑不到真 PID** —— 模型通了，但**数据源还没有**
  （厂家 Mode 22 必须用扫描器实测；部分量可能根本不通过 OBD 暴露）

---
## v1.16.0 · 2026-10-05 · 补 3 个标准 PID + 5 条控件别名 + 修 3 处控件绑错 PID

### 新增：3 个标准 OBD PID（两侧同步）

| id | 名称 | 公式 | 量程 | 备注 |
|---|---|---|---|---|
| `std_0A` | 燃油压力 | `A*3` | 0~765 kPa | 燃油泵供油压力 |
| `std_22` | 燃油轨压力 | `((A*256)+B)*0.079` | 0~5178 kPa | 相对进气歧管的轨压 |
| `std_14` | 氧传感器电压 | `A/200` | 0~1.275 V | B1S1；0.1~0.9V 来回跳是正常的 |

配套 `DesignFile.PID_ALIASES` 加 3 条（`obd.fuelPressure` / `obd.railPressure` /
`obd.o2voltage`），并同步 `tools/theme-studio/js/schema.js`。

### 新增：2 个厂家模板（默认关闭）

`tpl_oilPressure`（机油压力）/ `tpl_afr`（宽域空燃比）。**PID 号是占位示例**，
与既有 `tpl_*` 一样默认 `enabled=false` —— 必须先用扫描器实测。

### 修复：3 处控件模板绑了不存在的 PID

`tools/theme-studio/js/presets.js` 里三个控件绑的名字在 PID 库里不存在，
而所有仪表的 `make()` 都是"查不到就用 `min=0/max=100` 兜底" ——
于是它们**静默退化成普通数字表 / 永远不亮的灯**：

| 控件 | 改前 | 改后 | 为什么 |
|---|---|---|---|
| `lamp_fuel` 燃油报警 | `obd.fuel` | `obd.fuel_level` | 燃油液位 `std_2F`（`warnLow=15`） |
| `lamp_charge` 充电提示 | `obd.charging` | `obd.voltage` | 控制模块电压 `std_42`（`warnLow=11.8`） |
| `gauge_parts_fuel` 拼装条形油量 | `obd.fuel` | `obd.fuel_level` | 同上 |

> ⚠️ **修法是改控件模板用规范名，不是给别名表加名字。**
> 别名表是一条**双射**：每个默认启用的内置 PID 恰好一个别名。
> 我一开始想"加两条别名指向同一个 PID"，被两个测试当场拦住 ——
> `DesignFileTest.别名表本身没有重复目标`（不许两个别名指向同一 PID）
> 与 `ThemeStudioSampleTest.别名数量与内置启用 PID 数量一致`（条数必须相等）。
> **这两个测试是有意的**，不是形式主义：别名一多，"该用哪个名字"就没人说得清。

### 修复：`docs/12-主题设计大纲.md` 的结构损坏（文档修复）

发现这份**架构权威文档**被一次错误的插入破坏了：

| 现象 | 证据 |
|---|---|
| §一 出现两次 | 内容逐字节相同 |
| §二 出现两次，且**两份互补** | A 有 2.42 / 2.44~2.109（85 节），B 有 2.4 / 2.7 / 2.9~2.22 / 2.35~2.43（42 节），共有 18 节 |
| **一份文件头被插进 §2.42 正文中间** | `1. **\`# 主题设计系统 · 设计大纲` —— 把 "1. **⟨短语⟩" 里的短语吃掉了 |
| 被吃掉的**后半截**被挤到 B 的 §2.23 末尾 | `" 是精确匹配** —— 加 \`box_card\` ..."` |
| 42 行相邻重复行 | 40 个 `### ` 标题 + 2 行引用 |

**修复方式**：写一次性脚本（`stage/fix-outline.ps1`）把两份互补副本合并成
完整的 **2.1 ~ 2.109**，去掉重复行，并把被挤走的片段放回 §2.42。

**验证**（可复现，不是"看着对"）：

| 判据 | 结果 |
|---|---|
| 小节数 | **109**（2.1~2.109 一个不缺、无重复） |
| 与原文逐节比对 | 除 §2.42 外，37 节**只差被有意去掉的重复行**，**0 处无法解释的差异** |
| 尾部 §三~§九 | **302 行逐字节一致** |
| 相邻重复非空行 | 0（原 42） |
| 编码 / 换行 | 无 BOM、纯 LF（与原文一致） |
| 行数 | 2868 → 2371 |

> ⚠️ **§2.42 的 item 1 有一处短语是重建的，不是原文。** 原文被文件头覆盖，无法还原。
> 依据是同节代码块里的 `// ← 精确匹配` 注释与残留的 `" 是精确匹配**"`，
> 重建为 `` `^(group|image|text)$` ``。**这是推断。**
> 原文件备份：`stage/主题设计大纲.md.orig`（在 `.gitignore` 里，不进版本控制）。

### 验证

| 项 | 结果 |
|---|---|
| Kotlin 单测 | **495 全过**（25 个测试文件） |
| 浏览器套件 | **22 个套件 / 847 断言全过** |
| 跨语言比对 | `verify-crosslang.js` **103 项全过**（别名表两侧 30 条逐条一致） |
| 构建守卫 | 通过（**1 条警告**，见遗留） |
| 装机 | v1.16.0（versionCode 22）安装成功；静置 35 秒后**进程存活、崩溃缓冲空、ANR 0**；日志 `===== iCar OBD 启动 ===== | ver=1.16.0`、`渲染仪表盘(v2) | nodes=2 page=0/2` |

### 遗留

- 🔴 **18 个控件仍绑着不存在的 PID**（守卫警告，v2.61.0 起就是存量债务）。
  其中 14 个是**指示灯**（ABS/ESP/胎压/气囊/安全带/车门/玻璃水/保养/车道/碰撞…），
  4 个是数值类（续航里程 / 总里程 / 挡位 / 电池电量）。
  **它们卡在同一个设计决定上**：「布尔 / 枚举 / 文本型数据怎么进 `min~max` 数值模型」——
  挡位（P/N/R/D）与故障码是同一类问题。三个候选方向见
  [`tools/theme-studio/CHANGELOG.md`](../tools/theme-studio/CHANGELOG.md) v2.60.0，
  （📌 该目录 v2.83.0 起已改名 `tools/icarui/` —— 见 [`tools/icarui/CHANGELOG.md`](../tools/icarui/CHANGELOG.md)；
  上面那个链接是**当时的路径**，保留原样以保持历史可追溯）
  **等这个决定才能往下做**（决定了之后守卫从 `Warn` 改成 `Fail`）
- `dist/iCarOBD-debug-v1.15.0-android.apk` **未删除** —— v1.15.0 是「首个公开版本」，
  按约定应上传 GitHub Releases 后再删本地包；未经确认不做不可逆删除
- 上一轮（10-05）主题工具 v2.15.0 ~ v2.73.0 的工作**仍未提交**（git 只有根提交）

---

## v1.15.0 · 2026-10-05 · 首个公开版本（补记）

> ⚠️ **本条是补记**：这一版当时没有写 CHANGELOG，条目内容由根提交
> （`6c81252 v1.15.0: 首个公开版本`，2026-10-05 03:13）与 `.gitignore` 的注释还原。

- 项目**首次公开**：初始化 git 仓库，`main` 分支一个根提交
- `versionCode 21` / `versionName 1.15.0`；APK 6.74 MB（单 ABI `arm64-v8a`）
- **APK 不进 git**：`.gitignore` 忽略 `dist/`，发版时把 APK 作为
  **GitHub Releases 附件**上传（理由：每版 6.7 MB，20 版就是 134 MB，
  且会永久留在历史里，想删只能改写历史）
- `00-README.md` 面向使用者的安装说明更新到 v1.15.0

---

## v1.14.0 · 2026-10-04 · **六种表全接霓虹**（P7-8）

### 问题

`BaseGaugeView` 早就有 `neon` 实例，但**只有圆表和条形表在用** ——
数字表 / 折线表 / 多值表 / G力表在霓虹主题下是**哑的**：
配色变了，但没有一点辉光，和另外两种表放在一起很割裂。

### 做法：五个共用助手，而不是六份辉光循环

`BaseGaugeView` 新增：

| 助手 | 用途 |
|---|---|
| `neonBar` | 发光进度条（数字表底部条 / 多值表各条） |
| `neonText` | 发光文字（数字读数 / 折线当前值 / 多值读数） |
| `neonLine` | 发光线段（G力十字线） |
| `neonDot` | 发光圆点（G力球） |
| `neonPath` | 路径辉光（折线轨迹 —— 几十个点逐段 bloomLine 太贵） |

> **为什么必须抽出来**：6 个视图各写一遍辉光循环的话，层数、扩散、
> `glow` 开关的判定迟早分叉 —— 圆表亮一点、数字表暗一点，用户看得出。

### 关掉霓虹 = 零额外绘制

每个助手都有守卫（`if (on)` / `if (palette.glow)` / `if (!on) return`）。
**有测试钉住这一点** —— 辉光是纯装饰，关掉必须真的不做功。

### 多值三兄弟自动受益

`DualStackGaugeView` / `QuadGaugeView` / `SubDualGaugeView` 只有 ~40 行，
它们**委托给 `MultiValueGaugeView`** —— 所以接了那一个，三个都有了。

### 新增契约测试 `NeonCoverageTest`（4 条）

霓虹是纯绘制，像素级验证要真机。但真正容易出的问题不是"画得对不对"，
而是 **"新加了一种仪表，忘了给它接霓虹"** —— 那种表在霓虹主题下是哑的，
**而且没有任何测试会失败**。

所以检查四个静态事实：

1. 每个仪表视图都**至少调用一次**霓虹绘制
2. 五个助手都定义在 `BaseGaugeView`（不是各视图各写一份）
3. 关掉霓虹时助手**直接跳过**（不做白工）
4. 多值三兄弟确实委托给 `MultiValueGaugeView`

### 验证

| 项 | 结果 |
|---|---|
| Kotlin 单测 | **461 全过**（+4 霓虹契约） |
| 浏览器 17 套件 | **622 断言全过** |
| 构建守卫 | 通过 |
| 装机 | v1.14.0 安装成功，**无崩溃、无 ANR** |

### ⚠️ 没验证的：辉光**真的画出来了**

契约测试只能证明"代码调了霓虹"，**证明不了像素**。我尝试在设备上做
像素对比（同一份设计 glow 开/关，比亮度），但截图管线在这台设备上
反复失败（adb 的 stderr 被 PowerShell 当成错误中断流程），**没跑通**。

**请你目视确认**：仪表盘 → 风格 → 霓虹赛道，看数字表/折线表有没有辉光；
再切到经典琥珀（glow=false），辉光应当完全消失。

### 遗留

- **折线的辉光用 `neonPath` 手写多层描边** —— `NeonPainter` 没有路径版 bloom，
  这里是在 `BaseGaugeView` 里补的，逻辑与 `bloomLine` 平行但独立
- **`neonDot` 用 `roundRect` 画圆** —— 因为 `NeonPainter` 只有 `bloomCircle`，
  没有"实心圆"的封装（`roundRect` 半径=边长/2 就是圆）

---
## v1.13.0 · 2026-10-04 · 内嵌主题配色 + 多指针表

### 内嵌主题配色（P8-5，配套工具 v2.16.0）

设计文件带了 `themeColors` 就用它渲染，没有才按设置里的主题 id 查。

> 为什么优先内嵌：设计文件是「作品」，配色是作品的一部分 ——
> 跟着设备当前主题走的话，**同一份设计在两台机器上长得不一样**。

`DesignFile` 里只存 `JSONObject`，**不依赖 ui/** —— `fromJson` 的调用在渲染层，
守住「data/ 不能依赖 ui/」这条红线。

### 多指针表（配套工具 v2.17.0）

`needle` 部件可以各绑一个 PID —— 「转速 + 车速」双针表。

- `GaugePart` 加 `pid`；**只有 needle 解析它**（表盘绑 PID 没意义）
- `GaugePartsView` 从「单个值」改成**值表**（`PID id → 值`）+ `neededPids()`
- 渲染器一次把需要的 PID 取齐推进来 —— 视图**不自己读总线**（红线 4.1.5）

> ⚠️ **量程跟着 PID 走**：车速 0~240、转速 0~8000。车速指针按转速量程映射的话，
> 120 km/h 算成 1.5%，**指针几乎不动** —— 用户会以为「数据没上来」。

### 验证

| 项 | 结果 |
|---|---|
| 构建 | `assembleDebug` 通过，6.74 MB / 单 ABI |
| 装机 | v1.13.0 安装成功，**无崩溃、无 ANR** |
| Kotlin 单测 | **457 全过**（+4 多指针） |
| 浏览器 17 套件 | **622 断言全过** |
| 构建守卫 | 通过 |

### 遗留

- `value` 数值部件还不能各绑 PID（双针表配两个读数）
- 设备上「选择页面」的完整点击流程仍需人工确认（环境有别的 App 抢前台）

---
## v1.12.0 · 2026-10-04 · 设备上选页 + 渲染日志修正（含 v1.11.0 的 v2 能力补齐）

> **这一版把 v1.11.0 之后所有 App 侧改动补齐并重新打包。**
> 之前 `dist/` 里的 APK 是 00:51 构建的，而源码 02:30 还改过 ——
> **它不包含多页面 / 子部件 / 背景 w/h**。装机后那些功能等于不存在。

### ✨ 设备上选页（新增）

多页面设计以前**在车机上切不了页** —— `dashPageIndex` 只能改设置文件。

现在「风格」菜单末尾多一项 **「选择页面：<当前页>（n/N）」**：

- **只在多页设计时出现**，单页不显示（不占地方）
- 对话框列出每页的名字 + **控件数**（一眼看出哪页是空的）
- 选中即写 `dashPageIndex` 并**重渲染** —— 不用重启、不用重新导入

> ⚠️ 菜单是**按索引匹配**的（`themes.size + N`），所以新项加在**末尾**；
> 插在中间会让所有已有项错位。而且它是条件添加的，所以点击处理用
> `labels.size - 1` 反推，比硬编码索引稳。

### 🐛 修：渲染日志记错了变量

```kotlin
renderer?.renderDesign(pick, theme)
AppLog.d(..., "nodes=${design.nodes.size}")   // ← 记的是 design，不是 pick
```

多页面下 `design.nodes` **永远是第 1 页** —— 所以日志里的 `nodes` 恒为第 1 页的数量，
**看不出切页有没有生效**。实测时我被它误导，一度以为"选页坏了"。

现在记 `pick` + 页码：`nodes=2 page=0/2 scaleMode=1`。

### 🔧 顺带补齐（v1.11.0 之后改过但没打包的）

| 能力 | 来源版本 |
|---|---|
| App 读 `pages` + `dashPageIndex` 选页 | v2.11.0（工具侧） |
| 子部件渲染（`GaugePartsView`：表盘/刻度/指针/数值） | v2.12.0（工具侧） |
| 背景 `w`/`h`（`PositionedBackgroundDrawable`） | v2.8.0（工具侧） |

### 验证

| 项 | 结果 |
|---|---|
| 构建 | `assembleDebug` 通过，**6.72 MB / 单 ABI** |
| 装机 | v1.12.0 安装成功，**无崩溃、无 ANR** |
| **v2 渲染实测** | 用 `run-as` 写入一份 2 页面设计，日志确认 `渲染仪表盘(v2) \| nodes=2 page=0/2 scaleMode=1` |
| `pages` 解析实测 | 2 页 / 各 2 与 1 个节点，解析正确 |
| Kotlin 单测 | **453 全过** |
| 浏览器 16 套件 | **479 断言全过** |
| 构建守卫 | 通过（含素材引用完整性检查） |

### ⚠️ 没能验证的

**在设备上点「选择页面」走完整流程** —— 这个环境有两个干扰：
设备前台**反复被 `com.live2d.overlay` 抢走**，且**通知栏常驻遮挡**，
adb 的 `input tap` 多次落到别的界面。**这个请你手动点一下确认**
（仪表盘 → 风格 → 选择页面）。

### 遗留

- 背景 `w`/`h` 改了之后要**重新导入设计文件**才生效（不是热更新）
- 多页面切页后**撤销栈是跨页共享**的（工具侧行为，App 侧无撤销）
- `dashPageIndex` 越界时会**夹到最后一页**（换设计文件后旧索引可能超范围）

---

## v1.10.4 · 2026-10-03 · 数值动画重做：输入滤波 + 四种缓动曲线 + 收敛策略

用户反馈「动画条要优化、要流畅、0-10 要 +3+5 这样走过去而不是直接跳过去」。
查下去发现**根因不是"没有缓动"，而是缓动的三个层次各有一个问题**。

### 根因：三层各有一处问题

原来的动画只有一层：`displayValue` 用指数逼近 `value`（τ=45ms）。三个问题：

| # | 问题 | 后果 |
|---|---|---|
| 1 | **只有一个写死的曲线** | 没有 ease-in/out 可选，也调不了节奏 |
| 2 | **收敛就吸附并停止动画** | 数据 5Hz 推，两次推送之间目标不变 → 缓动在窗口里早早收敛、**停住**，下次推送再跳一下 |
| 3 | **没有输入滤波** | 数据本身的抖动（传感器噪声、量化）直接进动画，指针看着"毛躁" |

第 2 条是关键：τ=45ms 时一个 200ms 推送周期内走完 **98.8%** ——
指针**几乎瞬间到位**，然后在剩下的时间里"趴"在目标上不动。
数据缓变时（水温上升、正弦峰顶）看起来就是一格一格地跳。

### 新增：`Easing` —— 三层纯逻辑（37 个用例）

```
总线原始值 ──[1. 输入滤波]──→ 平滑目标 ──[2. 缓动曲线]──→ 显示值
                                                            │
                                        [3. 收敛判据] ←──────┘
```

**① 输入滤波**（`valueSmoothingMs`，默认 90ms）
专门压数据本身的抖动，与缓动曲线**解耦**：想更稳调大、想更灵敏调小。

**② 四种缓动曲线**（`easingMode`）

| 模式 | 机制 | 手感 |
|---|---|---|
| 标准（指数） | 增量：每帧走 `k·dist` | 全程减速、收尾长，最不容易看出跳变 |
| 线性（匀速） | 增量：固定速度 | 跳变时最像"指针在扫" |
| 柔和（缓入缓出） | 绝对位置：`3u²−2u³` | 起步慢、中段快、收尾慢 |
| 干脆（缓出） | 绝对位置：`1−(1−u)²` | 起步快、收尾慢 |

**③ 收敛判据**（`Easing.needsMoreFrames`）
把"够不够近"和"要不要继续动画"**拆成两件事**：

- 数据还在动（距上次目标变化 < `HOLD_MS`=600ms）→ 只吸附消除尾巴，**继续动画**
- 数据稳定下来了 → 吸附并停止，不空转

### 关键参数：τ 从 45ms 提到 120ms

一个 5Hz 推送周期（200ms）内：τ=45ms 走 **98.8%**（几乎瞬间到位），
τ=120ms 走 **81%**（永远留余量给下一次推送 → 指针一直在动）。

代价是到位慢一点（3τ≈360ms）。仪表读数本来就不需要瞬时响应，而"顺"是第一眼就能看出来的。

### 重构：抽出 `GaugeAnimator`（状态机）

动画的状态机（起点、总行程、目标稳定计时）原来长在 `stepFrame` 里，
**JVM 单测跑不了**（要 View、要 Choreographer）。而"数据还在变时会不会冻住"
这类问题恰恰只出在状态机上，不在数学上。

抽成独立类后 `BaseGaugeView` 少了约 40 行可变状态，且这些状态有了单一负责人。
这也是重构文档 §2.2 步骤 2 要的那一步。**19 个用例**直接按真实时序喂数据。

### 新增：性能基准页的「流畅度」指标

帧率与掉帧只说明**画得动**，不说明**动得顺**。
指针"一格一格跳"的本质是**部分帧上没有位移**，所以基准页现在直接统计
「显示值真的变了的帧占比」。

**实测（小米平板 5，v1.10.4）**：

| 档位 | 动了 / 总帧 | 占比 |
|---|---|---|
| 8 表 · 主题默认 | 599 / 599 | **99.8%** |
| 8 表 · 夸张（11 层） | 599 / 599 | **99.8%** |
| 8 表 · 关闭辉光 | 599 / 599 | **99.8%** |
| 12 表 · 夸张（极限） | 599 / 599 | **99.8%** |

四段仍然**零掉帧**（帧间隔 p99 ≤ 16.73ms）。也就是说：**动画变顺了，性能没退**。

### 主题编辑器新增「数值动画」一节

缓动曲线下拉（4 种）+ τ 滑块 + 输入滤波滑块，**改完立刻在预览里看出来**。
内置主题只读 → 保存时自动另存为自建主题（与原有行为一致）。

### 过程中实际写出来又修掉的三个缺陷（都记下来）

1. **指数逼近的增量积分漂移**：`v ← v + (v_target−v)·(1−e^(−dt/τ))` 在 60Hz 与 120Hz 下
   同样 250ms 差 **20 个百分点**（55.5 vs 35.0）—— 因为 `1−e^(−dt/τ)` 不是线性的，
   帧多帧少累积出的曲线不同。修法：把每帧混合系数**按参考帧长归一化**
   （`k = 1−(1−k_ref)^(dt/REF)`），这样 k 对 dt 可加。

2. **进度型曲线把"剩余距离"当总行程**：写成"每帧位移 = 剩余距离 × 曲线速度 × dt/时长"，
   看着合理，实际**永远到不了目标**（实测停在 64.76%）—— 剩余距离逐帧缩小、位移逐帧衰减。
   修法：曲线作用在**固定不变的总行程**上（目标变化时固定下来）。

3. **下降方向恒不动**：`journeyStart + journeyDist·curve − from` 对下降方向是**负数**，
   被 `coerceIn(0, dist)` 夹成 0。需要 `abs` 之后统一乘方向。
   **上升方向的用例完全测不出来** —— 是补了下降用例才发现的。

> 第 3 个缺陷特别值得记：它只在"目标下降"时出现，而人写测试时下意识先写上升。
> 现在 `GaugeAnimatorTest` 里有一条专门的下降收敛用例守着。

### 踩坑：改 `build.gradle.kts` 用 PowerShell `-replace | Set-Content -NoNewline`

只想改版本号，结果：
- **换行全被吃掉** → `abiFilters += "arm64-v8a"` 那行被并进注释 → **四个 ABI 全编**
  （APK 6.68 → **9.41 MB**，`lib/` 0.91 → 3.61 MB）
- 文件被写成 **ANSI(GBK)** → 中文注释变乱码，`read` 工具直接报 `invalid UTF-8 text`

修法：用 `[System.IO.File]::WriteAllText($p, $text, (New-Object System.Text.UTF8Encoding($false)))`
显式写 UTF-8 无 BOM。**改源码文件不要用 `Set-Content`**（它按 ANSI 写，且 `-NoNewline` 会吃掉换行）。

### 验证

- **415 个单元测试全通过**（+57）：`EasingTest` 37（新建）· `GaugeAnimatorTest` 19（新建）·
  `GaugeEasingTest` 14（改）· `GaugeThemeTest` 25
- 装机实测：流畅度 99.8%、零掉帧（见上表）
- `adb logcat -b crash` 无 `com.icar.obd` 条目

### 遗留

- 各曲线的**手感**最终要靠眼睛定。τ=120ms / 滤波 90ms 是算出来的起点，
  真机上觉得"太慢/太快"直接在主题编辑器里调（有实时预览）
- 进度型曲线（柔和 / 干脆）的总时长固定为 `2τ`，**没有单独的总时长参数**。
  想要"慢起步 + 长滑行"需要再拆一个参数，目前没做
- 「流畅度」指标只统计**第一块表**。8 块表各自动画时它们的占比可能略有差异

---


## v1.10.3 · 2026-10-03 · 打通「电脑上设计 → 设备上生效」的闭环

### 修复：设计文件在 App 侧**根本没有入口**（这是 v1.10.0 起就有的断点）

用户问了一句「电脑的主题修改有同步修改好吗」，顺着去查才发现：

> `DesignFile.parse` 写好了、22 个用例守着、PC 工具也能产出文件 ——
> 但 **`app/src/main` 里一次都没调用过它**。

也就是说 v1.10.0 引入的 `icar.ui/1` 格式，**只有一半**：能写、能校验，
但**设备上没有任何地方能读它**。工具做得再好也流不到 App ——
只能手动 `adb push` 到 `files/design.json`，而那个文件**没有任何代码会去读**。

这是"规则同步做好了、但数据流是断的"——两件事都得成立才行。

**修法**：仪表盘「风格」对话框新增两个动作项，走 SAF（不需要存储权限）：

| 入口 | 作用 |
|---|---|
| **导入设计文件…** | 选一个 `design.json` → 解析 → **先给用户看结果** → 确认后整体替换自定义仪表盘 |
| **导出当前布局为设计文件…** | 把当前盘面导成 `design.json` 分享出去（回到 PC 工具继续改） |

**为什么导入要两段式**：设计文件的校验**不抛异常**、返回带字段路径的错误列表，
所以有硬错误时可以精确说清"哪一块表的哪个字段错了"；软警告（比如背景路径在本机
不存在）也要显示 —— 那是"能加载但效果可能不是你想要的"，瞒着用户更糟。

**为什么必须有导出**：没有它，用户在设备上微调过的布局就回不到 PC 工具上，
只能从头重画。闭环的另一半。

### 修复：主题写的是数字 id，而不是设计文件规定的别名

设计文件格式规定 `theme` 写 `"neon"` 这样的**名字**，但 App 存的是数字 id。
导出时直接写 id 的话，导入端（甚至另一台设备）会报「主题不存在」。

- 新增 `GaugeTheme.aliasOf(id)` / `byAlias(alias)` —— **内置主题的别名是冻结的跨层契约**
- 放在 `GaugeTheme` 而不是 `DashFragment`：这是主题自己的属性；
  而 `data/DesignFile.kt` 导出时也要用它（`data/` 不能依赖 `ui/`，所以由调用方传入）
- **自建主题没有别名** → 导出时留空（= 用当前主题）。自建主题的 id 在不同设备上
  必然不同，写进文件只会让导入端报"主题不存在"
- 别名映射有 5 条用例守着（`GaugeThemeTest`），漏一个内置主题就失败

### 验证

- **358 个单元测试全通过**（+13）：`GaugeThemeTest` 25（+7）·
  `ThemeStudioSampleTest` 24（+5）· 其余不变
- **装机实测完整闭环**（小米平板 5，v1.10.3），不是"编译过"：
  1. 把工具产出的 `sample.json` 推到设备，经 SAF 选择器导入
  2. 导入确认框正确显示：设计名「赛道模式」· 6 块仪表 · 主题 `neon` · 背景「铺满（裁切）」
     · **1 条警告**（`background.path` 在本机不存在）
  3. 确认后落盘核对：`dash.json` 6 块表、`cardStyle` 逐条正确
     （`std_0C`→2 透明、`std_04`→1 无边框、其余未设置）；
     `settings.json` 的 `bgImage`/`bgFit`/`dashType=2` 都对
  4. 再走「导出当前布局为设计文件…」→ 系统分享面板弹出 →
     `cache/design.json` 内容正确：`theme: "neon"`（**别名不是 id**）、6 块表、
     `cardStyle` 与导入前**逐条一致**、背景段保留、无 `legacyGrid`
  5. `adb logcat -b crash` 里**没有** `com.icar.obd` 的条目；ANR 0 条

### 遗留

- 导出的是**自定义仪表盘**（`Store.customGauges`）。「普通 / 性能」两个内置预设
  是代码里的常量、不可编辑，所以不参与导出 —— 想改它们要先「布局 → 套用预设」
  转成自定义盘面
- 设计文件里**不能内嵌主题颜色**（只能引用内置主题别名）。自建主题的配色无法随
  文件传递 —— 需要的话得用「主题编辑器 → 导出主题」单独传
- 导入后**不会自动重建 PID**：设计文件里引用的自定义 PID 必须已经在设备上。
  校验会警告"不在内置 PID 库里"，但不拦下

---


## v1.10.2 · 2026-10-03 · 外框可关 / 吸附可关 / 背景图 / PID 别名补全

四项都是「盘面控制权」的补齐 —— 之前这些东西要么没有，要么藏得太深。

### 新增：卡片外框三层控制

**问题**：`cardStrokeDp` / `cardAlpha` 早就有（v1.6.2），但只有主题级一个入口，
而且**藏在「编辑主题…→ 几何」里，内置主题还得先「另存为」**。更要紧的是
主题编辑器的实时预览**没画卡片底** —— 调那两个滑块时屏幕上什么都不会变。

三层一起补：

| 层 | 入口 | 说明 |
|---|---|---|
| **主题级** | 风格 → 编辑主题… → 几何 | 原有滑块不变 |
| **快捷开关** | 风格 → 「关闭卡片外框（保留卡片底）」/「卡片完全透明（适合背景图）」 | 新增。自动生成自建主题副本，不用进编辑器 |
| **单块表** | 布局 → 编辑 → 「卡片外框」下拉 | 新增。`跟随主题 / 无边框 / 完全透明卡片 / 不画卡片` |

**单块表这一层是真正缺的那一块**：真实盘面常常是混合的 ——
大转速表想完全透明露出背景图，旁边四个小数字表却需要卡片底才读得清。
一刀切必然牺牲一边。

- `GaugeItem.cardStyle: Int?`（`null` = 跟随主题，**旧配置无需迁移**）
- 常量 `CARD_THEME / CARD_NO_BORDER / CARD_TRANSPARENT / CARD_NONE` + `CARD_NAMES`
- `GaugeTheme.withCardOverride()` / `cardBackgroundFor()` —— 渲染器与编辑器
  **共用同一个入口**（红线 §4.5.20），编辑器里看到的边框 = 实际渲染的边框
- `CARD_NONE` 返回 `null` 背景，调用方把 host 背景留空（比设一个全透明 Drawable 少一次绘制）
- **快捷开关复用已有的自建主题**：当前用的本来就是自建主题时就地改，
  否则每点一次开关就多出一个主题，主题列表很快会被垃圾填满

**主题编辑器预览**：三个预览表各套一层 `pvCard*` 容器画卡片底。
不套这一层的话，「卡片描边」「卡片不透明度」两个滑块**看不到任何变化** ——
而那正是这个预览区最该演示的东西。

### 新增：拖拽编辑器可关吸附

`Store.Settings.dashSnapEnabled`（默认 `true`，与引入本项之前的手感一致）。
编辑器工具栏新增「吸附开 / 吸附关」按钮，提示行同步显示当前模式。

**关键取舍**：关掉的是「对齐网格」，**不是「允许拖出画布」**。
`DashLayout.Drag.moveIf/resizeIf` 里夹取**永远生效** ——
把仪表拖到看不见的地方没有任何用途。

### 新增：背景图片铺法 + 设计文件支持背景段

**App 侧**：`Store.Settings.bgFit`（0 铺满 / 1 完整显示 / 2 居中原始大小），
入口在「风格 → 背景铺法…」。用 `BitmapDrawable` 的 gravity 实现，
**不引入第二套枚举**（取值与 `DesignFile.FIT_*` 同源）。

> ⚠️ 三种铺法解决的是同一个问题：相册里的图与屏幕宽高比几乎不可能一致。
> 铺满会裁掉边缘，完整显示会留黑边 —— 哪个更好取决于图，所以交给用户选。

**设计文件**：新增可选的 `background` 段（`path` + `fit`）。

- 只存**路径**，不内嵌图片数据 —— 设计文件要能被人读、被 diff 看，
  塞一段 base64 会让它变成不可读的二进制块，而且改一个坐标就要重写几 MB
- 路径不存在**只警告不报错**：设计文件常在不同设备之间传递，
  写死绝对路径必然对不上；拦下整个设计太粗暴（仪表布局本身是好的）
- `fit` 取值非法时回落到「铺满」并警告

### 补全：PID 别名 14 → 27 条

**每个默认启用的内置 PID 现在都有语义别名**（20 标准 + 7 派生）。
之前只有 14 条，`obd.maf` / `obd.stft` / `obd.ltft` / `obd.map` / `obd.ambient`
等都没有 —— 在主题工具里选不到，只能去翻 PID 表。

刻意**不给** `MANUFACTURER_TEMPLATES`（`tpl_*`）别名：那 4 条是占位示例
（默认 `enabled=false`，PID 号是猜的）。给它们起个"好听的语义名"反而会让人
以为可以直接用。

新增 `DesignFile.missingAliases()` + `每个内置 PID 都有语义别名` 用例 ——
把「补别名时漏了一条」变成**可测的事实**，而不是靠人记得同步三处
（Kotlin 别名表 / 主题工具 / 设计指南）。

### 主题工具同步（`tools/theme-studio/`）

- PID 别名补到 27 条 + `BUILTIN_PIDS` 补到 31 条，**下拉框按分组加 `<optgroup>`**
  （标准 OBD / 派生 / 厂家模板）—— 31 条平铺在一起没法找
- 新增「背景图」面板：选本地图片**预览**（按铺法画在画布上）、路径手填、铺法下拉
- 属性面板新增「卡片外框」下拉 + 「把外框应用到全部」按钮
- 画布预览按 `cardStyle` 渲染卡片底；「不画卡片」的表用虚线框标出选中态
  （否则选了那一档就看不出选的是哪块）

### 修复：`ObdEngine` 的跨模块智能转换

`res.value` 是 `PidValue` 的**跨模块 `var` 属性**，Kotlin 不允许对它做智能转换
（`Smart cast to 'Float' is impossible`）。这不是新问题，只是 `data/` 重新编译时
才会暴露出来 —— 先取到局部变量再判空即可。

### 验证

- **345 个单元测试全通过**（+21）：`ThemeStudioSampleTest` 19（+11）·
  `GaugeThemeTest` 18（+6）· `GaugeLayoutTest` 34（+4）
- **跨语言一致性 63 项全通过**（Node 侧从 HTML 抽出真函数体 eval，与 Kotlin 文案比对）
- 装机验证（小米平板 5，v1.10.2）：
  - 「风格」对话框五个新条目都在
  - 「关闭卡片外框」→ 生成自建主题 `id=101`（`cardStrokeDp=0 cardAlpha=255`），
    **原自建主题 `id=100` 未被改动**
  - 吸附开关：按钮变「吸附关」、提示同步、`settings.json` 的 `dashSnap=false`
  - 「卡片外框」下拉四档正常；选「完全透明卡片」后 `dash.json` 里
    **该块 `cardStyle=2`、另一块仍是未设置**（互不影响）
  - `adb logcat -b crash` 为空；ANR 0 条

### 遗留

- 背景**平铺（tile）**没做 —— `BitmapDrawable` 的 REPEAT 配合已下采样到 2048 的图
  只会平铺 1~2 块，观感是错的。要做需要另写一个按屏幕尺寸缩放后平铺的 Drawable
- 卡片外框只有 4 个枚举档位，**不支持每块表自定义圆角/描边数值**。
  真需要时用主题编辑器做几套主题，再按块选
- `cardBackground` / `cardBackgroundFor` **没法在 JVM 单测里测**（要 `GradientDrawable`，
  是抛 `Stub!` 的 Android 桩）。纯 Kotlin 的那一半（覆盖项 → 三个数值的映射）已测，
  「返回 null」这条靠装机验证

---


## v1.10.1 · 2026-10-03 · 性能基准（终于量准了）+ 统一两套报警概念 + 主题制作工具

> 本轮把 `docs/21-下一步-主题工具与仪表盘重构.md` 里三件**一直悬着**的事一起做了：
> §2.4 的性能基准（从 v1.9.0 起就没量准过）、重构步骤 1、第一部分主题工具。

### 新增：仪表盘性能基准页（`ui/BenchActivity` + `ui/BenchHarness` + `ui/dash/DashboardBenchmark`）

**回答的问题**：9 层霓虹辉光在 8 个仪表下守得住 60fps 吗？（文档 §2.4，被推迟了三个版本）

**之前为什么量不出来**，两个原因都修掉了：

1. `dumpsys gfxinfo` 在这台设备上只给头部、没有帧统计；
2. 用真实数据测时**仪表根本没在动** —— 静止的 View 不重绘，测出来的"帧率"是屏幕刷新率，
   和绘制成本无关。基准自己每帧 `updateMulti()` 灌正弦假值，**强制每帧重绘**。

**四段测量**（8 表 × 3 档 + 12 表极限），每段预热 1.5s + 测量 10s。结果：

| 档位 | 仪表 | 帧数 | 帧间隔 平均 | p99 | 最大 | 超时帧 |
|---|---|---|---|---|---|---|
| 8 表 · 主题默认 | 8 | 1199 | 8.33 ms | 8.39 ms | 8.43 ms | **0** |
| 8 表 · 夸张（11 层） | 8 | 1199 | 8.33 ms | 8.38 ms | 8.41 ms | **0** |
| 8 表 · 关闭辉光 | 8 | 1199 | 8.33 ms | 8.38 ms | 8.43 ms | **0** |
| 12 表 · 夸张（极限） | 12 | 1199 | 8.33 ms | 8.38 ms | 8.41 ms | **0** |

**结论：12 个圆表 + 11 层辉光跑满 120fps，零掉帧。** 8 个表更不在话下。

> **⚠️ 判据是「帧间隔」，不是「每帧绘制耗时」—— 这一点差点搞错。**
>
> 第一版报告用 `DrawStats` 的每帧耗时（0.2~0.34ms）下结论，看起来"还有 50 倍余量"。
> 但 Android 开了硬件加速后 `onDraw` 只是把绘制指令**记录**进 DisplayList，
> 真正的光栅化在**渲染线程**上做 —— 那个数**不是绘制成本**。
> 报告里现在把它明确标成"旁证"，主判据换成帧间隔（主线程 + 渲染线程 + 合成器的最终结果）。
>
> 顺带发现：`关闭辉光` 的**记录**耗时（0.34ms）反而**高于** `夸张`（0.28ms）——
> 说明这一列量的是视图层代码，与辉光层数基本无关。这本身也印证了不能拿它当判据。

**踩坑（都记下来，避免下次重犯）**：

1. **画布高度塌成 0**：第一版把控件放进 `ScrollView`，`weight=1` 拿不到剩余空间，
   点「开始测量」直接报"容器还没布局好"。改成固定头部 + `weight=1` 画布，根部不套 ScrollView。
2. **布局监听器越界崩溃**：`onLayoutChange` 里读了 `segments[segIndex]`，
   三段跑完后 `segIndex=3` → `ArrayIndexOutOfBoundsException: length=3; index=3`，
   **真机上崩了两次**。布局监听器现在只读 `currentPreset`，完全不碰索引。
3. **预热被算进测量窗口**：延时按 `SEGMENT_SEC` 算，而预热吃掉 1.5 秒，
   实际只测了 8.5 秒。改成 `WARMUP_MS + SEGMENT_SEC`。
4. **首帧峰值污染统计**：重建视图后第一帧要付 `Paint` 光栅化 / 字体度量 / tessellation，
   峰值 **11393µs**。加了 1.5 秒预热，预热结束才 `reset()` 开始计数。
5. **屏幕刷新率会封顶帧率**：同一页两次测量分别读到 30Hz 和 120Hz
   （`mActiveModeId` 在 30/60/120 之间切）。拿 fps 当判据会得出"刚好达标"的错觉。
6. **本机同时挂着模拟器**：`adb` 不带 `-s` 会报 `more than one device/emulator`。
   所有命令都要写 `-s 7e7d7bb4`。

### 重构：统一两套报警概念（`BaseGaugeView`）

**问题**（文档 §2.1 问题 2）：两个概念并存且**重叠但不相等** ——

| | 来源 | 用途 |
|---|---|---|
| `warn: Boolean` | `isOutOfRange()`，**含下限** | 选颜色 |
| `alertLevel: Int` | `AlertPulse.level()`，**只认上限** | 驱动爆闪 |

`warnLow` 触发时 `warn=true` 而 `alertLevel=NONE`，于是"到底哪个才是报警"永远说不清；
而且 7 个视图各自写了一遍 `if (warn) cWarn else …`，加一档报警要改 7 个文件。

**做法**：

- 删掉 `warn`，新增 `AlertPulse.levelWithLow()`（**保留** `level()` 不动 ——
  它被扫描器沿用，27 个用例钉着它的迟滞边界，不该被顺手改）
- 新增 `AlertPulse.WARN_LOW` 档：**下限只染色、不爆闪**。
  爆闪的语义是"立刻松油门 / 靠边"，数值偏低不需要这种紧迫感；
  硬要闪反而会让驾驶员对爆闪脱敏
- 新增 `BaseGaugeView.alertColor()` / `valueTextColor()` / `extraTextColor()`，
  **报警配色只有一处判定**，7 个视图的重复判断全部删掉

**⚠️ 一处刻意的观感变化**：`CircularGaugeView` 的指针原来只在**危险档**变红
（`if (warn) cDanger else cNeedle`）。现在按报警等级取色 ——
WARN 档指针变橙、CRITICAL 变红。理由是"报警了指针却不变色"本身就不一致。
若不想要这个变化，改回 `alertLevel == AlertPulse.CRITICAL` 即可。

### 修复：`DigitalGaugeView` 的装饰弧跳变（文档 §2.1 问题 5，一行）

`ratio(value)` → `shownRatio()`。这是 `docs/10-动画实现.md` 记了很久的不一致：
数字表的底部进度条**不参与缓动**，和圆表 / 条形表的平滑观感不统一。

### 修复：`AlertPulse.levelWithLow` 的下限迟滞方向写反了（**自己写出来又被单测抓出来的**）

上限是"超过才报、跌下来才解除"，所以退出阈值**低于**进入阈值（`releaseOf` 用减法）。
下限正好相反 —— 照抄减法会让退出阈值落到进入阈值**下面**，于是**永远进不去**。

新增 `releaseHighOf()`（加法）。这个 bug 是 `下限也有迟滞` 那条用例抓出来的，
手测几乎不可能发现（现象只是"低电压不变色"，很容易归因到别处）。

### 新增：主题制作工具 `tools/theme-studio/`（文档第一部分）

**单文件 HTML，双击即用，零安装。** 画布可视化编辑 → 校验 → 导出 `icar.ui/1`。

- 360×360 参考网格、拖动 / 缩放、吸附 15 单位（与 `DashLayout.Drag.STEP` 一致）
- 属性面板（PID / 样式 / 量程 / 阈值 / 霓虹档位 / 指针环 / 副参数）
- 6 个预设布局（1 大 4 小 / 2×2 / 全条形 / 赛道 / 四联表）
- **校验规则逐条抄自 `DesignFile.parse`**（判定与文案），另有 PID 别名表、内置量程、
  吸附公式、霓虹档位名全部同源
- 内置一页「与 App 规则的差异」，把**对不上的地方显式列出**（比如 JSON 语法错误文案
  不可能逐字一致：App 用 `org.json`、浏览器用 `JSON.parse`）—— 不假装一致比假装一致安全

**交付物**：`index.html` + `sample.json` + `00-README.md`

**同源不是靠"抄的时候仔细"，是靠两层机器检查**：

1. **`ThemeStudioSampleTest`（Kotlin 侧）** —— 工具自带的 `sample.json` 必须能被
   `DesignFile.parse()` 解析且 0 错误 0 警告
2. **跨语言文案比对（Node 侧，一次性）** —— 从 HTML 里按大括号配平**抽出真正的函数体**，
   在最小上下文里 eval，用与 Kotlin 测试相同的输入比对输出文案。
   **36 项全通过**：常量（schema / unit / 32 上限 / STEP=15 / MIN_SIZE=30 / 14 条别名）·
   9 条硬错误文案 · 5 条软警告文案 · 别名解析与坐标不被二次 ×360 · 往返自洽 ·
   非法 JSON 报错带行号

### 修复：`tools/run-tests.ps1` 用绝对路径调用时直接退出

**症状**：`powershell -File "D:\...\tools\run-tests.ps1"` 报
`Split-Path : Cannot bind argument to parameter 'Path' because it is an empty string`，
**一个用例都没跑**。

**根因**：`param([string]$ProjectDir = (Split-Path -Parent $PSScriptRoot))` ——
从外部用绝对路径调用时 `$PSScriptRoot` 是空串。

**修法**：`ProjectDir` 改为可省略，按 显式传参 → `$PSScriptRoot` → `$MyInvocation.MyCommand.Path`
依次回退；都拿不到时给出明确提示而不是抛栈。三种调用方式都验证过。

### 踩坑：改 `.ps1` 丢了 UTF-8 BOM（**报错完全指向错误方向**）

修上面那条时把 `run-tests.ps1` 写成了**无 BOM** 的 UTF-8。
Windows PowerShell 5.1 对无 BOM 的 `.ps1` 按 **ANSI(GBK)** 解码，于是：

- 中文注释全变乱码；
- 乱码把**行尾吃掉**，下一行的 `if (-not $ProjectDir) {` 被并进上一行注释里；
- 报错是 `Unexpected token '}' in expression or statement` ——
  **看起来像语法错误，实际是编码问题**，顺着报错行查语法会白费很久。

`oncar-check.ps1` 一直有 BOM，可以对照。已在 `05-FILE_MAP.md` §6.1.1 记下验证方法：
`[System.Management.Automation.Language.Parser]::ParseFile($p, [ref]$null, [ref]$errs)`。

> **`docs/*.md` 与 `.kt` 不受影响**（Markdown 与 Kotlin 都按 UTF-8 读）。

### 验证

- **324 个单元测试全通过**（+36）：`DashboardBenchmarkTest` 12 · `AlertPulseTest` +10 ·
  `ThemeStudioSampleTest` 8 · `NeonStyleTest` 6（新建）
- **`ThemeStudioSampleTest` 是"同源"的硬保证**：工具自带的 `sample.json` 必须能被
  `DesignFile.parse()` 解析且 **0 错误 0 警告**，坐标不能被再乘一次 360，
  别名要解析成真实 PID id。抄错规则会**在测试里失败**，而不是在用户推上设备时
- **`NeonStyleTest` 冻结霓虹档位名**：那是 `data/` 与 `ui/view/` 之间的跨层约定，
  改名会让存量 `dash.json` / `design.json` **静默回落到「标准」**
- 装机验证（小米平板 5）：基准四段 0 掉帧；`adb logcat -b crash` 为空；ANR 0 条

### 遗留

- 基准只测了**圆表**（最贵的样式）。数字 / 折线 / 多值 / G力值四种表**没接霓虹**（v1.9.0 遗留），
  将来给它们接上辉光后应当重跑一次
- 基准的「每帧记录耗时」**不是**光栅化成本。要拿 GPU 真实耗时需要
  `dumpsys gfxinfo framestats`（这台设备上只给头部）或 GPU 计数器 —— 目前做不到，
  所以判据只能落在帧间隔上（帧间隔已经足够回答"守不守得住"）
- 主题工具的撤销 / 重做**没做**；App 侧的「导入设计文件」入口**仍未接线**
- 重构步骤 2~5（抽 `ValueEasing` / `GaugePalette` / 拆 `DashRenderer` / `GaugeItem` 分组）**未做**。
  现在性能基线有了：**瓶颈不在渲染层**，所以重构的紧迫性下降了，
  可以按"可读性收益"而不是"性能风险"来排期

---


### 新增（横屏 2 列布局）

- **`ui/view/ColumnFlowLayout.kt`** —— 分栏流式布局，**宽度够就自动分 2 列**。
  - 解决的问题：平板横屏可用宽度 1138dp，而表单是单列的，结果一行一个「超宽输入框」。
    `MaxWidthViews` 那套治的是「太宽」（夹窄居中），但夹窄之后右边一大片还是空的 ——
    分栏才是真正把宽度用起来。
  - **不用 `layout-land` 副本**：列数由可用宽度决定，竖屏自动 1 列、横屏自动 2 列，
    一份代码通吃。同一份表单写两遍 XML，改一处忘一处是必然的。
  - 摆放规则是**瀑布流**（依次放进当前最矮的列），不是按行切分 ——
    字段行高度不一时，按行切分会因一个高控件把整行撑开，另一边留一大块空白。
  - 列分配抽成纯函数 `assign` / `assignColumns`，`onMeasure` 与 `onLayout` **共用同一个函数**
    （各算一次必然算出不同结果 → 错位）。`ColumnFlowLayoutTest` 9 个用例。
  - 已接入：**主题编辑器**（`themeFields`）、**模拟信号工具**（`simChannels`）、
    **CAN 探测**（`sniffResults`）。这三个是代码生成行的，换容器即可。

### 验证（横屏 2 列布局）

- **218 个单元测试全通过**。
- **装机验证（小米平板 5 横屏 2560×1600）**：主题编辑器字段分布
  **左列 8 个 / 右列 7 个**，右列字段 x≈1392（屏宽 2560），高度自动均衡；无崩溃。
- ⚠️ **踩了一个坑**：第一次验证失败（全在左列 x=126），原因是我装的是**上一轮归档的旧 APK**
  —— 新构建没重新 `Copy-Item` 到 `dist/`。**构建后必须重新归档再装**。

---

---

### 新增：[UI控件清单.md](08-UI控件清单.md)

把**所有 UI 控件的名字**整理成一份可查的清单：

- **8 种仪表样式 → View 的映射**（含继承关系图）
- **全部自定义 View**：14 个绘制类 + 4 个 `MaxWidth*` 容器 + 4 个非 View 的绘制辅助
- **22 个布局文件的控件 ID 全表**（约 240 个 ID，按文件分组）
- **颜色资源**（22 个，分界面基础 / 文字 / 语义 / 仪表专用 / 扫描）
- **样式资源**（10 个）、**drawable 资源**（13 个）
- **主题字段**（`GaugeTheme` 全字段）与**霓虹档位表**（5 档的具体参数）
- **改 UI 时的 6 条注意事项**（不要覆写 `onDraw`、不要在 `onDraw` 里 new、
  颜色必须从主题派生、动画走 `GaugeTicker` 等）

**交叉核对过**：脚本扫描全部布局文件，确认布局里的控件 ID **一个不漏**都在文档里
（第一次漏了 `btnTpl2/3/4`，因为我用了 `btnTpl1..btnTpl5` 的范围写法，已展开）。

### 新增：[动画实现.md](10-动画实现.md)

把"仪表盘动画靠什么驱动、数值变化动画怎么算"整理成一份分析。核对代码时发现一处**不一致**：

> `DigitalGaugeView` 第 88 行用的是 `ratio(value)` 而**不是** `shownRatio()`，
> 所以它的装饰弧是**跳变**的，和圆表/条形表的平滑观感不统一。**一行可修。**

文档要点：

- **两套机制性质不同**：数值缓动是"过渡"（会收敛会停），阈值爆闪是"振荡"（不收敛一直在跑）。
  必须分开 —— 只有一套的话，要么报警闪一下就不动，要么数值不动了还在 60fps 空转。
- **全工程只有 `GaugeTicker` 一处动画驱动**（`Choreographer`），
  没有用 `ValueAnimator`/`ObjectAnimator`/`postInvalidateOnAnimation`。
- **缓动是指数逼近**（一阶低通），`k = 1 - e^(-dt/τ)`，τ=45ms。
  时间基准而非每帧固定比例 —— 这台平板能跑 120Hz，按帧缓动会快一倍。
- **收敛判据按像素折算**，不用相对比例（转速量程 8000 时相对千分之一是 8 转，指针会肉眼可见地"爬"）。
- **文本永远用原始值**，只有图形用动画值 —— 读数必须准，指针可以慢半拍。
- **爆闪带迟滞**（退出阈值 = 进入 × 0.97），否则转速在 6500 抖动会让爆闪乱闪。
- 文档末尾列了**已知问题**，其中"性能基准仍未量准"标为**高优先级**。

## v1.10.0 · 2026-10-03 · 缓动改时间基准 + 删除 Sky 主题 + PC 端设计框架

### 修复：个别进度条"一顿一顿"

**根因是缓动的实现方式，不是数据。** 原来是**按帧**逼近：

```kotlin
from + (target - from) * 0.25    // 每帧固定比例
```

两个毛病：

1. **帧率相关**。60Hz 下 200ms 收敛，120Hz 下只要 100ms ——
   同一份代码在不同设备观感完全不同。**这台平板就能跑 120Hz**。
2. **和 5Hz 的数据推送错拍**。数据每 200ms 来一个新目标，
   而按帧缓动要 ~173ms 才到 95%，剩下 5% 是长长的尾巴 ——
   **永远在"快起步、慢收尾"的循环里**，看起来就是一顿一顿。

改成**时间基准**：`k = 1 - e^(-dt/τ)`，τ=45ms。不管多少帧率，固定时间收敛。

顺带把收敛判据从**相对比例**改成**像素级**：
转速量程 8000 时，相对千分之一 = 8 转，条形上是 0.1% 宽度，
但**指针会肉眼可见地"爬"**。现在 `BarGaugeView` / `CircularGaugeView`
按自己的像素尺度覆写 `settleEpsilon`，不到半个像素就吸附。

**新增 7 个测试**，其中两个专门钉"帧率无关"：
60Hz 与 120Hz 跑同样 200ms，结果必须几乎一致。

### 删除：Sky Gauge 主题支持

用户确认可以删。删掉 `SkyTheme.kt` / `DashElement.kt` 及两个测试文件，
清掉 `Store` / `DashFragment` / `LvglDashView` / `LvglBridge` 里的全部引用。

**APK 从 7.21 MB 降到 6.65 MB。**

### 新增：`DesignFile` + [UI设计指南.md](13-UI设计指南.md) —— **在电脑上设计 UI**

现在调布局只有两条路（手指拖 / 改代码），**都不适合做设计**。
设计文件把它变成"编辑一个 JSON"：

```
PC 写 design.json  →  校验（有明确报错）  →  推到设备  →  App 加载
```

**与刚删掉的 Sky Gauge 格式的关键区别**：

| | Sky Gauge | `icar.ui/1` |
|---|---|---|
| 归属 | **别人的**格式 | **我们自己的** |
| 模型 | 图元级，要写转换层 | **直接复用 `GaugeItem`**，零转换 |
| 表达力 | 受限于他们的词汇表 | = App 能画的东西，一一对应 |
| 坐标系 | 正方形 360×360，非方形屏会变形 | 每轴 0..360，天然适配 |

**校验是这个格式一半的价值**：手写 JSON 一定会写错，而"推到设备上发现没显示"
是最低效的调试方式。所以解析器**不抛异常**，返回带字段路径的可读错误：

- 硬错误（拒绝加载）：JSON 语法 / schema 不对 / unit 不是 360 / 缺 pid / 量程非法
- 软警告（能加载但提示）：**越界**（越界不会报错、只会"看不见那块表"）/ 坐标为负 /
  尺寸过小 / 未知 pid（自定义 PID 是合法场景，不拦）

**22 个测试**。其中一条抓出一个真问题：

> `GaugeItem.fromJson` 用**元素自己的 `unit` 字段**判断新旧格式，没有就 ×360（旧配置迁移）。
> 而设计文件的单位声明在 `canvas.unit` 上 —— 不注入标记的话**每个坐标都会被再乘一次 360**
> （12.5 → 4500）。这个坑是单测抓出来的。

### 验证

**288 个单元测试全通过**，装机无崩溃。

## v1.9.0 · 2026-10-03 · 仪表盘重构：共用霓虹层 + 阈值爆闪

### 新增：`AlertPulse` —— 阈值报警与爆闪（纯逻辑，27 个单测）

抽成独立对象的理由：**迟滞边界**和**时间相位**是最容易写错、又最难手测的两处。
放在 `onDraw` 里这两件事都没法验证；做成纯函数（时间由调用方传入）就能单测。

- **迟滞**：退出阈值 = 进入阈值 × (1 − 3%)。没有它，真实转速在 6500 上下抖动会让爆闪乱闪。
  测试里专门写了一个**反证用例**：不传上一帧等级，同一串样本会被最后那个小值打回 NONE。
- **两档不同节奏**（一眼看出严重程度）：
  - `WARN` ≈1.7Hz **平滑脉冲**（smoothstep）—— 低等级用硬方波太刺眼，长途驾驶会烦
  - `CRITICAL` ≈5Hz **硬方波** —— 干脆、有冲击力
- **染色策略**：不做"整个元素变色"（那会让读数在闪烁中消失），
  只把**辉光和外圈**推向危险色，读数始终可辨。

### 新增：`NeonPainter` —— 共用霓虹绘制层

原来只有圆表有辉光，且是 4 层写死的循环；数字、条形都不发光，
整个盘面看起来是"一个霓虹表 + 一堆素控件"。

- 弧 / 线 / 圆 / 圆角矩形 / 文字，五套辉光原语
- **层数按控件尺寸自适应**（3 / 5 / 7 / 9 层）—— 小控件上叠 10 层既看不出效果又白花钱
- **`onDraw` 零分配**：所有 Paint 复用，不 new

### 重构：`CircularGaugeView`

1. 辉光换用 `NeonPainter`，层数自适应
2. **底轨上标出危险区**：从 `warnHigh` 起就是暗红。原来危险阈值只体现在"超了之后变红"，
   开车时看不到"还有多远到红线"
3. **爆闪**：超过危险阈值时整个环 + 指针按节奏闪
4. **文本格式化加缓存**：文本只随 `value` 变（5Hz），不随缓动变（60fps）
5. 留白按**辉光扩散量**给（原来按描边算，最外层会被裁掉）

### 重构：`BarGaugeView`

霓虹进度条 + 爆闪 + 阈值刻度线在报警时一起变亮。

### 验证

- **288 个单元测试全通过**（+27 个 `AlertPulseTest`）
- 装机：无崩溃；**模拟信号活过界面切换**（v1.8.0 的生命周期修复生效）

### ⚠️ 未完成 / 未验证（**下一轮优先**）

1. **性能没有量准**。`dumpsys gfxinfo` 只采到 5 帧（12 秒），
   且当时布局只有 2 个仪表、数据也没到位 —— **样本太小，不能下结论**。
   霓虹的层数上限（9 层）**是否能在 8 个仪表下守住 60fps，尚未验证**。
   **这是本轮最大的遗留风险**：这个项目已经因为"选型不量性能"栽过一次（LVGL）。
2. 数字 / 折线 / 多值 / G力值四种仪表**还没接霓虹**
3. 屏幕级报警叠加（整屏边缘辉光）未做

## v1.8.0 ~ v1.0.0 · 2026-10-02 ~ 10-03 · **已归档**

> 这 9 个版本（含 **LVGL 迁移的完整调试日志**）搬到了
> [`archive/CHANGELOG-v1.0~v1.8.md`](archive/CHANGELOG-v1.0~v1.8.md)。

| 版本 | 一句话 |
|---|---|
| `1.8.0` | 霓虹圆表（LVGL 自定义绘制）+ Sky Gauge 格式调研 —— **方案后被放弃** |
| `1.7.0` | 混合架构：仪表盘那一屏改用 LVGL（C）渲染 —— **后被放弃** |
| `1.6.0` | 模拟信号工具（无车调试仪表） |
| `1.5.0` | 自定义仪表盘（自由画布 / 拖拽编辑 / 参考线 / 自定义主题） |
| `1.4.0` | 抽出传输层接口 + 经典蓝牙 SPP 传输 |
| `1.3.1` | 修复公式引擎（3 个缺陷）+ 补单元测试 + 实车取证脚本 |
| `1.3.0` | 修复实车暴露的两个严重缺陷 |
| `1.2.0` | 仪表盘视觉主题 |
| `1.1.0` | 横竖屏自适应 |
| `1.0.0` | 首个可运行版本 |

> **LVGL 那一段的结论**（值得记住）：做到了能渲染，但"不如安卓控件流畅"，
> 最终放弃、改回 Android 自绘。完整原因见 [`19-LVGL-放弃记录.md`](19-LVGL-放弃记录.md)。
> 教训是：**C 层跨 JNI 每帧通信的开销**比想象中大，而收益只有"能读 Sky 主题"。

---
