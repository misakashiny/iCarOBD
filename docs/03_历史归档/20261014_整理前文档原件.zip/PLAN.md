# iCarOBD 协作计划

> 原则：一次只在 `TASK.md` 激活一项。完成后更新 `STATUS.md`，再推进下一项。

> 文档门槛：每项任务同时验收受影响文档，按 `AGENTS.md` 执行。项目待办权威仍为 `docs/03-迭代清单.md`；本文件维护协作顺序。执行完成先标待审查，审查通过后才推进。

## 1. 审查 G 值纵向单位换算（当前候选）

状态：已完成，2026-10-11 第三轮复核通过（T1-R2）。缺陷确认、限幅单位、同源时间基准、逐拍递推、传感器判据及受影响文档均已审查；实现仍未修复。证据见 STATUS.md 顶部规划方第三轮复核。

目标：以最小范围确认 `GForceSource.onCycle` 对速度变化计算 `calc_gy` 时的单位是否正确；先建立可失败的回归测试，再决定是否需要修复。

验收标准：

- 明确输入车速、时间间隔、期望 m/s² 与 G 值之间的换算关系，并记录证据。
- 新增或完善的单测能区分正确实现与“重复除以 9.80665”的错误实现。
- 若确认缺陷，提出最小修复方案及受影响范围；若不成立，记录反证并关闭风险。
- 不改变 `calc_gx`、`calc_gforce` 的既有语义，除非测试证明必须联动。

验证命令：

```powershell
.\tools\run-tests.ps1
```

## 2. 修复已确认的 G 值缺陷（条件任务）

状态：已完成，2026-10-11 T2-R 审查通过（规划方最小修正文档统计后）。正负持续限幅回归已补齐，格式差异已收敛。执行端 JVM 与构建通过，规划方核对本轮 XML/编译产物；独立 Gradle 复跑受 loopback 环境故障阻塞，未执行测试/构建。完整证据与保留风险见 STATUS.md 的规划方 T2-R 复核。

前置：任务 1 确认实现错误，并由审查结论说明修复边界。

验收标准：

- 修复仅作用于被证实错误的换算步骤，且有回归测试锁定。
- 模拟信号与真实传感器/速度推导路径的单位说明一致。
- 不引入存量仪表配置、PID ID 或 JSON 格式不兼容。

验证命令：

```powershell
.\tools\run-tests.ps1
.\gradlew.bat assembleDebug
```

## 3. 补齐多画布无需车辆的验证

状态：已完成，2026-10-12 T3-R2 审查通过（规划方追加精确快照范围、更正措辞并还原可核对的历史原句后）。T3/T3-R 未通过记录保留。权威状态见 [迭代清单 P11](docs/03-迭代清单.md) 和 [设备验收 §11.3.6](docs/16-上车监控清单.md)。

验收标准与已验收范围：

- 判据6：单套画布拒删行为通过；确认框、列表、删除日志、Toast事件与源码联合取证。完整中文 Toast 受污染，不称无损 UI 取证。
- 判据7：主题、背景、设计页号的隔离及冷启动持久化通过。23:40/42/47 的背景导入后往返以日志证明切换，XML证明两套列表属性；dump-58/69 均是当前B快照，不冒充活动A或最后A的全字段快照。JSON采样目标字段一致，冷启动 gauges 0→8 不属于23:47往返。
- 判据9：规则页模拟触发、同会话音效关→开即响与听音局部通过；后两项是本会话用户直接观察确认。SignalSimulator 与真车路径仍未验证。
- 原配置六份字节/语义一致、原设计10/10哈希一致（本轮只读复核时点）；旧恢复测量不被覆盖。
- 文档及证据有效性问题已关闭；不把本项完成等同 P11 全部完成，设备结论仅限1.20.21。

验证命令：

```powershell
adb devices -l
node tools/check-doc-links.js
powershell -ExecutionPolicy Bypass -File ./tools/check-build-guard.ps1 -Apk D:\icarobd\app\build\outputs\apk\debug\app-debug.apk
git diff --check
node tools/iteration-board/build.js
```

T3-R2 仅文档与只读复核，未重跑 JVM/浏览器/构建；旧结果不计为本轮新执行。详细证据见 STATUS.md 最新规划方复核。

## 4. T5 本地并行迭代第一批（已完成）

状态：已完成，2026-10-12 Codex接管后T5-R3独立复核通过。原7例及后续4观察均0违例；全量33套2603/0、跨语言169/0，锚点/按钮事件/画布/预算变异分别复现预期行为失败。B既有本地结果与C文档审查成果保留，旧失败和独立Gradle阻塞不覆盖。完整证据见 [STATUS.md](STATUS.md)。T6复现/方案已执行并评审，当前转T6-I由Codex实现；车辆最后。

三条独立支线并行：T5-A ICarUI撤销快照健壮性（UI-O1）、T5-B App探测页展示文案（APP-L1）、T5-C原T4-R文档收口。三支交付后由主代理统一集成，Codex按分支审查；T4/T4-R未通过结论不因改排而变成通过。

验收标准：

- A：先有失败回归；坏快照不污染当前设计/未应用JSON，加载过滤及运行时跳过有一致的栈/提示行为，合法旧设计和正常撤销/重做不回归，不自动恢复旧会话。
- B：普通展示不出现字面Markdown星号，安全提示语义不变，纯函数回归与页面接线可核，零探测/协议/配置逻辑变化。
- C：原R1~R4全部逐条补日期更正及来源/权限限定；不执行设备/车辆、不覆盖取证原件。
- 文件所有权无重叠、无子代理写共用报告；主代理串行运行浏览器/Gradle，统一文档与状态待审查。业务及文档一起审查，不能靠一个分支的绿灯宣布全批完成。

验证命令：

```powershell
powershell -ExecutionPolicy Bypass -File tools/run-browser-tests.ps1 -Filter bugfix
powershell -ExecutionPolicy Bypass -File tools/run-browser-tests.ps1
node tools/icarui/tests/verify-crosslang.js
powershell -ExecutionPolicy Bypass -File tools/run-tests.ps1
Push-Location D:\icarobd
.\gradlew.bat assembleDebug --no-daemon --console=plain
Pop-Location
node tools/guard-pid-probe.js
node tools/check-doc-links.js
powershell -ExecutionPolicy Bypass -File tools/check-build-guard.ps1 -Apk D:\icarobd\app\build\outputs\apk\debug\app-debug.apk
git diff --check
node tools/iteration-board/build.js
```

上段命令是T5原验收要求。2026-10-12规划方独立浏览器2019/0、跨语言169/0，但新探针复现两项数据保护缺陷；JVM/assemble各exit=1，被loopback阻塞，未产生独立新测试/构建通过。当前T5-R的命令/范围以TASK为准；原执行端绿灯不覆盖审查反例。第4项不得标完成或推进第5项。

2026-10-12 T5-R复审：独立定向217/0、全量33套2131/0、跨语言169/0；隔离真实file页面探针7例均发现验收违例（exit=1），不通过。当前以T5-R2命令/范围为准，JVM/assemble和设备未运行，历史证据保留；第4项仍不得完成。

2026-10-12 T5-R2复审：原独立7例exit0/无违例；新增隔离真实file探针4观察行/4违例、exit1（对应三项产品缺口）。全量33套2335/0、跨语言169/0及git diff --check0不能覆盖新反例；仅T5-R3激活，不完成第4项。原失败记录与已关闭缺陷均保留，JVM/构建/设备本轮未运行。

## 5. T6 ICarUI编辑一致性（UI-O2，已完成）


状态：已完成，2026-10-12 Codex实现及本地收口复核通过。最终定向891/0、全量33套2805/0、跨语言169/0，T5独立反例7例及4观察无违例；文档/看板守卫见STATUS本轮报告。UI-O2本批关闭，未发版，无设备/真车结果。

按顺序：先在隔离设计复现jsonDirty期间画布/属性/打开/撤销的冲突 → 提交最小交互方案 → 审查方案后实现。不能因工具CHANGELOG旧待办而假定现在每一条仍有缺陷。

验收：未应用JSON不被静默覆盖，应用/取消/继续编辑的结果可解释；现有合法文件往返及快捷键不回归，失败不丢设计。实现范围与写入所有权另卡确认，不引入自动合并或数据格式改变。

验证命令：

```powershell
powershell -ExecutionPolicy Bypass -File tools/run-browser-tests.ps1 -Filter bugfix
powershell -ExecutionPolicy Bypass -File tools/run-browser-tests.ps1
node tools/icarui/tests/verify-crosslang.js
node tools/check-doc-links.js
git diff --check
node tools/iteration-board/build.js
```

## 6. T7 ICarUI性能基线与首个瓶颈优化（UI-O3，量测完成，当前先修手势遗漏）

状态：T7-P已完成3轮60份量测及候选定位，产品未优化、第6项未通过/未完成。独立发现真实指针拖动没有撤销记录（2例2违例），当前TASK只激活T7-R修复正确性；修复审查后再评审JSON应用重复主绘制候选。量测/原缺陷/历史证据见STATUS，不以测量成功代表产品通过。

按顺序：在固定60/200控件、相同页面/缩放/环境下记录拖动、属性滑块、模拟和JSON校验的rAF帧间隔/输入响应/长任务及调用次数、序列化写入量 → 选一处已证瓶颈并定预算 → 最小优化。函数耗时只用于定位，不冒充整帧渲染成本；不并发改同一app/panels/canvas文件。

验收：提供可重放前后负载与帧间隔/输入响应指标，证明目标瓶颈减少且其他测量无明确退化；最终编辑状态、撤销粒度、校验错误/告警、file直开与素材预览不变。代码行数、函数耗时或调用减少不能单独作为画面更流畅的证明，本地性能观测不冒充真车帧率。

验证命令：

```powershell
powershell -ExecutionPolicy Bypass -File tools/run-browser-tests.ps1 -Filter features
powershell -ExecutionPolicy Bypass -File tools/run-browser-tests.ps1
node tools/icarui/tests/probe-file-url.js
node tools/check-doc-links.js
git diff --check
node tools/iteration-board/build.js
```

量测脚本/固定样例在任务激活时确定；probe退出码恒0，只作事实输出，必须逐项读结果，不能当验收门禁。

## 7. T8 ICarUI素材跨会话可用性（UI-O4，未激活）

状态：计划。前置：先确认导入素材实际体积、现有rawFile/缩略图/导包行为与支持环境，再评审方案；不直接把图片塞进撤销栈或localStorage。

验收：跨会话有无原字节明确报告，缺素材不能悄悄产出“完整包”；任何持久化改动先证明配额/失败恢复、用户数据保留、旧包兼容及file直开。预算/存储方案未确定前只盘点，不实现新的存储依赖。

验证命令：

```powershell
powershell -ExecutionPolicy Bypass -File tools/run-browser-tests.ps1 -Filter pack
powershell -ExecutionPolicy Bypass -File tools/run-browser-tests.ps1
node tools/icarui/tests/probe-file-url.js
node tools/check-doc-links.js
git diff --check
node tools/iteration-board/build.js
```

## 8. T9 App日志突发完整性（P2-3，未激活）

状态：计划。前置：高优先级本地项收口或被明确延期；详见 [迭代清单P2-3](docs/03-迭代清单.md)。P2-5在v1.20.18已实现的跟随/复制/对齐不重做。

按顺序：确认队列上限/内存及文件完整性 → 用可复现突发负载验证实际缺口 → 必要时给最小提示。验收：列表有界、增量位置不崩、不增加热路径重排/高亮开销，不把显示不全说成文件丢日志；先确定性能预算再实现。

验证命令：

```powershell
powershell -ExecutionPolicy Bypass -File tools/run-tests.ps1
Push-Location D:\icarobd
.\gradlew.bat assembleDebug --no-daemon --console=plain
Pop-Location
node tools/check-doc-links.js
git diff --check
node tools/iteration-board/build.js
```

负载入口及设备观感若需另有条件，激活时写清；不能用JVM绿灯代替UI压力证据。

## 9. T10 无需车辆的设备补验（条件项，未激活）

状态：计划；不阻塞上面的电脑端迭代。前置：有可用测试设备并确认每卡允许的配置/安装/恢复范围，无设备时保持未验。

按顺序各开小卡：SignalSimulator与规则评估路径核实 → 完整Toast/多指手势 → 当前App版本装机行为。已通过的6/7及用户直接听音项不重复破坏性操作。

验收：每项区分JVM/源码/设备/用户观察，备份与恢复可核；疑点未经复现不改规则语义。真车转向灯路径不能作为模拟失败的自动后备。

验证命令（只在专门卡激活后）：

```powershell
adb devices -l
powershell -ExecutionPolicy Bypass -File tools/run-tests.ps1
node tools/check-doc-links.js
git diff --check
node tools/iteration-board/build.js
```

当前T5禁止上述设备操作，实际设备命令/安装与恢复清单须由各卡明确。

## 10. T4 上车前准备与真车验收（排最后，未激活）

状态：用户明确延期，未完成/未通过。原T4审查失败与T4-R交付缺失事实保留；不勾完成、不销项。原文档返工作为T5-C先做，无车不妨碍该支；真实车辆/适配器验证留在本计划最后。

权威条目：[迭代清单](docs/03-迭代清单.md) 的P9/P11/P12/P1与 [上车监控清单§11](docs/16-上车监控清单.md)。

依次另卡：重新确认当时车辆/适配器目标身份/当前配对与现场安全条件 → 审查T5-C纠正清单及新版本取证方案 → 激活连接/初始化健康检查（BLE/SPP分开门槛）→ 通过后工单B → 工单A → 仅依赖车辆的剩余C。未知PID/CAN位保持未知，不猜绑定；不重跑已经通过的无需车辆项。

验收：每步保留该轮证据、失败停止、保护配置/原件；本地测试、旧设备1.20.21与历史实车证据不能替代新版当轮真车验证。条件恢复且用户明确激活前保持延期，不由子代理自动转上车。

验证命令（只在相应专门卡激活后）：

```powershell
adb devices -l
node tools/guard-pid-probe.js
node tools/check-doc-links.js
powershell -ExecutionPolicy Bypass -File tools/check-build-guard.ps1 -Apk D:\icarobd\app\build\outputs\apk\debug\app-debug.apk
git diff --check
node tools/iteration-board/build.js
```

实际连接/初始化/监听/导出与留档的命令及停止门槛由每张上车卡单独规定；当前不执行。


## 2026-10-12 用户新增任务 T7-U 已完成

- [x] T7-U：控件库保留滚动位置、素材显示比例修复、原创图标与 favicon。Codex 本轮实现及同轮复核通过，正式全量33套件2938/0、跨语言169/0；权威条目见 [迭代清单](docs/03-迭代清单.md) 的 T7-U 补充。
- [ ] T7-R：真实画布手势撤销/持久化。恢复为 TASK 唯一当前任务，原失败证据保留。

T7 性能及 UI-O3 仍未完成，设备/真车未验。T7-U 的完成不替代 T7-R 或性能验收，不激活 T8以后。


## 2026-10-12 用户重排：T11 全量重建控件库

权威规格与验收见 [主题设计大纲](docs/12-主题设计大纲.md) T11节；项目状态见 [迭代清单](docs/03-迭代清单.md)。

- [x] T11-P：规划与三风格隔离样板，本轮完成；不代表生产库替换。
- [ ] T11-I：新库核心数据契约、三风格读数与配套素材，下一唯一任务。
- [ ] T11-S：状态源和枚举/驾驶信息，逐支验收。
- [ ] T7-R：真实手势撤销，原失败保留，必须在新库编辑体验验收前专门完成。
- [ ] T11-L：组合布局与主题；T11-X：完成验收后替换默认入口、收退旧库。

T7性能、T8以后与车辆仍未完成/未激活，旧TASK-T7R卡在stage/t11p-codex-20261012留档。T11父任务未完成，不由样板预览替代正式集成。

## 2026-10-12 T11-P2 扩展样板完成

- [x] T11-P2：用户认可外观后补齐其他功能三风格、交互与原创三态素材，样板验证通过。
- [ ] T11-I：恢复为TASK唯一下一任务，正式核心生成/集成仍待执行。

扩展样板不勾T11-S/L/X生产完成，T11父任务及T7-R/性能/车辆未完成保留；权威内容见 [主题设计大纲](docs/12-主题设计大纲.md) T11-P2，证据见STATUS。

## 2026-10-12 用户重排：T12-UI界面与文案

- [x] T12-UI：实际编辑器布局、文案和帮助优化完成；Codex执行并同轮复核通过，正式33套件2969/0。
- [ ] T11-I：UI任务通过后恢复，原卡保留在stage/t12ui-codex-20261012/TASK-T11I.md。

项目状态以 [迭代清单](docs/03-迭代清单.md) 为准。T11-S/L/X、T7-R、性能和设备/真车缺口保持未完成。

2026-10-12 T12-UI复核通过后，TASK恢复T11-I为唯一当前任务。上方“待恢复”顺序已兑现，T11父任务及T7-R/性能/设备缺口继续保留。证据见STATUS，权威待办见docs/03。


2026-10-12 T11-I本轮：首批5类/15变体生产入口与图片拖入比例本地通过，34套件3059/0。完整验收的独立控件JSON迁移、缺数据动画/告警及App一致性仍需补齐，TASK保持T11-I，不推进T11-S。完整证据见STATUS，项目待办仍以docs03为准。


2026-10-13：T11-I-C工具控件文件/数据状态修复本地通过，35套件4205/0。父T11-I仍未完整通过，App排版字段/缩放/额外单位差异已写TASK；不推进T11-S。权威状态见docs/03-迭代清单.md，证据见STATUS。

2026-10-13 App全局框架审查：保持TASK=T11-I，未实施业务修复、未推进下一卡。App-A0～A8为未激活的后续候选，优先处理请求安全、数据正确性与配置保护，再考虑职责/性能重构；验收和阻塞关系只在[迭代清单](docs/03-迭代清单.md)的「App全局审查候选」维护。若用户决定插入修复批次，先保留T11-I未通过状态并单独激活父卡；车辆验收仍排末尾。本轮测试/环境限制与源码证据见STATUS。


2026-10-13：用户明确将数据显示放在外观之前。T11-I-D作为当前T11-I的关联修复，先补组合数据绑定入口、真实PID回显、动态单位及App拼装值快照。保留App-A审查原始结论，当前只修与控件直接相关的数据消费；采集端失效/油耗/重连等仍未激活。T11-I未完整通过，不推进T11-S。


2026-10-13 T11-I-D本地收口：数据绑定与局部消费通过，36套件4422/0、JVM1133/0/0；仍留T11-I为唯一当前任务。App-A采集端失效/派生/重连未由本轮消费修复关闭；设备与新包显示验收未完成。

## 2026-10-13 用户授权App优化：首批App-A0

- [x] App-A0：最终PID请求安全保护本地验收/同轮差异复核通过；实际会话假传输、导入/备份、完整JVM与新debug构建证据见STATUS，设备/真车未验。
- [x] T-App-A1-D（候选App-A1-D）：派生数据失效与行程清零，2026-10-13 Codex实现及同轮范围复核本地通过；红绿回归、完整JVM/新APK及文档证据见STATUS。源断连总项未关闭。
- [x] T-App-A1-L（候选App-A1灯状态分支）：2026-10-13生产解析/分发与本地范围复核通过；完整JVM、新debug/文档、36套浏览器及迁移后crosslang见STATUS。实际App像素/渲染性能仍未验，App-A1总项不关闭。
- [x] T-UI-A1-L：2026-10-13续轮正常审核补齐Git/97项定向/最新看板及文档守卫，本地审查通过；历史审批限制保留。
- [x] T-App-A1-P：2026-10-13生产源生命周期/正式三轮8项5红及最小方案交付本地通过；源产品尚未修复，原卡留档。
- [x] T-App-A1-C：2026-10-13内部源/轮询实现与同轮范围复核本地通过，1216项JVM及最终APK/文档/Git/C看板有证据；平板安装/原生显示/17文件保护局部通过，真实OBD断连未验。
- [ ] T-App-A1-S：CAN-2通过后恢复当前唯一TASK，已规划未实施，冻值未修。
- [x] T-App-CAN-1：2026-10-14本地范围与平板UI局部/同轮文档复核通过，1252项全量和最终包有证据；真实硬件/车辆未验。
- [ ] T11-I：保留未完整通过状态，原卡留档stage/app-a0-codex-20261013/TASK-T11-I.md；后续恢复时重新激活。

App-A1其余分支及App-A2～A8是后续候选，验收与优先级仍以[迭代清单](docs/03-迭代清单.md)为权威，本轮不自动并行实施。2026-10-13收口更正：上方预先推进的T-App-A1-P已撤回为候选，当前保持T-UI-A1-L待最终Git/看板复核；通过后才评审源归属/会话失效方案。原T11-I继续未完整通过，设备/真车末尾。


2026-10-13 续轮：T-UI-A1-L最终Git与定向检查已补齐，本地审查通过，正在重建当前摘要看板；原额度阻止记录保留。App源失效候选将按TASK单卡激活，未因既有消费层绿灯关闭总项。


2026-10-13续轮：前项看板和文档守卫已实际通过，本轮激活T-App-A1-P。此前撤回候选是当时事实，此处更新当前顺序；App源实施卡仍须本卡证据/方案复核后激活。


2026-10-13 T-App-A1-P当前进展：真实Engine正式红回归8项/5失败、反例重复集合一致；源归属/有限期限/旧job边界方案已登记，生产未修。拟下一单卡T-App-A1-C仅内部令牌与轮询，须当前方案与文档复核后激活，不自动执行模拟/监听/传感器后续卡。权威状态/验收见docs03。


2026-10-13 T-App-A1-P最终收口：文档30份1019候选0失效/84豁免 exit0，沿用1.20.22 APK/419PNG守卫 exit0，正常审批Git CRLF diff --check exit0，当前P看板37原文 exit0。源表/正式可重复红回归/最小实施方案的本地交付审查通过；8条中5红不是产品通过，生产未修。TASK切T-App-A1-C待执行，原P卡和UI卡均在本轮stage留档；当前C快照随摘要重新生成。


2026-10-13 T-App-A1-C最终复核：原8条5红→8绿、最终源26项/完整1216项0失败错误跳过、最终debug APK与设备pull哈希一致、crosslang174/0、文档30份1024候选0失效/84豁免、Git CRLF diff exit0及C看板37原文exit0。轮询小卡本地范围通过，平板显示/配置保护局部通过；真实轮询断连/车辆未运行。原卡留档stage/app-a1c-codex-20261013/TASK-T-App-A1-C.md。下一仅激活T-App-A1-S已规划待执行，解决真实模拟stop后冻值；App-A1总项、其他源/Controller/Session/MAF/T11-I与真车未完成。


2026-10-13用户重排：当前唯一TASK=T-App-CAN-1，检查修复CAN探测并优化界面。T-App-A1-S原卡已留档仍未完成，CAN本卡通过后再评审恢复；C既有通过证据/其他总项保持。权威验收与问题在docs03，真实车辆仍末尾。


2026-10-14 T-App-CAN-1收口：最终75类1252项fail/error/skip=0，新debug构建/设备pull哈希一致、横竖屏UI局部与17文件恢复、文档/Git及CAN看板实际通过，同轮代码/文档范围复核通过。原CAN卡留档stage/can-review-codex-20261013/TASK-T-App-CAN-1.md。现只恢复T-App-A1-S待执行，未在本轮实现S；真实CAN/常驻监听硬件、总App-A1/T11与真车仍未完成，车辆最后。


2026-10-14用户布局反馈：当前仅激活T-App-CAN-2收紧顶部并扩大结果，执行中；T-App-A1-S暂缓未实施留档，CAN-1先前逻辑/平板局部证据保留。CAN-2通过后恢复S，不把新布局反馈当作原逻辑验证失效或全CAN硬件通过。

- [x] T-App-CAN-2：2026-10-14顶部修正/本地与平板UI/文档同轮范围复核通过，横屏结果高多37.47%、竖屏多28.41%。


2026-10-14 CAN-2收口：仅2个UI文件、75类1252项无失败错误跳过、新包/平板17文件保护、实际高度与详情旋转、文档/Git/CAN-2看板均通过，同轮范围复核完成。原卡留档stage/can-header-codex-20261014/TASK-T-App-CAN-2.md；仅恢复S待执行，本轮不实施S，原CAN硬件/车辆及其他缺口保持。


2026-10-14用户重排：唯一当前TASK=T-App-PID-1，检查PID逻辑并优化结果界面，执行中。S未实施暂缓留档，CAN既有局部证据保留；PID本卡通过后恢复S待执行，车辆仍末尾。


- [x] T-App-PID-1：2026-10-14逻辑/UI本地与设备UI局部同轮复核通过，最终1284项全绿/新包/17文件/文档/Git，硬件未验。

2026-10-14最新顺序：唯一当前TASK恢复T-App-A1-S待执行，PID卡留档stage/pid-review-codex-20261014/TASK-T-App-PID-1.md。S尚未实施，原冻值缺陷保留；其他App/T11与真车仍未完成。


2026-10-14用户继续：T-App-A1-S已激活并进入执行，先建立真实Simulator红回归；不改其他源/主题/采集，也不自动开下一卡。


- [x] T-App-A1-S：2026-10-14模拟停源本地/平板模拟及同轮范围复核通过；1295项/新包/17文件/文档与Git有证据。

下一仅激活T-App-A1-M-P待执行：先核常驻监听生产生命周期/停后值和最小方案；监听业务尚未修，其他App-A1/T11和车辆仍未完成，排版重叠另留权威待办。
